# W1.4 — Giao diện Swing

Trạng thái: hoàn thành, 14/10/2026.

Đã có Server console, Login, Quầy chủ quán và Client tại bàn. Chủ quán nhìn sơ đồ 6 bàn, số kết nối, đơn/ticket theo bàn và hóa đơn. Khách chọn số lượng từ menu, gửi note, xem tiến độ, gọi nhân viên, yêu cầu tính tiền và xem phản hồi. Mọi request chạy trong SwingWorker; update UI được chuyển về EDT. Disable nút khi đang gửi/mất kết nối và theo trạng thái nghiệp vụ.

Bổ sung CLOSE_EMPTY_TABLE để chủ quán kết thúc bàn không phát sinh đơn mà không tạo hóa đơn giả; yêu cầu còn mở phải được xử lý trước. Service test bổ sung kiểm chứng quyền và điều kiện này. Lỗi compile do MenuItem bị trùng tên với AWT đã được sửa bằng import rõ ràng. Refresh thất bại sau ACK không được làm mất kết quả mutation đã được xác nhận.

`scripts/maven.ps1 -B test`: **23 tests pass, 0 failures/errors/skipped** (6 frame, 7 service, 8 network, 2 UI). UiWorkflowTest bấm nút Swing thật, network thật, database thật; chỉ thay câu trả lời modal qua Dialogs. Đã kiểm chứng đơn 2 cà phê sữa giá 60.000 đ, ba bước phục vụ, yêu cầu tính tiền, trả lời, payment và đóng phiên; trạng thái chờ bàn và disconnect vô hiệu nút đặt.

Ảnh render từ giao diện thật ở `cafelink-system/target/ui-smoke`: admin-serving.png, guest-orders.png (tab phản hồi tại thời điểm capture), guest-disconnected.png. Đã mở ảnh và kiểm tra tiếng Việt/bố cục, không dùng ảnh giả. Chạy trên desktop Windows hiện tại; môi trường headless sẽ skip suite UI và phải được báo rõ, không coi skip là pass.

Giới hạn: test modal dùng câu trả lời tự động; chưa thay thế hoàn toàn một người demo thao tác thủ công. Login/entrypoint sẽ kiểm tra thêm ở bước đóng gói. Giao diện là Swing desktop, không phải web/mobile. Contribution tự phục hồi outbox thuộc tuần 2.
