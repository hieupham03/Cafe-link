﻿# CafeLink Original 1.0.0

Start in cafelink-system. PowerShell commands:

    powershell -NoProfile -ExecutionPolicy Bypass -File scripts/verify-package.ps1
    powershell -NoProfile -ExecutionPolicy Bypass -File scripts/demo.ps1

JAR and runtime libraries are included; JDK is required. A build is not needed
to run the packaged baseline. See report/CafeLink_Original_Handoff.md and
cafelink-system/docs/LAN_ACCEPTANCE.md for evidence, limitations and LAN setup.
Do not share data/client-state journals created during use: they hold credentials.
SHA256-MANIFEST.csv describes pristine package contents, before runtime data.
