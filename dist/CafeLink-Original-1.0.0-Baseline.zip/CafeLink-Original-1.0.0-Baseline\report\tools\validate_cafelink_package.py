"""Validate a pristine exported ZIP in a new path, then build its included source.

Only processes started by the included smoke script are stopped. The archive
stays untouched; generated journals/databases stay in the validation copy.
"""
from pathlib import Path
import argparse
import hashlib
import json
import socket
import subprocess
import zipfile
import xml.etree.ElementTree as ET


def run_ps(script, args, cwd, log, expected=0, timeout=300):
    print(f"PACKAGE CHECK: {script.name}", flush=True)
    process = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script), *args],
                             cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    log.write_bytes(process.stdout)
    if process.returncode != expected:
        raise RuntimeError(f"{script.name}: exit {process.returncode}, expected {expected}; see {log}")
    return process.stdout.decode("utf-8-sig", errors="replace")


def validate(archive, output, skip_source_build=False, source_build_evidence=None):
    # The child PowerShell runs from the extracted project, not this caller's cwd.
    archive, output = archive.resolve(), output.resolve()
    if source_build_evidence is not None:
        source_build_evidence = source_build_evidence.resolve()
    output.mkdir(parents=True, exist_ok=False)
    clean = output / "Fresh copy with spaces"
    clean.mkdir()
    with zipfile.ZipFile(archive) as source:
        for info in source.infolist():
            target = (clean / info.filename).resolve()
            if not target.is_relative_to(clean.resolve()):
                raise ValueError("Archive escapes validation directory")
        source.extractall(clean)
    package = next(clean.iterdir())
    project = package / "cafelink-system"
    scripts = project / "scripts"
    source_files = [project / "pom.xml", *[p for p in (project / "src").rglob("*") if p.is_file()], *scripts.glob("*.ps1")]
    source_hash = hashlib.sha256("".join(str(p.relative_to(project)).replace("\\", "/") + "\0" + hashlib.sha256(p.read_bytes()).hexdigest() + "\n" for p in sorted(source_files)).encode("utf-8")).hexdigest()
    prior_build = None
    if skip_source_build:
        if source_build_evidence is None:
            raise ValueError("Skipping build requires a passing source-build evidence file")
        prior_build = json.loads(source_build_evidence.read_text(encoding="utf-8"))
        if prior_build["status"] != "PASS" or prior_build["applicationSourceSha256"] != source_hash or not prior_build["rebuiltSourceTests"]:
            raise ValueError("Candidate build evidence does not match final application source/tests/scripts")
    run_ps(scripts / "verify-package.ps1", [], project, output / "manifest-pass.log")
    readme = project / "README.md"
    original = readme.read_bytes()
    try:
        readme.write_bytes(original + b"\nvalidation-tamper\n")
        run_ps(scripts / "verify-package.ps1", [], project, output / "manifest-tamper-rejected.log", expected=1)
    finally:
        readme.write_bytes(original)
    run_ps(scripts / "verify-package.ps1", [], project, output / "manifest-restored.log")
    # Connectivity probe is deliberately checked separately from application acceptance.
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        listener.listen()
        port = str(listener.getsockname()[1])
        run_ps(scripts / "lan-check.ps1", ["-ServerAddress", "127.0.0.1", "-Port", port], project, output / "probe-connected.log")
    run_ps(scripts / "lan-check.ps1", ["-ServerAddress", "127.0.0.1", "-Port", port], project, output / "probe-unavailable.log", expected=1)
    smoke_cases = []
    for recovery, name in ((False, "normal"), (True, "recovery")):
        before = set((project / "target").glob("smoke-*"))
        smoke_output = run_ps(scripts / "smoke.ps1", ["-Recovery"] if recovery else [], project, output / (name + "-smoke.log"))
        if "Owned JVM stopped, listener closed:" not in smoke_output:
            raise ValueError("Restart proof requires an explicit closed-listener check, not only PASS JSON")
        folder, = set((project / "target").glob("smoke-*")) - before
        for filename in ("populate.json", "restart.json"):
            # Tee-Object in Windows PowerShell writes UTF-16LE by default.
            raw = (folder / filename).read_bytes()
            result = json.loads(raw.decode("utf-16") if raw.startswith(b"\xff\xfe") else raw.decode("utf-8-sig"))
            if result["status"] != "PASS":
                raise ValueError("Smoke data did not pass")
            smoke_cases.append(dict(scenario=name, **result))
            (output / (name + "-" + filename)).write_text(json.dumps(result, indent=2), encoding="utf-8")
    run_ps(scripts / "verify-package.ps1", [], project, output / "manifest-after-runtime.log")
    # This intentionally rebuilds only the validation copy after pristine-runtime checks.
    # Bootstrap may use Internet; Maven dependency cache is shared on this machine.
    measured_jar_hash = hashlib.sha256((project / "target/cafelink-1.0.0.jar").read_bytes()).hexdigest()
    if prior_build and measured_jar_hash != prior_build["originalJarSha256"]:
        raise ValueError("Final runtime JAR differs from candidate")
    totals = None
    if not skip_source_build:
        run_ps(scripts / "build.ps1", [], project, output / "source-build.log", timeout=600)
        suites = [ET.parse(path).getroot() for path in (project / "target/surefire-reports").glob("TEST-*.xml")]
        totals = {key: sum(int(suite.attrib[key]) for suite in suites) for key in ("tests", "failures", "errors", "skipped")}
        if not suites or any(totals[key] for key in ("failures", "errors", "skipped")):
            raise ValueError("Clean-path build requires all suites passing, including UI")
    summary = dict(status="PASS", archive=str(archive.resolve()), validationPath=str(clean.resolve()),
                   archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(), originalJarSha256=measured_jar_hash,
                   applicationSourceSha256=source_hash,
                   manifest="Pass before runtime, detects modified README, pass after restore and runtime",
                   connectivityProbe="Loopback success and unavailable-port failure checked; physical LAN NOT RUN",
                   smoke=smoke_cases, rebuiltSourceTests=totals,
                   sourceBuildSkipped=skip_source_build,
                   identicalSourceBuildEvidence=str(source_build_evidence) if source_build_evidence else None,
                   pathScope="Fresh ASCII directory with spaces. A separate Vietnamese-directory probe failed on this JDK24 Windows native.encoding=Cp1252; retained as known launcher limitation, not a passing check.",
                   buildEnvironment="Same Windows/JDK24 machine; fresh extracted source, Maven bootstrap download and existing user dependency cache; not a fresh OS/offline build")
    (output / "package-validation.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": "PASS", "rebuiltSourceTests": totals, "smokeChecks": len(smoke_cases)}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--skip-source-build", action="store_true", help="Recheck final ZIP runtime after an identical-source candidate build passed")
    parser.add_argument("--source-build-evidence", type=Path)
    options = parser.parse_args()
    validate(options.archive, options.output, options.skip_source_build, options.source_build_evidence)
