# CafeLink bản gốc — truy vết yêu cầu và bằng chứng

Nguồn yêu cầu: `final-project/Instruction.md`, phạm vi đã chốt trong `CafeLink_Implementation_Plan.md`. Chỉ tính các cơ chế đã có mã và kiểm tra; đề xuất nâng cấp nằm riêng trong Upgrade Plan.

| ID | Yêu cầu | Mã triển khai chính | Bằng chứng nghiệm thu |
|---|---|---|---|
| F01 | Đăng nhập, phân quyền ADMIN/GUEST | CafeService, PasswordHash, CafeServer | CafeServiceTest, NetworkIntegrationTest, UiWorkflowTest |
| F02 | Menu và giá do server quyết định | CafeService.placeOrder | CafeServiceTest: dữ liệu sai, giá, quantity; UiWorkflowTest |
| F03 | Mở/đóng bàn, một lượt active | CafeService, Database | CafeServiceTest, GuestSessionTest; unique index one_active_visit |
| F04 | Đặt món và tổng VND | CafeService, NetworkClient | CafeServiceTest, 12-client concurrency, benchmark + SQLite oracle |
| F05 | Tiến độ SUBMITTED→PREPARING→READY→SERVED | CafeService, DashboardFrame | CafeServiceTest, UiWorkflowTest |
| F06 | Gọi phục vụ/yêu cầu tính tiền và phản hồi | CafeService, DashboardFrame | CafeServiceTest, UiWorkflowTest, RecoveryIntegrationTest |
| F07 | Hóa đơn/thanh toán mô phỏng, chỉ đóng khi đủ điều kiện | CafeService.payAndClose | CafeServiceTest, UiWorkflowTest, race order/payment, lost payment ACK |
| F08 | Guest chỉ thấy/thao tác bàn được gán | CafeService.snapshot, credential guard | GuestSessionTest, NetworkIntegrationTest, UiWorkflowTest |
| F09 | Cập nhật chủ động và presence socket | CafeServer, NetworkClient | NetworkIntegrationTest, UiWorkflowTest; không xác minh số người vật lý |
| F10 | Giữ dữ liệu qua restart | Database, receipt/outbox | CafeServiceTest, GuestSessionTest, smoke hai JVM và recovery smoke |
| F11 | Lấy lại outcome/chống lệnh trùng | command_receipts, fingerprint | CommandReceiptTest, RecoveryIntegrationTest, campaign LOST_*_ACK |
| F12 | Outbox bền vững, lookup, xác nhận/bỏ trước nhận | Outbox, NetworkClient.recover/discard | OutboxTest, RecoveryIntegrationTest, UiWorkflowTest; REVIEW/REPLAY_ALL campaign |
| F13 | Ý định cũ không chuyển sang lượt khách mới | guest_credentials, visit guard, START_NEW_VISIT | GuestSessionTest, RecoveryIntegrationTest; VISIT_CHANGED campaign |
| N01 | TCP framing/version/giới hạn/UTF-8 | FrameCodec | FrameCodecTest: phân mảnh, nhiều frame, lỗi header/body/Unicode/JSON/version |
| N02 | Nhiều client và tương quan response/event | CafeServer, NetworkClient | NetworkIntegrationTest; 1/5/10/20 guest benchmark, raw requests.csv |
| N03 | Giới hạn 32 socket, queue 64, client chậm | CafeServer | NetworkIntegrationTest: socket thứ 33, slow peer không đọc, cleanup thread |
| N04 | Invalid request, disconnect, timeout, DB error | FrameCodec, CafeServer, CafeService, NetworkClient | Codec/service/integration/recovery tests, rollback trigger, unavailable server lock |
| N05 | Commit mutation + receipt + revision nguyên tử | CafeService transaction | CommandReceiptTest, SQLite rollback, payment/order race |
| N06 | Đo latency/throughput/traffic/storage và có raw data | BenchmarkClientMain, benchmark.ps1, analyzer | evidence/cafelink-original/; định nghĩa đo và giới hạn trong Project Report mục 8–10 |
| D01 | Kiến trúc, giao thức, contribution, thảo luận | docs và báo cáo technical paper | Project Report mục 1–16, PROTOCOL, ARCHITECTURE, ADR-001/002 |
| D02 | Chạy độc lập từ bản đóng gói | package-original.ps1, verify-package.ps1 | SHA256 manifest; kiểm chạy bản giải nén ở đường dẫn sạch ASCII có khoảng trắng |
| L01 | LAN vật lý hai máy | run-server/run-client/lan-check | **NOT RUN**: người dùng chỉ có một máy; runbook docs/LAN_ACCEPTANCE.md |
| S01 | Bìa, phân công thực tế, tên file nộp | Báo cáo | **Hoãn theo người dùng**; chưa cần điền thông tin nhóm |
| S02 | Compilatio và bàn giao chính thức | Theo Submission.md | **NOT RUN**: cần tài khoản/kết quả thực tế và người dùng thực hiện nộp |

Tên suite trỏ tới `cafelink-system/src/test/java/com/cafelink/`. Tổng test lấy từ `evidence/cafelink-original/test-summary.json`; không dùng số lượng test để suy ra độ phủ dòng mã. Các mục LAN/nộp bài chỉ đổi trạng thái khi có bằng chứng thực tế.
