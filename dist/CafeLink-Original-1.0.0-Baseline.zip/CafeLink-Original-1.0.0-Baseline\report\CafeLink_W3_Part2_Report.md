# W3.2 — Đo tải, traffic và storage bản gốc

## Bộ đo và kiểm tra trước campaign

`BenchmarkClientMain` là chương trình client độc lập. ServerMain được launcher PowerShell tạo ở JVM riêng cùng DB mới. Mỗi guest có một socket, worker và journal; chia đều trên sáu bàn. Một admin mở bàn và nhận server push; traffic admin không nằm trong bộ đếm guest.

`BenchmarkWorkflowTest` kiểm tra fixture qua TCP/SQLite: hai guest, 20 request đo, 0 lỗi, bốn đơn/120.000 VND, CSV đủ 20 mẫu và summary khớp. Calibration launcher đã phát hiện hai lỗi công cụ trên Windows PowerShell: `java -version` ghi stderr khi ErrorAction=Stop và Process.ExitCode chưa được cache; đã đổi sang `--version` và giữ process Handle trước WaitForExit. Calibration sau sửa đạt, không dùng số đo một giây này làm benchmark cuối.

## Campaign cuối

```powershell
cd cafelink-system
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/benchmark.ps1 -ClientCounts '1,5,10,20' -Repetitions 5 -DurationSeconds 60 -WarmupSeconds 10
```

20 lần chạy nối tiếp, thứ tự tăng/giảm số client xen kẽ giữa các repetition. JAR hash được kiểm trước mỗi case; không rebuild hoặc chạy campaign phục hồi đồng thời. Một guest tạo một request/giây, mỗi slot thứ năm PLACE_ORDER (một cà phê sữa 30.000 VND), còn lại GET_STATE. Warmup mười giây và đo sáu mươi giây mỗi lần.

Raw folder cuối: `cafelink-system/target/benchmark-84fe20348a7f4644adcf553cb6570439/`. **PASS 20/20 lần; 10,800 request, 0 lỗi.** Analyzer đối chiếu đủ matrix/raw/SQLite và tổng tiền từng lần.

Đợt đo cũ `benchmark-5372d5c03aa047739b62c50fd4160788` bị loại khỏi baseline hiệu năng do launcher Oracle để JVM con sống sau cleanup. Đợt cuối dùng JVM thật từ java.home và kiểm `listenerClosed=True` mỗi case. Xem [đính chính](CafeLink_Launcher_Correction.md); raw cũ được giữ, không trộn với số đo cuối.

## Định nghĩa và giới hạn

- Latency đo nanoTime quanh RPC; đặt món gồm ghi journal trước gửi/cập nhật kết quả. Mẫu lỗi/timeout không bị bỏ.
- p50/p95 nearest-rank; bảng gộp mẫu từng mức tải, từng lần lặp vẫn giữ riêng để xem dao động. Không dùng pooled p95 làm khoảng tin cậy.
- Request/s gồm đọc và đặt món; chia thời gian cửa sổ hoặc cả drain nếu dài hơn. Lịch cố định không tìm công suất tối đa.
- Bộ đếm byte guest gồm header frame/event/heartbeat, không gồm TCP/IP hoặc admin. Byte write lỗi một phần có thể không tính. Mốc chụp traffic giữ độ lệch so với start; không suy thành byte Ethernet.
- Journal JSON và DB/WAL là kích thước tại mốc chụp, có cả dữ liệu warmup; chưa tách chi phí riêng receipt/outbox.
- CPU/RAM là cấu hình môi trường; process peak không phải benchmark tài nguyên theo cửa sổ đo. Không kết luận tối ưu RAM/CPU từ các con số peak không đầy đủ.

Analyzer `report/tools/analyze_cafelink_experiments.py` kiểm đủ matrix, raw sample/count/timing, lỗi không bị giấu, SQLite integrity/foreign key/count/receipt/tổng tiền. Evidence công khai không có credential/outbox/DB. Có ba kiểm thử Python của thống kê và phát hiện raw data không khớp.

## Kết quả sau đối chiếu

| Guest | Tổng request | Lỗi | Request/s TB | p50 (ms) | p95 (ms) | Nhận TB (MiB) |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 300 | 0 | 1.00 | 4.64 | 18.40 | 0.18 |
| 5 | 1500 | 0 | 5.00 | 2.68 | 12.50 | 1.58 |
| 10 | 3000 | 0 | 10.00 | 2.60 | 11.36 | 7.63 |
| 20 | 6000 | 0 | 20.00 | 2.89 | 8.64 | 44.81 |

[Raw data và biểu đồ](evidence/cafelink-original/RESULTS.md), [oracle SQLite](evidence/cafelink-original/database-oracle.csv). Bảng không phải công suất tối đa hoặc đo LAN.
