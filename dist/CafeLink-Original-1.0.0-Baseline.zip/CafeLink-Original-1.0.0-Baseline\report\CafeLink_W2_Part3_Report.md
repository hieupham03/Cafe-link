# W2.3 – Outbox, reconnect và phục hồi theo loại yêu cầu

Hoàn thành 20/10/2026. `scripts/maven.ps1 -B test`: **48 tests, 0 failures/errors/skipped** (4 OutboxTest và 8 RecoveryIntegrationTest mới).

Client production ghi ý định vào file trước gửi, lưu ID/payload/credential và trạng thái. Ghi file temporary, force, atomic replace; file lock chặn hai tiến trình dùng chung journal. Không lưu password; không tự ghi đè dữ liệu hỏng. Login mặc định dùng credential đã lưu, đối chiếu receipt trước quyết định. Cả đơn và yêu cầu phục vụ chưa được ghi nhận đều cần xác nhận rõ; không claim TTL hoặc tự replay. Guest UI có tab Phục hồi, đối chiếu, xác nhận gửi lại và không gửi nữa. Khi còn yêu cầu chưa rõ, chặn thao tác mới để tránh người dùng vô tình đặt lại cùng ý định.

Thao tác “Không gửi nữa” là DISCARD_COMMAND tại server: nếu đã commit thì giữ kết quả; nếu chưa nhận, lưu dấu bỏ trong cùng khóa/transaction để chặn handler cũ đến muộn. Đây không phải hủy món đã nhận. Bắt đầu khách mới cần lượt cũ đã đóng và outbox đã giải quyết, server kiểm tra trước khi cấp credential mới.

Đã kiểm thử: mất ACK sau commit + service/server/client restart; mất trước nhận đơn/lời gọi; giữ nguyên ID khi xác nhận; ticket đã nhận không tạo bản sao; đổi lượt và bảo vệ dữ liệu khách mới; dấu bỏ chặn lệnh gốc đến muộn; lookup/replay cạnh tranh handler cũ; cấp lượt mới đúng điều kiện. FaultInjector được truyền từ constructor local, không có RPC cho remote bật lỗi. Kiểm thử UI recovery và demo đóng gói/fault CLI sẽ bổ sung ở W2.4.

Đây là kết quả chức năng. Chưa có benchmark tải/median/p95 hoặc kết luận tỷ lệ cải thiện trên mạng thực tế. Chỉ bảo đảm độ bền trong các tình huống đã kiểm thử, không claim exactly-once delivery hay chống mất điện mọi trường hợp.
