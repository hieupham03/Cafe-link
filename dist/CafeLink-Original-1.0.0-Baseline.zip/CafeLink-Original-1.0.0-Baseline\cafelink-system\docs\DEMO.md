# Demo CafeLink và câu hỏi bảo vệ

## Demo 5–7 phút

1. Build bằng scripts/build.ps1; mở scripts/demo.ps1. Server + ba cửa sổ guest. Trong Server console mở chủ quán và đăng nhập admin/CafeLink@123. Guest ban1/2/3 dùng Ban1/2/3@123.
2. Giải thích server là authority; guest chưa được đặt nếu chủ quán chưa mở bàn. Mở bàn 1–3 và quan sát guest cập nhật không bấm refresh.
3. Bàn 1 đặt 2 cà phê sữa = 60.000 đ; bàn 2/3 đặt món khác. Chủ quán chọn từng bàn xem đơn, chuyển bước phục vụ. Đơn đang pha vẫn chưa được thanh toán.
4. Bàn 2 gọi nhân viên; chủ quán phản hồi “Nhân viên đang đến”. Guest xem tab Phản hồi. Bấm nhiều lần cùng loại đang OPEN được UI/server kiểm soát.
5. Bàn 1 yêu cầu tính tiền, chủ quán phản hồi, Xem hóa đơn, Thanh toán & đóng bàn. Phiếu giữ tổng đúng và bàn trở về sẵn sàng.
6. Dừng client/đăng nhập lại: nếu phiên chưa đóng thì thấy đơn đang có. Dừng server: guest báo mất kết nối và nút mutation bị khóa. Chạy lại server cùng DB để chứng minh persistence.
7. Tiếp tục kịch bản contribution tuần 2 bên dưới để kiểm chứng mất phản hồi và phục hồi kết quả.

## Những đoạn cần giải thích được

- FrameCodec: byte length/UTF-8, đọc đủ frame, giới hạn allocation.
- CafeServer: reader pool/queue writer, vì sao một client lỗi không dừng server; auth/per-table snapshots.
- NetworkClient: pending future map, event demultiplexing, heartbeat/timeouts và unknown outcome.
- CafeService: giá server, role checks, transaction, visit lifecycle, payment invariant.
- DashboardFrame: I/O trong SwingWorker và render trên EDT.
- SQLite persistence và seed idempotent khi restart; không reset database người dùng.

## Baseline và contribution

UI realtime/transaction/role là nền kỹ thuật. Tuần 2 đã có receipt nguyên tử và credential gắn lượt. Giải thích vì sao GET_STATE đơn thuần không đủ xác định từng outcome, và vì sao client cũ không được tự nhận quyền lượt khách mới.

## Kết quả test và hạn chế

Surefire reports ở target/surefire-reports; ảnh target/ui-smoke được render từ JFrame thật trong test. UI suite thay câu trả lời modal để có thể kiểm chứng button workflows; vẫn cần người chạy demo trên các máy LAN để xác nhận mạng/firewall/DPI. Smoke script dùng hai JVM và cố ý dừng process của chính nó rồi restart cùng DB; đó không phải chứng minh power-loss durability mọi lúc.
# Demo contribution tuần 2

Cập nhật 20/10/2026. Build lại trước demo. Trong các terminal riêng, từ `cafelink-system`:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/run-server.ps1 -DatabasePath data/recovery-demo.db -Fault drop-order-ack
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/run-client.ps1 -Username admin
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/run-client.ps1 -Username ban1
```

1. Đăng nhập, mở bàn 1, đặt món. Fault chỉ kích hoạt lần đầu: server lưu đơn nhưng khách mất kết nối. Chủ quán vẫn thấy đơn.
2. Khách bấm Đăng nhập lại, dùng cùng host/cổng/tài khoản. Không chọn lượt mới. Client lấy credential/outbox đã lưu, tra outcome và tab Phục hồi hiển thị đã xác nhận. Chủ quán vẫn chỉ có một đơn.
3. Demo khác: chạy server với `-Fault drop-service-before` và DB mới. Gọi nhân viên làm mất kết nối trước tiếp nhận. Đăng nhập lại: tab Phục hồi hiển thị cần xác nhận; chủ quán chưa có ticket. Chỉ khi khách bấm xác nhận mới tạo ticket; hoặc bấm Không gửi nữa để bỏ trước tiếp nhận.
4. Để demo đổi khách: tạo lời gọi chưa nhận, đóng bàn trống rồi mở lại trước khi khách reconnect. Client cũ hiển thị lượt kết thúc, outbox STALE; không thấy dữ liệu khách mới. Khi thật sự đổi người dùng terminal, chọn Bắt đầu lượt khách mới ở login; server kiểm tra lượt cũ đã đóng.

Nếu một tài khoản có cửa sổ cũ đang mở, đóng cửa sổ đó để giải phóng lock journal. Không xóa outbox để né trạng thái chưa rõ. Chỉ dùng mật khẩu demo. Không dùng fault trên phiên vận hành bình thường.

Đối chứng chức năng tự động:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/recovery-experiment.ps1 -Repetitions 3
```

REPLAY_ALL có idempotency và guard lượt giống REVIEW; khác chính sách phục hồi. Xem CSV/metadata/log của mỗi lần chạy. Đây chưa phải benchmark tải/LAN.

## Kiểm chứng tuần 3 và baseline đóng gói

Campaign mở rộng có sáu kịch bản, hai policy, năm lần lặp với thời gian offline 2/10/60 giây:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/recovery-experiment.ps1 -Repetitions 5 -OfflineSeconds '2,10,60' -Parallelism 6
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/benchmark.ps1 -ClientCounts '1,5,10,20' -Repetitions 5 -DurationSeconds 60 -WarmupSeconds 10
```

Chạy hai lệnh nối tiếp. Benchmark có warmup và 60 giây đo/lần; đợi toàn campaign xong, không rebuild JAR giữa các lần. Mỗi lần tạo folder mới nên không ghi đè evidence cũ. Tổng hợp bằng analyzer trong `report/tools/`; bảng/biểu đồ ở `report/evidence/cafelink-original/` sau kiểm chứng.

Bản gốc được đóng gói bằng `scripts/package-original.ps1` sau khi analyzer PASS; kiểm bằng `scripts/verify-package.ps1` trong thư mục đã giải nén. Xem [bàn giao](../../report/CafeLink_Original_Handoff.md) để dùng đúng ZIP baseline. LAN hai máy hiện NOT RUN, dùng [runbook](LAN_ACCEPTANCE.md) khi có thiết bị.

