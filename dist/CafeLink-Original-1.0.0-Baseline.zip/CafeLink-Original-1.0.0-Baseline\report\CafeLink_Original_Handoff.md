# Bàn giao CafeLink bản gốc trước nâng cấp

**Đã hoàn tất các phần kỹ thuật có thể kiểm chứng trên một máy của bản gốc tuần 1–3.** Kết quả: 59/59 test Java (0 failures/errors/skipped), 3 test bộ phân tích Python, 180/180 ca phục hồi, 20/20 lần đo tải với 10,800 request và 0 lỗi. Source giải nén được build/test lại; smoke từ JAR giữ đúng dữ liệu qua restart và khôi phục mất ACK. Chưa triển khai U1–U5.

## Tài liệu và bản chạy

- [Báo cáo dự án](CafeLink_Project_Report.md), [Word tương ứng](CafeLink_Project_Report_Draft.docx).
- ZIP baseline: `dist/CafeLink-Original-1.0.0-Baseline.zip`, gồm source/test/docs, JAR + dependency, báo cáo/evidence, BASELINE.json và SHA256-MANIFEST.csv. Khi đọc từ bản giải nén, thư mục chứa START-HERE.md chính là nội dung ZIP này. Cần JDK, không cần build chỉ để chạy.
- [Tổng hợp evidence](evidence/cafelink-original/summary.json), [raw và chỉ số](evidence/cafelink-original/RESULTS.md), [truy vết yêu cầu](CafeLink_Requirements_Traceability.md).
- [Kiểm chạy bản giải nén và build source](evidence/cafelink-original/package-validation.json). Hash ZIP cuối và lần kiểm runtime của ZIP cuối lưu ngoài archive tại `report/evidence/cafelink-original-release/` để tránh hash tự tham chiếu.

## Kết quả đo thực tế

| Guest | Tổng request | Lỗi | Request/s TB | p50 (ms) | p95 (ms) | Nhận TB (MiB) |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 300 | 0 | 1.00 | 4.64 | 18.40 | 0.18 |
| 5 | 1500 | 0 | 5.00 | 2.68 | 12.50 | 1.58 |
| 10 | 3000 | 0 | 10.00 | 2.60 | 11.36 | 7.63 |
| 20 | 6000 | 0 | 20.00 | 2.89 | 8.64 | 44.81 |

Mỗi mức tải năm lần, 10 giây warmup + 60 giây đo, một request/giây/guest; 20% đặt món và 80% GET_STATE. Server/client ở hai JVM riêng trên loopback. p50/p95 nearest-rank gộp mẫu; từng lần giữ riêng trong [benchmark-runs.csv](evidence/cafelink-original/benchmark-runs.csv). Không xem request/s lịch cố định là công suất tối đa. Traffic là byte ứng dụng guest, gồm frame/event/heartbeat, không gồm admin/TCP/IP.

Gói chạy có vá đọc đồng thời hai pipe trong bước dò JDK trước khởi động; JAR, JVM thực thi và đường xử lý request đã đo giữ nguyên. [Hồ sơ startup patch](evidence/cafelink-original/launcher-startup-patch.json) giữ mã/hash khi đo và diff tới launcher đóng gói. Không đo startup latency; khởi chạy gói sau vá được smoke/build riêng.

180 ca phục hồi gồm hai policy × sáu kịch bản × khoảng offline 2/10/60 giây × năm lần. REVIEW giữ 15 đơn chưa nhận và 15 lời gọi chưa nhận chờ khách xác nhận; REPLAY_ALL tự gửi lại. Riêng lời gọi chưa nhận, REVIEW tạo 0 ticket trước xác nhận mới, REPLAY_ALL tạo 15. Cả hai dùng receipt/idempotency/guard lượt, không ghi nhận đơn trùng hoặc tác dụng sai lượt trong các ca. Không quy toàn bộ hiệu quả chống trùng cho REVIEW; chưa chứng minh nhu cầu thực sự đã hết hoặc policy mới nhanh hơn.

## Các bước đã kiểm thử và báo cáo

| Mốc | Kết quả | Báo cáo |
|---|---|---|
| W3.1 | 59 test Java, thêm ca tài nguyên/ACK/lock/byte | [Part 1](CafeLink_W3_Part1_Report.md) |
| W3.2 | 20 lần đo tải; CSV request, latency/traffic/storage, oracle DB | [Part 2](CafeLink_W3_Part2_Report.md) |
| W3.3 | 180 ca fault/offline, seed và ma trận đối chứng đầy đủ | [Part 3](CafeLink_W3_Part3_Report.md) |
| W3.4 | Manifest, tamper rejection, probe, smoke và build source ở đường dẫn mới ASCII có khoảng trắng | [Part 4](CafeLink_W3_Part4_Report.md) |
| W3.5 | Báo cáo/Word, biểu đồ, local references và truy vết | [Part 5](CafeLink_W3_Part5_Report.md) |

## Chạy bản đóng gói

Giải nén ZIP, vào `cafelink-system`:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/verify-package.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/demo.ps1
```

Admin/CafeLink@123; ban1/Ban1@123, ban2/Ban2@123, ban3/Ban3@123. Chủ quán mở bàn trước khi khách đặt. TCP demo chưa mã hóa; không dùng mật khẩu thật. [README](../cafelink-system/README.md) có build/run riêng, IP/cổng và schema. Không chia sẻ journal sinh ra tại data/client-state vì chứa credential.

Tái chạy phép đo từ source:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/recovery-experiment.ps1 -Repetitions 5 -OfflineSeconds '2,10,60' -Parallelism 6
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/benchmark.ps1 -ClientCounts '1,5,10,20' -Repetitions 5 -DurationSeconds 60 -WarmupSeconds 10
```

Chạy nối tiếp, không rebuild trong campaign. Analyzer cần Python + matplotlib; chạy `--help` để truyền thư mục benchmark/recovery/Surefire/output mới. ZIP giữ baseline có hash để so nâng cấp; các lần chạy mới tạo thư mục mới.

## Phần còn cần điều kiện bên ngoài

- **LAN vật lý hai máy NOT RUN:** hiện chỉ có một máy, đã có [runbook và checklist](../cafelink-system/docs/LAN_ACCEPTANCE.md). Probe localhost không thay LAN.
- **Bìa/thành viên/phân công:** hoãn theo yêu cầu người dùng, không tự bịa dữ liệu. Chưa đổi tên báo cáo theo số nhóm thật.
- **Compilatio/nộp chính thức và xem bố cục Word:** chưa có bằng chứng; cần hoàn tất trước nộp. Word hiện đã kiểm cấu trúc/nội dung/link/ảnh, chưa coi đó là duyệt bố cục trực quan.

Không diễn giải bộ test thành 100% độ phủ dòng mã hoặc không còn mọi lỗi. Chưa chạy runtime JDK17 riêng (đã dùng JDK24.0.2), chưa thử mất điện, Wi-Fi thực, soak dài hạn hoặc khảo sát người dùng quán.

Launcher cần thư mục ASCII, cho phép khoảng trắng. Probe thư mục tiếng Việt **không đạt** trên JDK24/Windows Cp1252, đã giữ log và ghi điều kiện cài đặt trong README; chưa sửa hỗ trợ tên thư mục có dấu. Nội dung message vẫn UTF-8.

## Bắt đầu nâng cấp từ baseline này

[Upgrade Plan](CafeLink_Upgrade_Plan.md) giữ nguyên các gói. Dùng JAR/hash/dataset hiện tại làm E0, không làm lại công cụ đo từ đầu. Ưu tiên U1 quyền vào bàn/resume và U2 phân biệt phục hồi thật sự theo loại; U3/U4 tăng giá trị vận hành. Dữ liệu byte của baseline giúp quyết định U5 giảm snapshot thừa. U6 vẫn còn CI/app-image và nghiệm thu LAN của bản nâng cấp; không coi các bước đó đã xong từ kết quả bản gốc.
