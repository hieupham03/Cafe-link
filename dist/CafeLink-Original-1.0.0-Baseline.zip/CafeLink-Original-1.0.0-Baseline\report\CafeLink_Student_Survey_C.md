# CafeLink: bổ sung khảo sát dự án sinh viên có gọi món theo bàn

Ngày khảo sát: **14/10/2026**. Người thực hiện: agent `cafe_table_survey`. Đây là mẫu bổ sung có chủ đích, không phải mẫu ngẫu nhiên và không đại diện toàn bộ đồ án sinh viên.

## 1. Phạm vi và cách mã hóa

Mục tiêu: tìm dự án có bằng chứng tác giả công khai xác nhận course/final-year/capstone, có đặt món tại bàn và có mã nguồn backend/frontend/schema để kiểm tra contribution dự kiến của CafeLink.

Ba tiêu chí được kiểm tra riêng:

- **R — Phục hồi kết quả chưa biết:** client giữ một request ID ổn định qua reconnect/retry; server lưu kết quả theo ID và hỗ trợ tra cứu kết quả khi phản hồi bị mất. Order ID sinh sau khi nhận yêu cầu và nút chống bấm hai lần chưa đủ.
- **D — Deadline theo ngữ nghĩa:** yêu cầu phục vụ/tính tiền chưa tiếp nhận chỉ có hiệu lực tới deadline, trong khi đơn đã được server chấp nhận vẫn bền vững. Timeout HTTP, thời hạn token đăng nhập, giờ ước tính hoàn thành không được tính.
- **E — Phiên chiếm dụng bàn:** server cấp mã/epoch mới cho mỗi lượt khách; đường thay đổi dữ liệu kiểm tra mã này cùng thao tác cập nhật một cách nguyên tử và chặn thao tác của lượt khách cũ khi đóng/chuyển bàn. `tableId`, order ID, phiên đăng nhập hoặc QR tĩnh không được tính.

`Y`: tìm thấy implementation đáp ứng tiêu chí. `N`: chưa tìm thấy trong đường liên quan đã đọc và schema ở SHA khảo sát; đây là kết luận giới hạn theo phạm vi đọc, không phải chứng minh phủ định tuyệt đối. `U`: chưa đủ mã để kết luận. `—`: tính năng tương ứng không nằm trong phạm vi dự án nên tiêu chí không áp dụng.

## 2. Query log và lựa chọn mẫu

Web search được thực hiện với ba truy vấn:

1. `site:github.com restaurant table ordering "final year" project`
2. `site:github.com restaurant ordering "course project" table`
3. `site:github.com smart restaurant "capstone"`

Ba kết quả được chọn và clone shallow để đọc source, vì mỗi kết quả có bằng chứng học thuật và bàn/ăn tại chỗ. Đã tránh các repo mà nhóm nghiên cứu khác đang đọc: NatasaTM/RestaurantManagingJavaApp, jedrzej-p/self-order, pha123661/Online-Food-Ordering-System, ByteBiteDev/food-ordering-system, aannirajpatel/samosabucket, christian-tapales/Canteen-Express, bhavankumar2911/cafeteria-management-system, karthik-d/cafeteria-management-system, Areyzxc/MangaBrew-Cafe và cặp K23-Smart-Restaurant admin/customer.

Các kết quả không chọn trong lượt này:

- [khawajaacode/little-lemon-website](https://github.com/khawajaacode/little-lemon-website): có chứng nhận capstone nhưng đặt bàn frontend; không có đường đặt món client/server cần khảo sát.
- [juniperus01/College-Canteen](https://github.com/juniperus01/College-Canteen): có final-year evidence nhưng chưa xác minh đặt món gắn một bàn/lượt khách; không đưa vào mẫu bàn.
- [rahilmhd/CAMPUS_BITE](https://github.com/rahilmhd/CAMPUS_BITE): có academic statement nhưng chưa xác minh bàn/lượt khách trong lượt này.
- [Manichandumaddela/campusbite-canteen](https://github.com/Manichandumaddela/campusbite-canteen): README nói phù hợp làm final-year project; phát biểu này tự nó chưa chứng minh đây là đồ án được thực hiện trong một khóa học.
- [markgilmore10/Final-Year-project](https://github.com/markgilmore10/Final-Year-project): bằng chứng học thuật tốt nhưng chưa đọc code trong giới hạn lượt này, nên không dùng để đếm.

Loại trừ ở đây chỉ là giới hạn khảo sát; không được diễn giải rằng các dự án bị loại thiếu contribution.

## 3. Mẫu được đọc

| Dự án | SHA cố định | Bằng chứng học thuật | Tương đồng với CafeLink | R | D | E | Cả bộ |
|---|---|---|---|---|---|---|---|
| sulemaniftikhar/final-year-project | `7174047852d0cda898c791f2074dfd567194368c` | About/API description tự nhận final-year project, code và documentation cộng tác với team/mentors | QR DINEIN, bàn có label, customer/owner, Socket.IO | N | — | N | N |
| user7121/Restaurant-Management-System | `444c890ce0ebee98ad0ed1bcc18f91622c234fdd` | README dòng 3: Academic Group Project, Software Project Management Course | QR table ordering, transactional order creation, table occupied/empty | N | — | N | N |
| tomisin-ogunn/Restaurant-Management-System | `fe59428d28465ca11c0efc16c4254bdf3c10f9d9` | About/API description tự nhận Final Year Project | Khách và waiter đặt món theo bàn; kitchen, customer basket | N | — | N | N |

Nguồn description học thuật: [suleman repo](https://github.com/sulemaniftikhar/final-year-project), [user7121 repo](https://github.com/user7121/Restaurant-Management-System), [tomisin repo](https://github.com/tomisin-ogunn/Restaurant-Management-System). API metadata được lưu thành ba file `report/research-cache/student-c/*-metadata.json`; description là tự khai của tác giả, không phải xác nhận độc lập của trường. Commit source là bất biến, còn About có thể đổi.

## 4. Chi tiết nguồn và đường đã đọc

### 4.1. sulemaniftikhar/final-year-project

Academic evidence: GitHub About/API description. README 65–68 mô tả QR gắn bàn và `DINEIN`.

- [Order mutation](https://github.com/sulemaniftikhar/final-year-project/blob/7174047852d0cda898c791f2074dfd567194368c/backend/controllers/orderController.js#L13-L95): `createOrder` nhận `restaurantId`, `type`, `table`, items; tạo `orderNumber` phía server và insert nested order/items. Trong đường này không có client request-ID hay request outcome ledger. `getOrderById` ở 203–230 yêu cầu order ID đã biết, không giải quyết trường hợp client chưa nhận được ID.
- [Frontend order service](https://github.com/sulemaniftikhar/final-year-project/blob/7174047852d0cda898c791f2074dfd567194368c/frontend/src/services/order.service.js#L3-L19): POST một lần, GET theo order ID. [Cash checkout](https://github.com/sulemaniftikhar/final-year-project/blob/7174047852d0cda898c791f2074dfd567194368c/frontend/src/pages/customer/CartPage.jsx#L219-L241): lỗi được thông báo, không có durable unknown-outcome reconcile trong đoạn này.
- [Reconnect/view status](https://github.com/sulemaniftikhar/final-year-project/blob/7174047852d0cda898c791f2074dfd567194368c/frontend/src/pages/customer/OrderTracking.jsx#L19-L48): lấy trạng thái khi mount, socket `connect` gửi `join_order(id)`. Rejoin socket room được ghi nhận là partial recovery; nó không phải request outcome query.
- [Auth](https://github.com/sulemaniftikhar/final-year-project/blob/7174047852d0cda898c791f2074dfd567194368c/backend/middleware/auth.js#L10-L67): Firebase token xác định user. [API interceptor](https://github.com/sulemaniftikhar/final-year-project/blob/7174047852d0cda898c791f2074dfd567194368c/frontend/src/services/api.js#L14-L43) gắn token, trả lỗi 401. Đây là auth session, không phải lượt khách tại bàn.
- [Schema order](https://github.com/sulemaniftikhar/final-year-project/blob/7174047852d0cda898c791f2074dfd567194368c/backend/prisma/schema.prisma#L192-L226): `Order.table` là string; [schema table](https://github.com/sulemaniftikhar/final-year-project/blob/7174047852d0cda898c791f2074dfd567194368c/backend/prisma/schema.prisma#L302-L315) có label/capacity/isActive, không có visit/current epoch. [Table updates](https://github.com/sulemaniftikhar/final-year-project/blob/7174047852d0cda898c791f2074dfd567194368c/backend/controllers/tableController.js#L61-L95) cập nhật label/capacity/isActive, không phải close/renew occupancy session.
- Service-call/bill-request deadline: không thấy tính năng tương ứng trong các controllers, routes, schema và customer pages đã khảo sát. Mã hóa **D = —**, không đưa vào mẫu số deadline.

### 4.2. user7121/Restaurant-Management-System

- [Academic evidence](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/README.md#L1-L3). README 179–190 mô tả public QR table ordering.
- [Customer POST](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/customer-app/src/api.js#L18-L29): body chỉ gồm table ID và items. [Checkout](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/customer-app/src/components/CartDrawer.jsx#L7-L18): lỗi thông báo rồi đóng drawer. Không tìm thấy stable request-ID hay recovery query.
- [Public mutation](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/backend/controllers/orderController.js#L155-L202) **có** kiểm tra bàn đã có đơn Pending/Preparing và **có** database transaction. Phải ghi nhận hai chức năng này; tuy nhiên, guard không trả lại cùng kết quả theo request-ID, và không phân biệt retry đơn cũ với một yêu cầu mới thật sự.
- [Insert helper](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/backend/controllers/orderController.js#L59-L90): insert order và set table Occupied. [Đóng bàn theo delivered/cancelled](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/backend/controllers/orderController.js#L309-L317): set table Empty; không tăng visit epoch. [Table status update](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/backend/controllers/tableController.js#L39-L61): cập nhật status đơn thuần.
- [Schema](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/database/mysql_rest_core_schema.sql#L28-L51): bàn có table ID/number/status; order có auto-increment ID, table ID/user ID/status. Không thấy occupancy epoch hoặc request ledger trong schema cốt lõi.
- [Public routes](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/backend/routes/publicRoutes.js#L8-L15) chỉ category/product/order creation. [JWT auth](https://github.com/user7121/Restaurant-Management-System/blob/444c890ce0ebee98ad0ed1bcc18f91622c234fdd/backend/middlewares/authMiddleware.js#L11-L39) áp dụng staff/private routes; TTL JWT là auth TTL, không là table visit epoch.
- Service-call/bill-request deadline: chưa có tính năng tương ứng trong paths đọc. **D = —**.

### 4.3. tomisin-ogunn/Restaurant-Management-System

Academic evidence: GitHub About/API description. README giới thiệu customer/waiter/chef/manager; source xác nhận đặt món gắn bàn.

- [Guest order mutation](https://github.com/tomisin-ogunn/Restaurant-Management-System/blob/fe59428d28465ca11c0efc16c4254bdf3c10f9d9/users/views/customer_views.py#L947-L1001) và [logged-in mutation](https://github.com/tomisin-ogunn/Restaurant-Management-System/blob/fe59428d28465ca11c0efc16c4254bdf3c10f9d9/users/views/customer_views.py#L1004-L1063): lấy basket bằng Django session/user, lấy bàn từ POST, sinh order ID phía server và assign kitchen zone; sau đó tách items khỏi basket. Không thấy client request ID+outcome recovery trong hai đường này. Việc basket hết items sau lần đầu là state side effect, không phải contract idempotency trả lại cùng receipt.
- [Table schema](https://github.com/tomisin-ogunn/Restaurant-Management-System/blob/fe59428d28465ca11c0efc16c4254bdf3c10f9d9/restaurant/models.py#L14-L23), [Basket](https://github.com/tomisin-ogunn/Restaurant-Management-System/blob/fe59428d28465ca11c0efc16c4254bdf3c10f9d9/restaurant/models.py#L168-L184), [Order](https://github.com/tomisin-ogunn/Restaurant-Management-System/blob/fe59428d28465ca11c0efc16c4254bdf3c10f9d9/restaurant/models.py#L235-L285): Basket có session ID; Table chỉ capacity/waiter/status available/reserved. Order ID không có ý nghĩa occupancy epoch.
- [Regenerate-session backend](https://github.com/tomisin-ogunn/Restaurant-Management-System/blob/fe59428d28465ca11c0efc16c4254bdf3c10f9d9/users/views/customer_views.py#L53-L57) và [page-load caller](https://github.com/tomisin-ogunn/Restaurant-Management-System/blob/fe59428d28465ca11c0efc16c4254bdf3c10f9d9/users/templates/customers/home.html#L1289-L1295): trang tạo mới Django user session khi tab mở, không do server table turnover và không được atomically checked với table/order mutation. **Không mã hóa E = Y vì thấy từ session.**
- [Kitchen consumer](https://github.com/tomisin-ogunn/Restaurant-Management-System/blob/fe59428d28465ca11c0efc16c4254bdf3c10f9d9/restaurant/consumers.py#L7-L28): join/discard room, broadcast events, không có request outcome ledger. Kitchen template còn polling mỗi hai giây ở 457; polling tự nó không chứng minh contract R.
- Đã kiểm tra thêm waiter views, kitchen views, user URLs, customer templates và keyword recovery. Chưa thấy service-call/bill-request tương ứng; **D = —**.

## 5. Reproduction

Snapshots nằm tại `report/research-cache/student-c/`. Không cài dependencies, không chạy ứng dụng; tất cả findings là static inspection, không phải kết quả thực nghiệm lỗi mạng.

```powershell
git clone --depth 1 https://github.com/sulemaniftikhar/final-year-project.git report/research-cache/student-c/suleman-final-year
git clone --depth 1 https://github.com/user7121/Restaurant-Management-System.git report/research-cache/student-c/user7121-rms
git clone --depth 1 https://github.com/tomisin-ogunn/Restaurant-Management-System.git report/research-cache/student-c/tomisin-rms
# Trong từng repo: git rev-parse HEAD, sau đó đọc các file được nêu ở mục 4.
# Để tái lập sau khi HEAD thay đổi: git fetch origin <SHA>; git checkout --detach <SHA>.
rg -n 'requestId|idempot|retry|reconnect|deadline|expires|epoch|session' backend customer-app/src -g '!package-lock.json'
rg -n 'requestId|idempot|retry|reconnect|deadline|expires|epoch|session' backend frontend/src -g '!package-lock.json'
rg -n 'regenerate|session.flush|session.create|cycle_key' . -g '*.py' -g '!*.pyc'
```

Keyword search chỉ giúp tìm đường đọc, không được dùng một mình để kết luận thiếu tính năng.

## 6. Kết luận có thể sử dụng

Trong **ba dự án sinh viên có đặt món theo bàn đã bổ sung**, chưa quan sát được R hay E ở đường source/schema khảo sát, và chưa quan sát được bộ R+D+E. Đây là bằng chứng hỗ trợ rằng hợp đồng phục hồi đầy đủ có thể tạo khác biệt so với mẫu, **không phải chứng minh nó hiếm trong mọi đồ án**.

Không có mẫu số hợp lệ để tuyên bố deadline phục vụ/tính tiền là 0/3: cả ba chưa có tính năng tương ứng. Phải tìm thêm mẫu có service/bill request nếu muốn đo riêng độ phổ biến D. Khi gộp khảo sát, chỉ gộp **dự án duy nhất**, không gộp từng repo frontend/backend thành mẫu độc lập.

