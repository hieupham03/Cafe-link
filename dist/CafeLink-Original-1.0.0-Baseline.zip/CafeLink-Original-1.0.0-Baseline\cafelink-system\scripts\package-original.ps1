param([string]$OutputDirectory='')
$ErrorActionPreference='Stop'
$projectPath=Split-Path $PSScriptRoot -Parent
$workspacePath=Split-Path $projectPath -Parent
if (-not $OutputDirectory) { $OutputDirectory=Join-Path $workspacePath ('dist\CafeLink-Original-1.0.0-'+[DateTime]::Now.ToString('yyyyMMdd-HHmmss')) }
$destination=[IO.Path]::GetFullPath($OutputDirectory)
if (Test-Path -LiteralPath $destination) { throw "Destination already exists: $destination" }
$reportPath=Join-Path $workspacePath 'report'
$evidencePath=Join-Path $reportPath 'evidence\cafelink-original'
$summary=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $evidencePath 'summary.json') | ConvertFrom-Json
if ($summary.status -ne 'PASS') { throw 'Audited original-baseline evidence is required.' }
$appPath=Join-Path $projectPath 'target\cafelink-1.0.0.jar'
$appHash=(Get-FileHash -LiteralPath $appPath -Algorithm SHA256).Hash
if ($appHash -ne $summary.environment.appJarSha256) { throw 'JAR differs from measured baseline. Reconcile evidence before packaging.' }
$runtimeHash=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'runtime.ps1') -Algorithm SHA256).Hash
if ($runtimeHash -ne $summary.environment.runtimeLauncherSha256) {
    $startupPatch=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $evidencePath 'launcher-startup-patch.json') | ConvertFrom-Json
    if ($startupPatch.measuredRuntimeSha256 -ne $summary.environment.runtimeLauncherSha256 -or $startupPatch.packagedRuntimeSha256 -ne $runtimeHash -or $startupPatch.effectiveJavaExecutable -ne $summary.environment.javaExecutable -or $startupPatch.requestPathUnchanged -ne $true) { throw 'Runtime change lacks matching audited pre-start patch evidence.' }
}
New-Item -ItemType Directory -Path (Join-Path $destination 'cafelink-system\target') | Out-Null
foreach ($name in @('src','scripts','docs','pom.xml','README.md','.gitignore')) {
    $source=Join-Path $projectPath $name
    if (Test-Path -LiteralPath $source) { Copy-Item -LiteralPath $source -Destination (Join-Path $destination 'cafelink-system') -Recurse }
}
Copy-Item -LiteralPath $appPath -Destination (Join-Path $destination 'cafelink-system\target')
Copy-Item -LiteralPath (Join-Path $projectPath 'target\lib') -Destination (Join-Path $destination 'cafelink-system\target') -Recurse
New-Item -ItemType Directory -Path (Join-Path $destination 'report\evidence'),(Join-Path $destination 'report\statics'),(Join-Path $destination 'report\tools') | Out-Null
Get-ChildItem -LiteralPath $reportPath -File | Where-Object { $_.Name -like 'CafeLink*.md' -or $_.Name -eq 'CafeLink_Project_Report_Draft.docx' -or $_.Name -eq 'Contribution_Prior_Art.md' } | Copy-Item -Destination (Join-Path $destination 'report')
foreach ($name in @('cafelink-original','cafelink-week2','cafelink-diagnostics')) {
    $source=Join-Path $reportPath ('evidence\'+$name)
    if (Test-Path -LiteralPath $source) { Copy-Item -LiteralPath $source -Destination (Join-Path $destination 'report\evidence') -Recurse }
}
Get-ChildItem -LiteralPath (Join-Path $reportPath 'statics') -Directory -Filter 'cafelink*' | Copy-Item -Destination (Join-Path $destination 'report\statics') -Recurse
foreach ($name in @('export_cafelink_report.py','analyze_cafelink_experiments.py','test_analyze_cafelink_experiments.py','finalize_cafelink_original_report.py','finalize_cafelink_handoff.py','validate_cafelink_package.py','validate_cafelink_report.py','requirements.txt','README.md')) {
    Copy-Item -LiteralPath (Join-Path $reportPath ('tools\'+$name)) -Destination (Join-Path $destination 'report\tools')
}
New-Item -ItemType Directory -Path (Join-Path $destination 'final-project') | Out-Null
Get-ChildItem -LiteralPath (Join-Path $workspacePath 'final-project') -File -Filter '*.md' | Copy-Item -Destination (Join-Path $destination 'final-project')
[ordered]@{
    name='CafeLink Original'; version='1.0.0'; createdAtUtc=[DateTime]::UtcNow.ToString('o'); schemaVersion=3; wireVersion=1
    appJarSha256=$appHash; tests=$summary.tests; benchmarkCases=$summary.benchmarkCases; recoveryCases=$summary.recoveryCases
    measuredRuntimeLauncherSha256=$summary.environment.runtimeLauncherSha256; packagedRuntimeLauncherSha256=$runtimeHash
    startupPatch='See report/evidence/cafelink-original/launcher-startup-patch.json and launcher-startup.patch; only pre-start Java discovery pipe drain differs, no startup timing claim'
    runtimeVerified='Windows 11 / JDK 24.0.2; Java release target 17, runtime 17 not separately tested'
    networkVerified='Loopback TCP only; physical two-machine LAN NOT RUN (one machine available)'
    sourceProvenance='SHA256-MANIFEST.csv captures all included source, tests, docs and runtime libraries; no Git commit available in this workspace'
    deferred='Group metadata and instructor details intentionally left for user; U1-U5 upgrades not implemented'
} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $destination 'BASELINE.json')
@'
# CafeLink Original 1.0.0

Start in cafelink-system. PowerShell commands:

    powershell -NoProfile -ExecutionPolicy Bypass -File scripts/verify-package.ps1
    powershell -NoProfile -ExecutionPolicy Bypass -File scripts/demo.ps1

JAR and runtime libraries are included; JDK is required. A build is not needed
to run the packaged baseline. See report/CafeLink_Original_Handoff.md and
cafelink-system/docs/LAN_ACCEPTANCE.md for evidence, limitations and LAN setup.
Do not share data/client-state journals created during use: they hold credentials.
SHA256-MANIFEST.csv describes pristine package contents, before runtime data.
'@ | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $destination 'START-HERE.md')
$manifest=@(Get-ChildItem -LiteralPath $destination -File -Recurse | Sort-Object FullName | ForEach-Object {
    [pscustomobject]@{path=$_.FullName.Substring($destination.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
})
$manifest | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $destination 'SHA256-MANIFEST.csv')
$archive=$destination+'.zip'
if (Test-Path -LiteralPath $archive) { throw "Archive already exists: $archive" }
Compress-Archive -LiteralPath $destination -DestinationPath $archive -CompressionLevel Optimal
Get-FileHash -LiteralPath $archive -Algorithm SHA256 | Format-List
Write-Host "BASELINE PACKAGE: $destination"
