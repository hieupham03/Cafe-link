# W1.1 — Nền tảng và protocol

Trạng thái: hoàn thành, 14/10/2026.

Đã tạo project Java 17, Maven bootstrap có kiểm tra SHA-512, DTO và protocol JSON trên TCP với length-prefix 4 byte big-endian. Frame tối đa 256 KiB, đọc đủ khi stream bị chia nhỏ, kiểm tra UTF-8/version/kind/ID/action và cô lập EOF giữa frame. Request ID ở phần này chỉ để tương quan response, chưa là receipt bền vững.

Kiểm thử thực tế: `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/maven.ps1 -B test` tại `cafelink-system`; Maven tải/build thành công. **6 tests, 0 failures, 0 errors, 0 skipped**, suite `FrameCodecTest`. Đã kiểm tra Unicode tiếng Việt, nhiều frame liên tiếp, đọc một byte/lần, header/body bị cắt, length sai/quá lớn, JSON/UTF-8/version sai và outgoing quá kích thước.

Artifact: `cafelink-system/target/surefire-reports/TEST-com.cafelink.common.FrameCodecTest.xml` (có thể được cập nhật ở lần chạy sau). JDK thực tế 24.0.2, bytecode target 17. Maven 3.9.11 bootstrap cục bộ, không sửa PATH máy.

Tiếp theo: schema, xác thực và transaction nghiệp vụ W1.2. Kết quả này chưa chứng minh service/socket/giao diện hoạt động vì các phần đó chưa được triển khai tại mốc W1.1.
