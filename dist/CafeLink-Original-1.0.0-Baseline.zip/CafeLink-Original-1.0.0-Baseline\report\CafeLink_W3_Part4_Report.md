# W3.4 — Đóng gói và nghiệm thu bản gốc

## Thiết kế bộ bàn giao

`scripts/package-original.ps1` chỉ gom source/test/scripts/docs, JAR + runtime dependency, báo cáo và evidence công khai. Không gom `.tools`, clone khảo sát, DB đang vận hành hoặc private journal. Package yêu cầu summary audited PASS và JAR hash khớp chính JAR đo tải.

`BASELINE.json` ghi wire version 1/schema 3, runtime đã kiểm tra, số test/campaign và giới hạn. `SHA256-MANIFEST.csv` ghi hash/kích thước từng file; `scripts/verify-package.ps1` kiểm file thiếu/thay đổi và chặn path vượt thư mục package. SHA-256 ZIP lưu trong release record bên ngoài archive, tránh tự tham chiếu hash của chính nó.

`report/tools/validate_cafelink_package.py` giải nén sang **đường dẫn mới ASCII có khoảng trắng**, kiểm manifest, thử sửa README để xác nhận validator từ chối, khôi phục rồi kiểm lại. Sau đó kiểm probe cổng mở/cổng đóng, chạy smoke bình thường và recovery từ chính JAR giải nén, kiểm manifest vẫn đúng, cuối cùng build source giải nén và chạy suite đầy đủ. Chỉ dừng các process do smoke tạo.

Đây là thư mục sạch trên cùng máy Windows/JDK, có dùng dependency cache của người dùng; không phải cài Windows mới hoặc chứng minh build offline. Bản chạy đã kèm dependency nên không cần Maven/Internet chỉ để mở ứng dụng, nhưng vẫn cần JDK.

## LAN

Kiểm path sạch còn phát hiện dò JDK đọc stdout rồi stderr có thể deadlock khi pipe stderr đầy. Đã đổi riêng bước dò trước khởi động sang ReadToEndAsync cho cả hai pipe. JAR, JVM chạy server/client, cờ khởi động và xử lý request không đổi; campaign không đo startup latency. Mã lúc đo + diff và hash trước/sau nằm trong `evidence/cafelink-original/launcher-startup-patch.json`/`launcher-startup.patch`. Gói cuối được smoke/build sau vá; không viết lại hash launcher cũ trong metadata campaign.

Thử thư mục có dấu tiếng Việt không đạt: JDK24 trên máy kiểm tra dùng native.encoding=Cp1252 và tham số classpath bị mất ký tự. Manifest file vẫn đúng; CLI trực tiếp từ JDK cũng tái hiện, còn classpath tương đối ASCII tải được lớp. Đây là giới hạn launcher đã xác định, **chưa sửa hỗ trợ đường dẫn có dấu**. Điều kiện nghiệm thu cuối là thư mục ASCII có khoảng trắng; README/runbook ghi rõ. Log ca không đạt giữ tại `target/original-package-validation-r2/`; không gộp nó vào PASS.

Người dùng chỉ có một máy: **nghiệm thu LAN vật lý NOT RUN**. `docs/LAN_ACCEPTANCE.md` có cấu hình bind/IP/cổng, checklist chín ca và vị trí lưu bằng chứng; `scripts/lan-check.ps1` chỉ là probe TCP, không thay nghiệm thu nghiệp vụ. Script không sửa firewall.

## Kết quả kiểm chạy

**PASS.** Giải nén ở đường dẫn ASCII có khoảng trắng, manifest đúng, README sửa bị từ chối rồi khôi phục đúng; probe cổng mở PASS và cổng đóng bị từ chối như mong đợi. Smoke thường giữ ba đơn/190.000 VND/một ticket HANDLED qua restart; recovery smoke giữ một đơn/30.000 VND, journal PENDING→RESOLVED qua JVM mới.

Build source trong thư mục giải nén đạt **59 tests, 0 failures/errors/skipped**. Dùng cùng Windows/JDK24 và cache dependency trên máy, không claim môi trường OS sạch hoặc build offline. [Kết quả máy đọc được](evidence/cafelink-original/package-validation.json); log sạch của source build và smoke lưu kèm evidence.

ZIP cuối cùng có cùng JAR/source nhưng báo cáo được cập nhật sau kiểm chứng candidate. ZIP cuối được kiểm lại manifest/probe/smoke; release record ngoài archive ở `evidence/cafelink-original-release/` ghi hash chính ZIP cuối và kết quả thực tế. Không ghi hash ZIP vào chính file bên trong ZIP.
