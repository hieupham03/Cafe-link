# Đối chiếu bằng chứng kiểm thử và contribution: TOEIC Monitoring và CafeLink

Ngày đọc: 20/10/2026. Phạm vi: đọc tĩnh source, test và artifact đã công bố; không chạy ứng dụng, Maven, Docker hoặc thực nghiệm của nhóm bạn. Chỉ tạo tài liệu này; không sửa hai hệ thống.

Repo đối chiếu: `AnhTaizz/Toeic-Monitoring-Realtime`, checkout tại `report/research-cache/peer-toeic-monitoring-20261020`; `git rev-parse HEAD` trả **`d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a`** (merge PR #86). Các liên kết bên dưới cố định tại commit này. Khi evidence ghi source cũ, phải giữ source cũ đó thay vì gán thành kết quả của HEAD.

CafeLink đối chiếu theo source và evidence tuần 2 trong workspace. Nhận định dưới đây không phải chấm điểm học phần, kiểm chứng độc lập việc nhóm bạn đã chạy máy thật hay kết luận độ phổ biến trên toàn bộ đồ án sinh viên.

## 1. Nhóm TOEIC có bộ kiểm thử rộng và bằng chứng được quản lý kỹ hơn, nhưng không thể so chất lượng bằng số test

Evidence MON-07 mới nhất ghi full verify ở source `1b84d30`: **1.336 test invocation = 1.192 PASS + 144 SKIP, không failure/error**. Focused run cuối ở `1c008c8` có **334 PASS/0 SKIP**, gồm 29 invocation của pipeline PostgreSQL. Đây là hai lựa chọn kiểm thử chồng lắp; không cộng 1.192 với 334. Source của lượt đo được ghi riêng với runtime/test SHA và hash artifact.

Nguồn: [bảng lượt chạy MON-07](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/evidence/c-mon07-status-gap-20261020/REPORT.md#L69-L89), [receipt có source SHA và case thực thi](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/evidence/c-mon07-status-gap-20261020/receipt.json#L1-L29).

CafeLink có [49 test đạt, không skip](evidence/cafelink-week2/test-summary.json), cộng thực nghiệm chức năng riêng. TOEIC có số test lớn hơn rất nhiều và quy trình CI/provenance rõ hơn. Tuy nhiên, hai hệ thống khác phạm vi; parameterized invocation, unit test và GUI/DB integration cũng khác sức nặng. Không có cơ sở chuyển tỷ lệ số test thành tỷ lệ chất lượng hoặc điểm số.

## 2. CI xanh của TOEIC không đồng nghĩa toàn bộ PostgreSQL và GUI đã chạy

Workflow dùng Windows/Java 21 chạy `mvn clean verify`, kiểm LAN kit bằng MOCK và Python analyzer test. Chính source test quy định PostgreSQL cần `TOEIC_PG_INTEGRATION=true`, JavaFX cần các biến opt-in riêng. Báo cáo MON-07 cũng ghi full verify không bật PG và phân tách 144 SKIP. Vì vậy cần đọc focused DB/GUI evidence bên cạnh CI.

Nguồn: [workflow CI](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/.github/workflows/pr-ci.yml#L16-L46), [PG opt-in trong pipeline test](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/test/java/vn/edu/toeic/server/monitoring/signal/SignalPipelinePostgresTest.java#L38), [GUI opt-in và MOCK source](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/client/src/test/java/vn/edu/toeic/client/proctor/redesign/ProctorRedesignGuiTest.java#L17-L18).

Đây là giới hạn được nhóm bạn công khai, không phải bằng chứng rằng toàn bộ integration của họ chưa chạy: evidence 19/10 có PostgreSQL và GUI thật trên một máy. CafeLink nên học cách ghi rõ môi trường, số skip và phạm vi từng lệnh.

## 3. Đã có đóng gói và chạy một máy thật; LAN hai máy vẫn là phần chưa nghiệm thu

Evidence Phase 3 ghi build source `cfbba58`, Windows/Oracle 21/PostgreSQL thật: clean test và package mỗi lượt **942 PASS/4 SKIP**; installed MSI suite **943 PASS/3 SKIP**. Có MSI version/hash, kiểm cài đặt đường dẫn Unicode, bundled JVM và gỡ ứng dụng. Đây là bằng chứng triển khai sâu hơn script chạy JAR của CafeLink.

Tuy vậy, handoff vẫn ghi **LAN vật lý 0/41**, nghe audio thủ công và MSI trên máy thứ hai `NOT RUN`. Các ca ngắt mạng trong bộ kiểm một máy dùng lỗi SIMULATED; không thay kết quả rút cáp/Wi-Fi giữa hai máy. Không được lấy hai loại kết quả này lẫn nhau.

Nguồn: [môi trường, kiểm thử, MSI và giới hạn](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/evidence/stage3-execution-20261019/REPORT.md#L5-L31), [handoff vật lý còn thiếu](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/docs/STAGE3_FINAL_HANDOFF.md#L1-L11).

CafeLink hiện cũng [chưa benchmark tải/LAN nhiều máy](CafeLink_Week2_Handoff.md#L49). Vì vậy không thể kết luận dự án nào chịu tải LAN tốt hơn.

## 4. Contribution full/delta của TOEIC đã có code, nhưng lợi ích tiết kiệm mạng chưa được chứng minh bằng E2

TOEIC đã triển khai epoch, sequence/base, ACK/retry, resync, freshness và delta reducer; không nên mô tả các thành phần này chỉ là kế hoạch. Tuy nhiên, server vẫn đặt `delta-enabled:false`, và báo cáo tích hợp giữ FULL mặc định, DELTA experimental, E2 chưa chạy. Bộ đo byte chỉ tính chuỗi JSON UTF-8 ở WebSocket; không bao gồm HTTP, handshake, framing, TCP/IP, TLS và retransmission.

Nguồn: [cờ mặc định trong code](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/main/java/vn/edu/toeic/server/monitoring/MonitoringStateService.java#L53), [resync/retry/freshness đã mô tả theo source](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/docs/MONITORING_SYNC_REPORT_DRAFT.md#L59-L77), [E2 và physical gate chưa chạy](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/docs/MONITORING_SYNC_REPORT_DRAFT.md#L127-L141), [định nghĩa byte](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/docs/MONITORING_MEASUREMENTS.md#L7-L13).

Kết luận hợp lệ: đã có cơ chế đồng bộ thử nghiệm và kiểm tra tính đúng trong các ca đã chọn. Chưa hợp lệ: delta tiết kiệm X% tổng băng thông hoặc làm hệ thống nhanh hơn CafeLink. CafeLink cũng chưa đo chi phí snapshot đầy đủ, receipt/outbox và phục hồi để đưa ra đối chiếu hiệu năng trực tiếp.

## 5. Có thực nghiệm E1 lịch sử, nhưng bảng CPU cũ cần phân tích lại

Repo lưu E1 lịch sử **12 run/360 trial**, trong đó 287 observed, 62 missed và 11 unknown; khảo sát đánh đổi chu kỳ quét process với khả năng quan sát và tài nguyên. Đây là công sức thực nghiệm thực sự được tài liệu hóa, không phải chỉ có đề xuất.

Nhưng review 16/10 phát hiện analyzer lấy trung bình phần trăm CPU theo từng interval thay vì tổng CPU chia tổng thời gian. Tài liệu yêu cầu phân tích lại resource của toàn bộ 12 run; raw 84 file nguồn cũ không có trong phiên review. Ngày 20/10 đã bổ sung derived join/provenance, **27 Python test PASS** và một REAL smoke 3 trial, nhưng vẫn ghi `E1_ACCEPTANCE_PENDING`, raw lịch sử `NOT_AVAILABLE` và không chạy lại campaign 12 lượt.

Nguồn: [E1 lịch sử và phạm vi metric](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/evidence/overnight-20261015/phase-06/e1/analysis.md#L1-L17), [finding công thức và raw thiếu](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/evidence/t4-c1/2026-10-16-review.md#L20-L28), [yêu cầu reanalysis](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/evidence/t4-c1/2026-10-16-review.md#L57-L65), [kết quả tooling mới và giới hạn](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/evidence/c-e1-derived-20261020/REPORT.md#L43-L64).

Vì vậy không nên dùng bảng CPU lịch sử để khẳng định chu kỳ polling nào tốt nhất. E1 là collector/harness offline, cũng không phải benchmark hệ thống thi nhiều client hay phép đo full/delta mạng.

## 6. Không thể lấy idempotency và epoch làm điểm riêng có của CafeLink khi đối chiếu nhóm này

Trong `ExamService`, nhóm TOEIC đã có row lock theo attempt, `writerEpoch`, `savedRevision`, bảng request autosave/submit và phát hiện retry bằng request ID/nội dung. Luồng monitoring còn có ACK, retry giữ identity, conflict khi cùng ID khác nội dung. Các kỹ thuật cùng họ với receipt/idempotency/fencing của CafeLink đã hiện diện ở nhóm bạn.

Nguồn: [row lock và stale writer](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/main/java/vn/edu/toeic/server/exam/ExamService.java#L176-L213), [idempotency và lưu autosave request](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/main/java/vn/edu/toeic/server/exam/ExamService.java#L271-L344).

Phần khác biệt có thể trình bày của CafeLink là **hợp đồng phục hồi ý định phục vụ theo trạng thái đã tiếp nhận và lượt khách, có UI xác nhận/bỏ trước tiếp nhận cùng outbox đĩa**. MonitoringDelivery của TOEIC tự mô tả queue RAM, không disk queue; khác biệt này chỉ áp dụng module đó, không đủ để nói toàn repo TOEIC không có lưu cục bộ. [Giới hạn queue trong source](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/client/src/main/java/vn/edu/toeic/client/monitoring/MonitoringDelivery.java#L29-L30). Cơ chế CafeLink xem [protocol tuần 2](../cafelink-system/docs/PROTOCOL.md#L51).

Đây là khác biệt ngữ nghĩa và phạm vi thiết kế; chưa chứng minh thuật toán mới hoặc độ hiếm trên toàn bộ bài tập lớn.

## 7. CafeLink có đối chứng chức năng trực tiếp và gọn hơn; kết luận hiện tại vẫn hẹp

[CSV CafeLink](evidence/cafelink-week2/results.csv) có 24 ca = 2 chính sách × 4 kịch bản × 3 lần lặp. Hai bản cùng receipt/idempotency/guard. Trong kịch bản lời gọi chưa được tiếp nhận, REPLAY_ALL tự tạo ticket ở 3/3 ca; REVIEW giữ chờ xác nhận ở 3/3 ca. Cả hai đều không tạo đơn trùng và tác dụng sai lượt trong các kịch bản tương ứng.

Đây là bằng chứng so sánh **chính sách xác nhận lại ý định**, chưa chứng minh chính sách REVIEW làm giảm đơn trùng hơn chính bản REPLAY_ALL vốn đã có idempotency. Chưa có B0 bỏ guard, thời gian mất mạng dài/ngắn, benchmark tải hoặc mẫu đủ để suy luận latency. [Metadata](evidence/cafelink-week2/metadata.json) ghi rõ loopback TCP, server/client cùng JVM với socket riêng và recoveryMs gồm authentication/journal I/O.

Ngoài ra, bản CafeLink thu hẹp hiện yêu cầu xác nhận lại **cả đơn đặt món lẫn lời gọi chưa nhận**; khác biệt theo loại chủ yếu nằm ở thông báo, chưa phải hai chính sách phục hồi khác nhau rõ rệt và không có TTL. Vì vậy tên contribution nên nhấn mạnh trạng thái tiếp nhận và lượt khách; không diễn giải rằng đã tự động đánh giá tuổi/độ cần thiết của từng lời gọi. Đây là điểm cần siết diễn đạt hoặc bổ sung thực nghiệm, không nên che bằng cách tăng số tính năng.

Trong phạm vi đã đọc, TOEIC có độ rộng kiểm thử, giao dịch và công cụ thực nghiệm lớn hơn; CafeLink có câu chuyện nghiệp vụ và phép đối chứng tập trung dễ giải thích hơn. Hai dự án đều còn phần nghiệm thu mạng thực tế và không có số đo cùng workload/môi trường để xếp hạng hiệu năng. Việc nên làm tiếp cho CafeLink là bổ sung thực nghiệm tải/LAN, chi phí receipt/outbox và ablation từng cơ chế; không cần mở rộng nghiệp vụ để chạy theo số lượng tính năng của nhóm bạn.

## Ghi chú về diễn giải nguồn

- Các mốc README/review lịch sử có thể ghi PR chưa merge, migration còn xung đột hoặc test count cũ. Checkout hiện tại đã là merge PR #86 và có migration V17; không dùng release review cũ để kết luận HEAD vẫn bị chặn merge.
- PASS trong tài liệu công bố là kết quả do repo ghi nhận. Phiên đối chiếu này không tự chạy lại suite và không có raw private/ignored để xác minh mọi hash.
- Không cộng các cumulative test count, focused subset, lặp lại và package rerun thành số test độc lập; không gọi SKIP/NOT RUN là PASS.
