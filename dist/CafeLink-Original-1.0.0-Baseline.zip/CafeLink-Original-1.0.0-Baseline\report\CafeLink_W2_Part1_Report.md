# W2.1 – Receipt bền vững và tra cứu kết quả

Hoàn thành 20/10/2026. Lệnh kiểm tra: `scripts/maven.ps1 -B test` tại `cafelink-system`. Kết quả tại mốc: **32 tests, 0 failures/errors/skipped**, gồm 27 test tuần 1 và 5 `CommandReceiptTest` mới.

Server lưu ID, principal, fingerprint SHA-256 của action/payload và kết quả thành công trong `command_receipts`, cùng transaction với thay đổi nghiệp vụ/revision. Cùng ID và nội dung trả kết quả cũ, không tăng revision; đổi nội dung trả COMMAND_CONFLICT. Object key được sắp xếp khi fingerprint, thứ tự array vẫn có ý nghĩa. Chỉ outcome thành công được lưu; lỗi nghiệp vụ/database rollback và trả lỗi rõ ràng, không tạo receipt thành công.

Protocol có GET_OUTCOME và client có requestWithId. Đã kiểm thử replay, principal isolation, thay đổi payload, service restart, 8 bản gửi đồng thời và trigger làm lỗi INSERT receipt để chứng minh rollback cả đơn/revision. Có migration bổ sung bảng vào DB tuần 1, không xóa dữ liệu.

Đây là nền W2.1, chưa phải toàn bộ C1/C2: cần giới hạn principal bằng credential của lượt, outbox, reconnect và fault injection TCP ở các phần tiếp theo. Artifact Surefire trong target sẽ được thay bằng kết quả mới khi chạy phần sau; số 32 là kết quả tại mốc này.
