package com.cafelink.common;

import java.util.List;

public final class Models {
    private Models() { }
    public record Identity(String username, String role, Integer tableId, String credential) { }
    public record MenuItem(int id, String name, long priceVnd, String category) { }
    public record TableView(int id, String name, String visitId, String status, int onlineClients) { }
    public record OrderItem(int menuId, String name, int quantity, long unitPriceVnd, long subtotalVnd) { }
    public record OrderView(long id, int tableId, String visitId, String status, String note, long totalVnd, String createdAt, List<OrderItem> items) { }
    public record Ticket(long id, int tableId, String visitId, String type, String status, String note, String reply, String createdAt) { }
    public record Bill(String visitId, int tableId, long totalVnd, List<OrderView> orders) { }
    public record Snapshot(long revision, List<MenuItem> menu, List<TableView> tables, List<OrderView> orders, List<Ticket> tickets) { }
}
