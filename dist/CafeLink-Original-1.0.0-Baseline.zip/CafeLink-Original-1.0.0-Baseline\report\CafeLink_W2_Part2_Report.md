# W2.2 – Quyền phục hồi gắn với lượt khách

Hoàn thành 20/10/2026. `scripts/maven.ps1 -B test`: **36 tests, 0 failures/errors/skipped**. Bổ sung 4 GuestSessionTest và cập nhật UI test đổi lượt để xác nhận client cũ vẫn bị khóa sau khi mở lượt mới.

Schema 3 bổ sung guest_credentials: server trả credential ngẫu nhiên, chỉ lưu SHA-256; reconnect dùng mật khẩu + credential cũ. Credential đang chờ được bind khi mở lượt đầu, kể cả client không kịp đọc snapshot; credential đã bind không chuyển lượt. Guest snapshot chỉ hiển thị lượt có quyền. Mutation kiểm tra cùng khóa/transaction với đóng/mở. Receipt principal gồm tài khoản và hash credential: khách mới không tra outcome của credential cũ, credential cũ vẫn tra kết quả đã nhận sau khi lượt đóng.

Đã kiểm thử chờ/mất toàn bộ lượt đầu, lượt mới, resume qua service restart, credential giả/của tài khoản khác, không tự fallback, replay outcome đã nhận sau đóng lượt và migration DB schema 1 giữ visit. Tài khoản bàn dùng chung vẫn cho người biết mật khẩu chủ động xin credential mới; đây là mô hình terminal demo, không phải xác minh danh tính con người.

Phát hiện class trung gian của Java language server nằm trong target/classes: javap hiển thị constructor `AdminFrame(..., Dialogs)` với tên kiểu không đúng namespace. Maven đã tưởng output mới nên không compile lại, dẫn tới testCompile lỗi. Tách output Maven sang target/maven-classes và maven-test-classes; build lại toàn bộ pass. Chưa có outbox/recovery UI ở mốc này.
