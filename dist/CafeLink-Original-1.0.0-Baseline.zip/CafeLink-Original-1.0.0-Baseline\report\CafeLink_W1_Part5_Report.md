# W1.5 — Tích hợp, đóng gói và bàn giao

Trạng thái: hoàn thành, 14/10/2026.

## Deliverables

Build/runtime/server/client/demo/smoke PowerShell scripts; packaged jar + runtime dependency jars; README setup/LAN/accounts/workflow/limitations; protocol, architecture/ADR và hướng dẫn demo. Không cần Maven cài toàn hệ thống; bootstrap kiểm tra archive hash. Các script được parse bằng PowerShell AST: **7/7 không lỗi syntax**.

Bổ sung kiểm thử login GUI qua form thật, xóa nháp khi đổi lượt khách, race thanh toán với đơn mới và lỗi database giữa chừng. Với simulated SQLite trigger failure ở bước INSERT order_items sau INSERT order, TCP trả DATABASE_ERROR; order/revision rollback và cùng guest connection tiếp tục đặt thành công. Không mock service/network/database ở test này.

## Kiểm thử cuối cùng

`powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build.ps1` tại `cafelink-system`: **BUILD SUCCESS, 27 tests, 0 failures, 0 errors, 0 skipped**.

| Suite | Tests | Đặc điểm |
|---|---:|---|
| FrameCodecTest | 6 | Framing/UTF-8/partial reads/lỗi/giới hạn |
| CafeServiceTest | 7 | Quyền, giá server, nghiệp vụ/phiên, persistence, bàn trống |
| NetworkIntegrationTest | 10 | TCP thật, nhiều client, events/isolation, race và DB rollback |
| UiWorkflowTest | 4 | Swing actions/form thật + TCP/SQLite; chỉ thay câu trả lời modal |

Các report XML thực tế: `cafelink-system/target/surefire-reports/TEST-*.xml`. Môi trường JDK 24.0.2 Windows, compile target Java 17. Không tuyên bố đã chạy trên một JDK 17 runtime riêng.

## Smoke packaged app ở hai JVM

`scripts/smoke.ps1` chạy ServerMain headless trong một process và DemoSmokeMain trong process khác. Dùng DB mới/cổng tạm, không thay DB người dùng. Tạo 3 guest sockets trên 3 bàn, 3 đơn, một ticket xử lý. Dừng server process của script và restart cùng DB; trạng thái vẫn đúng, guest chỉ đọc bàn mình.

Kết quả thực tế:

```json
{"status":"PASS","mode":"populate","orders":3,"totalVnd":190000,"handledTickets":1}
{"status":"PASS","mode":"verify-restart","orders":3,"totalVnd":190000,"handledTickets":1}
```

Artifact gốc: `cafelink-system/target/smoke-5d9e7ec88cab4ff39f996d2f933a558a/` (DB, stdout/stderr server và JSON results). Runtime stderr server rỗng trong lần smoke. Đây là persistence sau dừng tiến trình có kiểm soát, không là chứng minh durability cho mọi mất điện. Package dùng jar thay vì target/classes; dependency jars đã được kiểm tra có trong target/lib.

## Giao diện và lỗi đã xử lý

Đã xem ảnh render JFrame thật và lưu bản ở `report/statics/cafelink-week1`. Spinner số lượng dễ đọc hơn, commit/validate khi đặt. Khi đổi phiên, xóa nháp/ghi chú/hóa đơn khỏi màn hình guest. Fail refresh sau response không che mất mutation đã được ACK. Native-access warnings ở test dưới JDK 24 đã ghi nhận; launch script runtime cấp native access cho SQLite.

## Giới hạn và công việc tiếp theo

Baseline tuần 1 hoàn thành, chưa triển khai durable receipt/outbox/outcome query hoặc automatic replay theo loại request. Auth bàn cố định chưa là session-bound credential của contribution. Các test chạy localhost; chưa khảo sát firewall/hardware/network trên nhiều máy. Không có benchmark baseline/proposed hoặc số liệu novelty giả. Tuần 2 triển khai đúng các contribution trong kế hoạch, trên nền workflow tuần 1 đã kiểm chứng.
