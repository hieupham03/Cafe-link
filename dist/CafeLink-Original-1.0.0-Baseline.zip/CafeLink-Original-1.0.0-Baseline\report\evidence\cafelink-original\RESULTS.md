# Kết quả đo bản gốc CafeLink

Dữ liệu và oracle SQLite đã đối chiếu tự động; xem summary.json và database-oracle.csv.

| Khách | Số mẫu | Lỗi | Request/s trung bình | p50 (ms) | p95 (ms) | Đặt món p95 (ms) | GET_STATE p95 (ms) |
|---|---|---|---|---|---|---|---|
| 1 | 300 | 0 | 1.00 | 4.64 | 18.40 | 20.87 | 6.42 |
| 5 | 1500 | 0 | 5.00 | 2.68 | 12.50 | 14.94 | 3.71 |
| 10 | 3000 | 0 | 10.00 | 2.60 | 11.36 | 13.43 | 3.54 |
| 20 | 6000 | 0 | 20.00 | 2.89 | 8.64 | 11.28 | 3.97 |

Mỗi mức tải chạy 5 lần × 60 giây, warmup 10 giây, 1 request/giây/khách (mỗi slot thứ năm đặt món). p50/p95 nearest-rank gộp mẫu; từng lần giữ trong benchmark-runs.csv. Đây là tải chủ động quy định, chưa đo công suất tối đa.

Campaign phục hồi: 180 ca, 2 policy × 6 kịch bản × 3 khoảng offline × 5 lần. REVIEW tạo 0 ticket chưa được khách xác nhận lại; REPLAY_ALL tạo 15. Cả hai có idempotency/guard lượt. Không đo độ hài lòng hoặc lượng nhu cầu thực sự hết hiệu lực.

Traffic là byte ứng dụng của guest gồm header frame/event/heartbeat; không gồm admin/TCP/IP. Timing phục hồi gồm login PBKDF2 và journal, chạy các ca song song nên chỉ là số mô tả. NORMAL không chờ offline. LAN vật lý hai máy: NOT RUN.
