# W1.2 — Dữ liệu, xác thực và nghiệp vụ

Trạng thái: hoàn thành, 14/10/2026.

SQLite/JDBC có schema version 1, foreign keys, WAL và transaction; seed 6 bàn, 8 đồ uống, 1 tài khoản chủ quán và 6 khách. Mật khẩu PBKDF2-HMAC-SHA256 có salt. CafeService giữ lock cho truy cập connection/state, tính giá VND tại server và kiểm tra quyền/bàn/phiên. Đã có mở bàn, đặt món, chuyển trạng thái, ticket và trả lời, hóa đơn, thanh toán mô phỏng và đóng phiên. Không giữ lock trong socket I/O ở thiết kế phần sau.

Kiểm thử: `scripts/maven.ps1 -B test`, **12 tests pass, 0 failures/errors/skipped**: 6 protocol + 6 service. Service tests kiểm tra login sai/SQL-like username, role và phạm vi bàn; workflow đầy đủ; client giả giá; yêu cầu trùng loại; chưa phục vụ/ticket chưa xử lý không được thanh toán; input phân số/món không tồn tại không để lại đơn hay tăng revision; chuyển trạng thái sai; restart giữ phiên/đơn và phiên cũ bị từ chối sau mở lại.

Lỗi đã sửa: test sử dụng biến được gán lại trong lambda, gây compile failure; tách payload riêng cho hai case và chạy lại thành công. Không thay đổi code nghiệp vụ để né test. JDK 24 phát cảnh báo native-access của SQLite; đây không phải test failure, script chạy app sẽ cho phép native access rõ ràng.

Giới hạn: service tests gọi trực tiếp, chưa chứng minh TCP hoạt động. Request receipt/outbox của contribution chưa triển khai. Các quy tắc phiên hiện tại là nền schema/nghiệp vụ của baseline; thực nghiệm contribution sẽ có phiên bản đối chứng riêng tuần 2.
