# Đối chiếu CafeLink với TOEIC Monitoring Realtime

Ngày đối chiếu: **20/10/2026**. Peer: [AnhTaizz/Toeic-Monitoring-Realtime](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime), cố định tại commit **`d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a`**. CafeLink: mã nguồn hiện có trong workspace, trạng thái bàn giao tuần 2, 49 test và 24 ca đối chứng chức năng.

Phương pháp: đọc mã nguồn, cấu hình, tài liệu và artifact được lưu. Không chạy Maven/Docker/app/installer của repo TOEIC, không xác nhận độc lập số test tác giả công bố. Không dùng số commit, số dòng mã hoặc số test làm thang điểm chất lượng. Không sửa hoặc đưa code peer vào CafeLink. Repo được clone riêng tại `report/research-cache/peer-toeic-monitoring-20261020` để tra cứu. Đánh giá khả dụng giao diện dựa vào hình đã lưu, không phải một phiên dùng thử trực tiếp.

## 1. Nhận định chính

**Repo TOEIC có phạm vi chức năng và nhiều cơ chế mạng sâu hơn CafeLink hiện tại.** Không nên mô tả họ như một ứng dụng CRUD có gắn WebSocket: đã có ACK sau commit, idempotency, reconnect có giới hạn, epoch cho quyền ghi/đồng bộ, FULL/DELTA/resync, heartbeat/presence và giám sát tiến trình. Nguồn: [WebSocket handler](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/main/java/vn/edu/toeic/server/realtime/RealtimeWebSocketHandler.java), [ExamService](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/main/java/vn/edu/toeic/server/exam/ExamService.java), [state reducer](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/protocol/src/main/java/vn/edu/toeic/protocol/monitoring/MonitoringStateReducer.java).

**CafeLink có phạm vi gọn, socket tự triển khai dễ kiểm tra và một bài toán phục hồi ý định nghiệp vụ cụ thể.** Journal trên đĩa, receipt và credential theo lượt đã có implementation/test. Đây là cơ sở để xây dựng bài bảo vệ tốt; chưa đủ để tuyên bố CafeLink hơn repo kia về fault tolerance nói chung. Nguồn: [Outbox](../cafelink-system/src/main/java/com/cafelink/client/Outbox.java), [service](../cafelink-system/src/main/java/com/cafelink/server/CafeService.java), [recovery tests](../cafelink-system/src/test/java/com/cafelink/server/RecoveryIntegrationTest.java).

Không thể kết luận điểm số của hai nhóm nếu chưa cùng chạy demo, đo workload tương đương và kiểm tra mức hiểu mã của các thành viên. Theo [rubric đề xuất của học phần](../final-project/Instruction.md), network implementation 25%, contribution 15%, experiment 15%, demo/bảo vệ 15%; thêm nghiệp vụ không tự thay thế các phần này.

## 2. Bảng so sánh

| Tiêu chí | TOEIC Monitoring Realtime | CafeLink | Nhận xét |
|---|---|---|---|
| Bài toán | Thi Reading/Listening, lưu đáp án, điều khiển ca, monitoring | Gọi món, tiến độ, phục vụ, tính tiền mô phỏng | TOEIC rộng và nhiều trạng thái hơn; CafeLink dễ giới hạn trong ba tuần |
| Kiến trúc | Maven nhiều module; JavaFX, Spring Boot/JDBC, PostgreSQL/Flyway | Một Maven project, package common/server/client; Swing, JDBC/SQLite | TOEIC tổ chức và vận hành nhiều thành phần hơn; CafeLink ít bước cài đặt |
| Kênh mạng | HTTP/REST + raw WebSocket với envelope riêng | TCP Socket + JSON UTF-8 có length-prefix | Cả hai đúng hướng môn học; dùng framework không làm mất giá trị lập trình mạng |
| Giao thức | Message/request/trace/attempt ID, ACK/ERROR, FULL/DELTA/RESYNC | Request/response/event, ID/fingerprint, GET_OUTCOME/DISCARD_COMMAND | CafeLink mạnh ở framing; TOEIC có nhiều semantics đồng bộ hơn |
| Mất kết nối | Bounded backoff/reconnect, retry event, kiểm ACK và scope | Reconnect chủ động, lookup outcome, xác nhận ý định chưa nhận | Khác mục tiêu, không có bên thắng tuyệt đối ở mọi tình huống |
| Lưu yêu cầu chưa xác nhận | MonitoringDelivery là queue RAM | Guest outbox atomic trên đĩa | CafeLink có điểm nhấn rõ về journal sống qua JVM restart; chỉ so với đúng lane monitoring |
| Chống trùng/quyền cũ | Event ID, receipt autosave, writerEpoch/syncEpoch | Receipt, fingerprint, credential gắn lượt bàn | Hai bên đều có, không dùng làm claim chỉ CafeLink có |
| Trạng thái realtime | Phân biệt state RAM, event DB, presence, gap; delta opt-in | Snapshot đầy đủ theo quyền và revision | TOEIC phân loại trạng thái phong phú hơn |
| Đồng thời | Spring transactional/JDBC, row locks tại đường ghi đáp án | Reader pool/queue mỗi peer; khóa service tuần tự hóa SQLite | Không suy throughput từ công nghệ; cần benchmark |
| Xác thực | Bearer session, expiry/revocation và kiểm lại từng WS message | Password + credential theo lượt, chưa expiry/revocation UI | TOEIC có vòng đời auth đầy đủ hơn trong source đã đọc |
| Giao diện | JavaFX dashboard/thi/nghe; có bộ redesign render với dữ liệu MOCK | Swing sáu bàn, đơn/ticket/hóa đơn và phục hồi | Nhận định hình đã xem: TOEIC trình bày phong phú hơn; ảnh MOCK không chứng minh chạy toàn luồng |
| Kiểm thử/đóng gói | Nhiều suite/evidence; có hồ sơ MSI local và nhiều test opt-in | 49 test, hai loại smoke tiến trình, 24 ca đối chứng | TOEIC có phạm vi kiểm thử rộng hơn; không so chất lượng bằng tổng test |
| Thực nghiệm còn thiếu | FULL/DELTA chưa đủ nghiệm thu hiệu quả; LAN vật lý còn NOT RUN theo hồ sơ | Chưa tải/LAN nhiều máy/chi phí byte/storage; 24 ca là sơ bộ | Cả hai chưa có căn cứ khẳng định toàn bộ mục tiêu hiệu năng |

Nguồn kiến trúc và luồng sản phẩm: [POM peer](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/pom.xml), [unified app](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/docs/UNIFIED_APPLICATION.md), [README CafeLink](../cafelink-system/README.md). Các mục sâu được chứng minh ở phần tiếp theo.

## 3. Điểm mạnh kỹ thuật của peer đã đọc trong source

### 3.1. ACK không chỉ là gửi socket thành công

MonitoringEventService.store dùng transaction, khóa/kiểm scope lượt, INSERT ON CONFLICT theo attempt/event ID và đối chiếu nội dung. Handler ACK sau service transactional trở về. Đây là cơ chế chống trùng và xác nhận lưu bền vững tương đồng nền tảng receipt của CafeLink, dù dữ liệu nghiệp vụ khác. Nguồn: [MonitoringEventService.java](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/main/java/vn/edu/toeic/server/monitoring/MonitoringEventService.java#L17), [handler](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/main/java/vn/edu/toeic/server/realtime/RealtimeWebSocketHandler.java).

### 3.2. Quyền ghi và phiên bản đã được xét trong nghiệp vụ thi

ExamService.autosaveAnswers kiểm writerEpoch/revision, khóa dòng attempt FOR UPDATE và lưu exam_autosave_requests trong transaction; request ID dùng với payload khác bị CONFLICT. Không thể nói CafeLink khác biệt chỉ vì có session hoặc request ID. Nguồn: [ExamService.java, autosaveAnswers](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/main/java/vn/edu/toeic/server/exam/ExamService.java#L147), [client ExamSession](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/client/src/main/java/vn/edu/toeic/client/exam/ExamSession.java).

### 3.3. FULL/DELTA có logic đồng bộ thực sự

MonitoringStateReducer kiểm collector/epoch, sequence/baseSequence, digest và duplicate; delta thiếu base trả RESYNC, không áp bừa lên trạng thái mới. Cache dedup tối đa 64 ID trong RAM. Đây là logic protocol có thể giải thích được trong môn lập trình mạng, không đơn thuần một framework broadcast. Tuy nhiên, implementation và correctness test không tự chứng minh tiết kiệm tài nguyên. Nguồn: [MonitoringStateReducer.java](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/protocol/src/main/java/vn/edu/toeic/protocol/monitoring/MonitoringStateReducer.java#L13), [báo cáo đồng bộ](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/docs/MONITORING_SYNC_REPORT_DRAFT.md).

### 3.4. Auth và reconnect được xử lý sâu

SessionAuthenticationService kiểm revoked/enabled/expires; WS handler xác thực lại trước parse/nghiệp vụ. RealtimeClient là adapter có timeout/bounded retries và phân tuyến ACK. CafeLink đã có role/credential, nhưng chưa có cùng bộ cơ chế thu hồi/hết hạn session. Nguồn: [SessionAuthenticationService.java](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/server/src/main/java/vn/edu/toeic/server/auth/SessionAuthenticationService.java#L24), [RealtimeClient.java](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/client/src/main/java/vn/edu/toeic/client/realtime/RealtimeClient.java).

## 4. Điểm CafeLink có thể bảo vệ cụ thể

### 4.1. Ý định guest được ghi trước gửi và sống qua lần chạy ứng dụng

Outbox ghi temporary file, force và atomic move; giữ ID/payload/credential và lock file. Mất ACK rồi restart client/server vẫn tra được đúng một đơn. Có [recovery populate](evidence/cafelink-week2/recovery-populate.json), [recovery restart](evidence/cafelink-week2/recovery-restart.json) và [RecoverySmokeMain](../cafelink-system/src/main/java/com/cafelink/client/RecoverySmokeMain.java).

Đối chiếu đúng lane: [MonitoringDelivery của peer](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/client/src/main/java/vn/edu/toeic/client/monitoring/MonitoringDelivery.java#L29) ghi rõ RAM delivery/no disk queue. Đây là khác biệt triển khai có bằng chứng, nhưng không suy ra toàn bộ ứng dụng TOEIC không phục hồi hoặc không lưu đáp án: server của họ có DB và cơ chế đối soát riêng.

### 4.2. Nhu cầu phục vụ có thể cần xác nhận lại

Khách từng bấm gọi nhân viên trong lúc mất mạng không có nghĩa vẫn cần khi quay lại. CafeLink không tự replay ý định chưa nhận; nếu đã nhận thì lấy outcome, nếu sai lượt thì STALE. DISCARD_COMMAND tạo dấu bỏ để handler đến muộn không hồi sinh ý định. Đây là tình huống nghiệp vụ dễ demo và làm rõ vì sao giao lại message chưa đồng nghĩa phục hồi đúng nhu cầu. Nguồn: [NetworkClient.recover](../cafelink-system/src/main/java/com/cafelink/client/NetworkClient.java), [CafeService.discard](../cafelink-system/src/main/java/com/cafelink/server/CafeService.java).

Đối chứng hiện có đều giữ idempotency và guard: [24 dòng CSV](evidence/cafelink-week2/results.csv) cho thấy ba ca lời gọi chưa nhận: REPLAY_ALL tạo ba ticket, REVIEW tạo không ticket và giữ ba ca cần xác nhận. Hai bản đều không tạo đơn trùng hoặc tác dụng sai lượt trong các ca tương ứng. Không gọi đây là kết quả TTL, không tuyên bố hiệu quả trên quán thực tế.

### 4.3. Phạm vi nhỏ giúp demo và giải thích xuyên suốt

Một luồng đặt món đi từ frame bytes → identity → validation → transaction → receipt → response/event → Swing. Nhóm có thể giải thích bằng một bài toán ít trạng thái hơn thi/nghe/monitoring. Đây là ưu điểm quản lý phạm vi và bảo vệ, không phải bằng chứng mới hơn hoặc điểm cao hơn. CafeLink cũng chưa là ứng dụng khách quét QR/browser; Swing là lựa chọn demo desktop đã chốt.

## 5. Những điểm CafeLink đang yếu và phải nói thẳng

1. **Nhãn “theo loại” hiện mạnh hơn khác biệt policy đã cài.** Trong NetworkClient.recover, PLACE_ORDER và CALL_SERVICE/REQUEST_BILL chưa nhận đều CONFIRM_REQUIRED; khác nhau chủ yếu ở câu giải thích. Chưa có TTL/grant, chưa có cơ chế tự replay theo cửa sổ hiệu lực. Nên phát biểu contribution là “phục hồi ý định chưa rõ kết quả theo trạng thái tiếp nhận và lượt bàn, có xác nhận lại nhu cầu” cho khớp code. Không thêm TTL chỉ để có tên gọi nếu không còn thời gian đánh giá.
2. **Không thể dùng chống trùng/epoch làm bằng chứng độc quyền.** Peer đã có các cơ chế tương đương ở event, autosave và state sync. Giá trị CafeLink nằm ở bài toán/contract cụ thể và thực nghiệm, không ở việc đổi exam attempt thành visit bàn.
3. **Bằng chứng đánh giá còn nhỏ.** 49 test xác nhận các tình huống đã xét; 24 ca chức năng với ba lần lặp không đủ kết luận median/p95, throughput hoặc độ bền trong mọi sự cố. B1/B2 cùng guard nên chưa đo riêng tác dụng C2.
4. **Vòng đời auth và ứng dụng thực tế còn giới hạn.** Shared table password vẫn cho người biết mật khẩu xin credential khác bằng client mới; chưa TTL/revocation credential, TLS, web/QR hoặc phân trang. Đây là điều kiện terminal demo cần công khai.

## 6. Không đánh giá quá mức những phần peer chưa nghiệm thu

Peer có implementation và hồ sơ kiểm thử rộng hơn, nhưng tài liệu chính họ phân biệt code-ready/local test với nghiệm thu: FULL mặc định, DELTA experimental; E2 chưa đủ kết quả chứng minh hiệu quả; physical LAN còn NOT RUN trong các hồ sơ đã đọc. Ví dụ [báo cáo stage3 ngày 19/10](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/evidence/stage3-execution-20261019/REPORT.md) ghi 942 PASS/4 SKIP và installed 943 PASS/3 SKIP ở source cfbba58, không phải lượt chạy độc lập trên HEAD hiện tại.

Ảnh dashboard redesign tại [verification](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/docs/ui-proctor-redesign/VERIFICATION.md) là JavaFX render thật với fixture MOCK; không dùng ảnh đó để xác nhận PostgreSQL/LAN đã hoạt động. USB/focus/display có các phần experimental/off trong [tiến độ](https://github.com/AnhTaizz/Toeic-Monitoring-Realtime/blob/d2c8f01ca2063aa10d797c86e1c1e7e2b62d273a/docs/TIEN_DO.md), không gộp tất cả thành chức năng production đã nghiệm thu. [Hồ sơ kiểm tra bằng chứng riêng](CafeLink_Toeic_Evidence_Review.md) ghi rõ các nguồn/mốc.

## 7. Ưu tiên đề xuất cho CafeLink

Giữ đề tài và hoàn thành đánh giá thay vì mở thêm nghiệp vụ để chạy đua số tính năng. Các ưu tiên sau là đề xuất, chưa được triển khai trong lần đối chiếu này:

1. Chỉnh câu contribution cho đúng policy thực tế; làm rõ journal bền vững, outcome chưa rõ, xác nhận ý định và guard lượt.
2. Hoàn thành workload 1/5/10/20 client, thời gian phục hồi median/p95 với mẫu đủ, lỗi/timeout, byte/storage và số lần khách cần xác nhận. Không benchmark mù để tìm số đẹp.
3. Tách bằng chứng cho từng cơ chế: idempotency chống lặp; guard chống sai lượt; review tránh tự phát nhu cầu chưa xác nhận; journal giữ ý định qua JVM restart. Không quy mọi lợi ích cho một chữ “retry”.
4. Demo LAN hai máy và một kịch bản mất ACK sau commit, đóng/mở bàn trong lúc offline. Lưu raw log/ID/outcome; kiểm tra trình tự nhìn thấy trên hai giao diện.
5. Làm rõ giao diện thông báo chưa rõ kết quả, đã nhận, cần xác nhận và lượt kết thúc. Có thể cải thiện bố cục; không cần chuyển JavaFX/Spring hoặc thêm web/QR vào sát hạn chỉ để giống peer.

Kết luận đánh giá: **TOEIC hiện mạnh hơn về phạm vi và độ đa dạng cơ chế mạng; CafeLink có hướng riêng hẹp và dễ chứng minh hơn nếu hoàn thành thực nghiệm và trình bày contribution đúng mức.** Chưa có cơ sở cho tuyên bố CafeLink đã mạnh hơn hoặc sẽ được điểm cao hơn repo kia.
