# CafeLink – Hệ thống gọi món và điều phối phục vụ tại quán café theo mô hình Client/Server sử dụng TCP Socket

**BÁO CÁO BÀI TẬP LỚN MÔN LẬP TRÌNH MẠNG**  
Năm học: 2026–2027  
Trường/Khoa: **[CẦN ĐIỀN]**  
Giảng viên hướng dẫn: **[CẦN ĐIỀN]**  
Lớp học phần: **[CẦN ĐIỀN]**  
Nhóm: **[CẦN ĐIỀN]**  
Ngày cập nhật: **21/10/2026**

| STT | Họ và tên | Mã sinh viên | Phần việc thực tế | Bằng chứng thực hiện |
|---|---|---|---|---|
| 1 | [CẦN ĐIỀN] | [CẦN ĐIỀN] | [CẦN ĐIỀN] | Commit/file/báo cáo |

**Trạng thái bản thảo:** bản gốc tuần 1–3 đã hoàn tất các phần kiểm chứng được trên một máy: 59 test đạt, 20 lần đo tải và 180 ca phục hồi. Có dữ liệu thô, biểu đồ, oracle SQLite và bộ đóng gói baseline. LAN vật lý hai máy chưa chạy; bìa/thành viên hoãn theo người dùng. Compilatio và thủ tục nộp chưa thực hiện. Xem [bàn giao bản gốc](CafeLink_Original_Handoff.md). Các gói nâng cấp U1–U5 vẫn là đề xuất.

## Tóm tắt (Abstract)

CafeLink giải quyết gọi món và điều phối phục vụ cho một quán café theo mô hình Client/Server. Client Swing giao tiếp TCP Socket bằng JSON có tiền tố độ dài; server xác thực, lưu SQLite và chủ động gửi cập nhật. Receipt nguyên tử, outbox ghi trước gửi và credential gắn lượt giúp lấy lại kết quả sau mất phản hồi, yêu cầu khách xác nhận ý định chưa được nhận và chặn yêu cầu của lượt cũ. Bản gốc đạt 59 test; 20 lần đo tải 1/5/10/20 guest trên loopback ghi nhận 10,800 request, 0 lỗi; 180 ca phục hồi ở khoảng offline 2/10/60 giây đạt. Trong 15 ca lời gọi chưa nhận của mỗi policy, REVIEW không tự tạo ticket, REPLAY_ALL tạo 15 ticket trước khi khách xác nhận lại. Hai policy cùng idempotency/guard và không ghi nhận đơn trùng hoặc tác dụng sai lượt trong các ca đã xét. Kết quả hỗ trợ tính đúng của hợp đồng phục hồi trong phạm vi thực nghiệm; chưa đo LAN vật lý, công suất tối đa hoặc hiệu quả tại quán thực tế.

**Từ khóa:** Client/Server; TCP Socket; giao thức ứng dụng; xử lý đồng thời; phục hồi kết nối; phiên sử dụng bàn.

## Mục lục

1. Giới thiệu
2. Kiến thức nền và các giải pháp liên quan
3. Định nghĩa bài toán và yêu cầu hệ thống
4. Phương pháp đề xuất
5. Kiến trúc hệ thống
6. Thiết kế giao tiếp mạng
7. Triển khai hệ thống
8. Thiết lập kiểm thử và thực nghiệm
9. Kết quả
10. Thảo luận
11. Điểm đóng góp và bằng chứng
12. Hạn chế
13. Hướng phát triển
14. Kết luận
15. Tài liệu tham khảo
16. Phụ lục

## 1. Giới thiệu

### 1.1. Bối cảnh và động lực

Trong phạm vi bài toán được chọn, khách tại bàn cần gửi đơn và yêu cầu phục vụ, còn chủ quán cần tiếp nhận, phản hồi và cập nhật tiến độ. Nếu mỗi màn hình chỉ lưu trạng thái cục bộ, khách và chủ quán có thể thấy dữ liệu khác nhau. Vì vậy, server giữ trạng thái chính thức và gửi cập nhật đến các client được phép truy cập.

CafeLink tập trung vào giao tiếp mạng thay vì mở rộng nghiệp vụ quản lý kinh doanh. Hệ thống cho phép quan sát trực tiếp một yêu cầu đi từ màn hình khách qua socket đến server, được lưu vào database rồi xuất hiện trên màn hình chủ quán. Luồng phản hồi diễn ra theo chiều ngược lại. Cách tổ chức này đáp ứng yêu cầu học phần về giao thức, nhiều client, trạng thái dùng chung và xử lý lỗi [1].

### 1.2. Vấn đề cần giải quyết

Ngoài luồng hoạt động bình thường, nhóm xét ba tình huống: server đã lưu đơn nhưng client mất phản hồi; yêu cầu gọi nhân viên chưa được tiếp nhận trở nên không còn cần thiết sau thời gian mất mạng; và bàn được chuyển sang lượt khách mới trong khi client cũ còn yêu cầu đang chờ. Chỉ kết nối lại hoặc gửi lại mọi yêu cầu không đủ để xác định thao tác nào vẫn phù hợp với trạng thái nghiệp vụ.

### 1.3. Mục tiêu và phạm vi

Mục tiêu thứ nhất là xây dựng ứng dụng Client/Server chạy được từ đầu đến cuối, có xác thực, phân quyền, cập nhật chủ động và lưu dữ liệu. Mục tiêu thứ hai là thiết kế, triển khai và kiểm chứng cơ chế phục hồi theo loại yêu cầu và lượt khách.

Phạm vi gồm một quán, sáu bàn, tám đồ uống, hai vai trò ADMIN và GUEST, giao diện desktop và thanh toán tiền mặt mô phỏng. Vai trò ADMIN đại diện chủ quán/nhân viên vận hành; chưa tách quyền nhân viên riêng. Không đưa vào bản đầu quản lý kho, khuyến mãi, nhiều chi nhánh, sửa/hủy món, thanh toán trực tuyến hoặc gọi món bằng QR trên web.

### 1.4. Định hướng đóng góp

Đóng góp C1 là đối chiếu kết quả trước khi gửi lại và xét trạng thái tiếp nhận/loại ý định để phục hồi hoặc yêu cầu xác nhận. Bản thu hẹp yêu cầu xác nhận cho cả đơn và lời gọi chưa nhận, với thông báo theo loại; không claim TTL. C2 ràng buộc quyền với lượt bàn. Đây là thiết kế ứng dụng dựa trên kỹ thuật đã có; trạng thái và bằng chứng tại mục 11.

## 2. Kiến thức nền và các giải pháp liên quan

### 2.1. TCP và giao thức ứng dụng

TCP cung cấp luồng byte tin cậy, có thứ tự trong một kết nối [3]. Luồng byte không cung cấp sẵn ranh giới thông điệp cho ứng dụng; do đó CafeLink sử dụng tiền tố độ dài để phân biệt các bản tin JSON. Một lần đọc socket có thể chỉ nhận được một phần bản tin, nên codec phải đọc đủ header và body.

Độ tin cậy của TCP không đồng nghĩa với việc client biết chắc một thao tác nghiệp vụ đã được commit. Nếu kết nối mất sau commit nhưng trước khi nhận phản hồi ứng dụng, client vẫn chưa rõ kết quả. Khôi phục kết quả và chống tạo thao tác trùng cần cơ chế riêng ở tầng ứng dụng.

### 2.2. Xác thực, phiên kết nối và lượt sử dụng bàn

CafeLink phân biệt ba khái niệm: tài khoản quyết định vai trò và bàn được truy cập; kết nối TCP là kênh giao tiếp đang hoạt động; lượt sử dụng bàn (`visitId`) là một lần phục vụ khách từ khi mở đến khi đóng bàn. Mất kết nối không kết thúc lượt khách. Một lượt có thể tồn tại qua nhiều lần kết nối lại.

Tuần 2 bổ sung credential opaque do server cấp, lưu hash và gắn với một lượt. Reconnect dùng credential cũ, không tự chuyển lượt. Người biết mật khẩu bàn vẫn có thể chủ động đăng nhập mới qua client khác: đây là mô hình terminal demo, chưa xác minh danh tính khách dùng thiết bị cá nhân.

### 2.3. Các cơ chế có tiền lệ

| Cơ chế/nguồn | Nội dung liên quan | Ý nghĩa đối với CafeLink |
|---|---|---|
| Stripe – Idempotent requests [4] | Dùng khóa để nhận lại kết quả của yêu cầu lặp | ID ổn định và chống lặp không phải phát minh của nhóm |
| AWS – Making retries safe [5] | Ràng buộc ID với ý định và xử lý yêu cầu gửi lại | Cần kiểm tra nội dung và lưu kết quả cùng thay đổi dữ liệu |
| MQTT 5.0 [6] | Có thời hạn hiệu lực cho message | Expiry là kỹ thuật đã có; cần định nghĩa đúng hiệu lực nghiệp vụ |
| Fencing token [7] | Từ chối thao tác mang quyền/phiên bản cũ tại nơi ghi | Guard lượt bàn là ứng dụng của cơ chế kiểm tra phiên |

Các nguồn trên là tiền lệ kỹ thuật, không phải số liệu chứng minh mức phổ biến trong đồ án sinh viên. Phân tích chi tiết nguồn và giới hạn diễn giải nằm trong [CafeLink_Prior_Art_Detail.md](CafeLink_Prior_Art_Detail.md).

### 2.4. Khảo sát dự án học tập

Khảo sát ngày 14/10/2026 đã đọc mã nguồn tại các commit cố định của 12 dự án: 11 dự án tự mô tả là đồ án sinh viên/môn học và một dự án cuối khóa đào tạo lại Java làm đối chứng. Hai repository Admin/Customer của K23 được tính là một dự án. Phương pháp, truy vấn, SHA, file nguồn và bằng chứng được lưu trong Survey A/B/C [8–10].

| Tiêu chí được khảo sát | Số mẫu sinh viên áp dụng | Kết quả trong luồng mã đã đọc |
|---|---:|---|
| ID lệnh được giữ qua gửi lại và server có receipt/tra cứu kết quả chưa rõ | 11 | Chưa ghi nhận mẫu đáp ứng đầy đủ |
| Phiên riêng cho lượt khách, kiểm tra nguyên tử với thao tác đóng/mở bàn | 5 | Chưa ghi nhận mẫu đáp ứng đầy đủ |
| Hiệu lực yêu cầu phục vụ chưa được nhận được xét khi phục hồi | 1 | Chưa ghi nhận; mẫu quá ít để kết luận về độ phổ biến |

Đây là mẫu có chủ đích, không đại diện mọi bài tập lớn. “Chưa ghi nhận” chỉ áp dụng cho các luồng và schema đã đọc, không chứng minh tính năng hoàn toàn vắng mặt. Kết quả định hướng khoảng trống thiết kế trong mẫu; không chứng minh CafeLink là hệ thống đầu tiên hoặc cơ chế mới trên thế giới.

## 3. Định nghĩa bài toán và yêu cầu hệ thống

### 3.1. Mô hình và giả định

Server chạy trên máy của quán và là nơi duy nhất truy cập SQLite. Client chủ quán và các client khách kết nối bằng địa chỉ IP/cổng TCP. Máy chủ quán có thể chạy đồng thời server và client quản trị, nhưng thao tác nghiệp vụ quản trị vẫn đi qua TCP. Dữ liệu hiển thị ở client là bản sao của trạng thái được server cho phép đọc.

Khách dùng tài khoản được gán cho bàn; chủ quán mở lượt trước khi nhận đơn. Nhân viên xác nhận các trạng thái pha chế/phục vụ bằng thao tác trên giao diện. Phần mềm không tự quan sát hay bảo đảm hành động phục vụ vật lý diễn ra đúng một lần.

### 3.2. Đầu vào, đầu ra và ràng buộc

Đầu vào gồm thông tin đăng nhập, mã bàn/lượt, danh sách mã món và số lượng, ghi chú, trạng thái đơn và phản hồi yêu cầu. Đầu ra gồm kết quả thao tác, mã lỗi, đơn hàng, yêu cầu phục vụ, hóa đơn và snapshot theo quyền.

Các ràng buộc chính: mỗi bàn có tối đa một lượt đang hoạt động; guest chỉ truy cập bàn được gán; server tự lấy giá món; số lượng là số nguyên 1–20; mỗi món có một dòng trong đơn; tối đa 20 dòng/đơn; ghi chú/phản hồi tối đa 500 ký tự. Tiền được tính bằng số nguyên VND. Thanh toán chỉ được ghi khi có đơn, tất cả đơn đã phục vụ và không còn ticket OPEN.

### 3.3. Yêu cầu chức năng

| Mã | Yêu cầu | Trạng thái |
|---|---|---|
| F01 | Đăng nhập, phân quyền ADMIN/GUEST tại server | Đã triển khai |
| F02 | Chủ quán mở bàn và cấp lượt sử dụng mới | Đã triển khai |
| F03 | Khách xem menu, chọn số lượng và đặt món | Đã triển khai |
| F04 | Chủ quán xem đơn và cập nhật tiến độ | Đã triển khai |
| F05 | Khách gọi nhân viên, yêu cầu tính tiền | Đã triển khai |
| F06 | Chủ quán phản hồi; khách nhận phản hồi | Đã triển khai |
| F07 | Xem hóa đơn, thanh toán mô phỏng và đóng bàn | Đã triển khai |
| F08 | Hiển thị số client khách đang kết nối theo bàn | Đã triển khai |
| F09 | Server chủ động gửi cập nhật theo quyền | Đã triển khai |
| F10 | Giữ dữ liệu nghiệp vụ qua restart server | Đã kiểm thử trong phạm vi mục 9 |
| F11 | Tra cứu kết quả lệnh chưa rõ sau mất phản hồi | Đã triển khai receipt/GET_OUTCOME |
| F12 | Outbox bền vững và phục hồi theo loại yêu cầu | Đã triển khai; ý định chưa nhận cần xác nhận |
| F13 | Xác thực ràng buộc lượt và chặn replay cũ | Đã triển khai credential/guard nguyên tử; có test |

Theo dõi online ở F08 là số kết nối, không phải danh sách thiết bị đã xác minh. Tạo tài khoản/menu trên GUI, buộc đăng xuất client và chat tự do chưa nằm trong bản triển khai.

### 3.4. Yêu cầu phi chức năng

Hệ thống phải xử lý nhiều client mà không cho guest đọc dữ liệu bàn khác, giữ nhất quán khi các thao tác cạnh tranh, cô lập kết nối gửi frame sai và không khóa giao diện trong lúc chờ mạng. Hàng đợi gửi và số worker được giới hạn để tránh tăng tài nguyên không kiểm soát. Các yêu cầu định lượng về độ trễ/throughput sẽ được đánh giá bằng thực nghiệm; hiện chưa có ngưỡng hiệu năng được xác nhận.

## 4. Phương pháp đề xuất

### 4.1. Giải pháp baseline đã triển khai

Client gửi lệnh; server xác thực danh tính của kết nối, kiểm tra quyền và dữ liệu, thực hiện transaction nghiệp vụ, rồi trả kết quả và gửi snapshot mới. Database giữ trạng thái chính thức. Revision tăng khi mutation thành công và không tăng khi rollback. Client bỏ snapshot có business revision nhỏ hơn revision đã biết.

Baseline không tự gửi lại mutation khi timeout. Người dùng đăng nhập lại và tải trạng thái hiện hành để kiểm tra. Cách này tránh tự phát lại một thao tác chưa rõ kết quả, nhưng chưa cung cấp công cụ xác định kết quả của từng lệnh và chưa đáp ứng mục tiêu phục hồi C1/C2.

### 4.2. C1 – Phục hồi yêu cầu

Client ghi ID và payload bất biến vào outbox trước gửi. Receipt server được ghi cùng transaction nghiệp vụ/revision, có principal, command ID, action, fingerprint SHA-256 và result. Guest principal gồm tài khoản và hash credential gắn lượt. Cùng ID/nội dung trả outcome cũ; dùng ID cho nội dung khác bị COMMAND_CONFLICT. Object key được canonical theo thứ tự, array giữ thứ tự; retry giữ nguyên biểu diễn payload.

Khi người dùng đăng nhập lại, client resume credential đã lưu, lấy snapshot và GET_OUTCOME. Outcome khớp fingerprint được phục hồi, không tạo lệnh mới. Lookup không thay thế unique key/transaction vì handler cũ có thể còn đang xử lý.

| Loại | Đã nhận, mất phản hồi | Chưa được nhận |
|---|---|---|
| Đặt món | Lấy kết quả đơn và snapshot | Chờ khách xác nhận còn muốn đặt |
| Gọi nhân viên/tính tiền | Lấy ticket đã có | Chờ khách xác nhận còn cần phục vụ |

Bản thu hẹp yêu cầu xác nhận lại cả đơn và lời gọi chưa nhận, với thông báo theo loại. Không có TTL/grant và không đo tuổi yêu cầu. Ý định sai lượt được đánh dấu STALE. DISCARD_COMMAND lưu dấu bỏ nguyên tử nếu chưa nhận, chặn handler cũ đến muộn; nếu đã nhận thì trả outcome cũ. Đây là bỏ ý định trước tiếp nhận, không hủy món đã lưu.

### 4.3. C2 – Quyền phục hồi gắn lượt khách

Credential đang chờ được bind khi mở lượt đầu, kể cả client không kịp đọc snapshot. Đã bind thì không chuyển lượt. Kiểm tra credential/lượt và ghi mutation dùng cùng khóa/transaction với đóng/mở bàn. Guest cũ không thấy snapshot lượt mới, vẫn tra receipt của chính nó; guest mới dùng credential khác không tra được receipt cũ.

START_NEW_VISIT chỉ cấp quyền mới khi lượt cũ đã đóng; client yêu cầu journal đã giải quyết. Không xóa token cục bộ để tự bind lại. Shared table password vẫn là mô hình terminal demo. Xem [ADR-002](../cafelink-system/docs/architecture/ADR-002-recovery.md).

### 4.4. Bất biến kiểm chứng

Cùng ID/nội dung không tạo thêm tác dụng; ý định cũ không chuyển sang lượt mới; ý định chưa nhận không tự replay trong GUI; outcome đã nhận vẫn tra được. CommandReceiptTest, GuestSessionTest và RecoveryIntegrationTest kiểm tra các tình huống này, gồm restart, lỗi ghi receipt và lookup/replay cạnh tranh handler cũ. Test hữu hạn không phải chứng minh cho mọi lịch thực thi.

## 5. Kiến trúc hệ thống

### 5.1. Thành phần và kết nối

```text
Client khách (Swing) -------- TCP --------+
                                        |
Client chủ quán (Swing) ----- TCP --------+--> CafeServer
                                               |
                                          CafeService
                                               |
                                           Database
                                               |
                                            SQLite

Server console: vận hành listener, log và mở client quản trị.
```

**Hình 1.** Kiến trúc baseline. Client không truy cập database trực tiếp.

| Thành phần | Trách nhiệm |
|---|---|
| `common` | DTO, JSON, định dạng Message, FrameCodec và tham số CLI |
| `server/CafeServer` | Accept socket, danh tính kết nối, phân tuyến lệnh, phản hồi và server push |
| `server/CafeService` | Kiểm tra quyền, ràng buộc nghiệp vụ, transaction và snapshot |
| `server/Database` | SQLite connection, schema, truy vấn chuẩn bị sẵn và seed |
| `client/NetworkClient` | Một reader, future theo request ID, heartbeat và event listener |
| `client/ui` | Đăng nhập, giao diện chủ quán/khách, tương tác trên Swing EDT |

### 5.2. Quyết định và đánh đổi

TCP Socket và Swing được chọn để tập trung vào lập trình socket và chạy nhiều client trong thời gian ngắn. JSON có tiền tố độ dài giúp kiểm tra rõ giao thức và partial reads. SQLite giảm công việc cài đặt server database. Ghi nghiệp vụ được tuần tự hóa trong `CafeService`, phù hợp dữ liệu nhỏ nhưng giới hạn khả năng mở rộng. Server gửi snapshot đầy đủ thay vì delta, giúp client hội tụ trạng thái nhưng tăng lượng dữ liệu truyền.

Các quyết định đầy đủ nằm trong [ARCHITECTURE.md](../cafelink-system/docs/ARCHITECTURE.md). Không coi lựa chọn này là bằng chứng TCP nhanh nhất hoặc hệ thống đã đáp ứng triển khai nhiều quán.

### 5.3. Mô hình dữ liệu

| Bảng | Khóa và dữ liệu chính | Ràng buộc đáng chú ý |
|---|---|---|
| `cafe_tables` | `id`, `name` | Sáu bàn seed |
| `accounts` | `username`, `password_hash`, `role`, `table_id` | Vai trò ADMIN/GUEST; table FK |
| `visits` | `id`, `table_id`, `active`, `opened_at`, `closed_at` | Unique partial index: một lượt active/bàn |
| `menu` | `id`, `name`, `price_vnd`, `category` | Giá dương |
| `orders` | `id`, `visit_id`, `status`, `note`, `created_at` | Trạng thái hợp lệ |
| `order_items` | `order_id`, `menu_id`, `name`, `quantity`, `unit_price_vnd` | PK ghép; lưu tên/giá khi đặt; quantity 1–20 |
| `tickets` | `id`, `visit_id`, `type`, `status`, `note`, `reply`, `created_at` | Một ticket OPEN mỗi loại/lượt |
| `payments` | `id`, `visit_id`, `total_vnd`, `method`, `paid_at` | Một payment/lượt; CASH_SIMULATED |
| `metadata` | `name`, `value` | Business revision |

```text
cafe_tables 1 ---- N visits 1 ---- N orders 1 ---- N order_items
     |                   |                              |
     +---- accounts      +---- N tickets                N ---- 1 menu
                         +---- 0..1 payments
```

**Hình 2.** Quan hệ dữ liệu chính. `metadata` độc lập với quan hệ nghiệp vụ. Schema 3 thêm guest_credentials(token_hash, username, visit_id, created_at) và command_receipts(principal, command_id, action, fingerprint, result_json, created_at), PK ghép principal/command_id. Outbox là file client. Migration từ schema 1 giữ dữ liệu.

## 6. Thiết kế giao tiếp mạng

### 6.1. Thiết lập và vòng đời kết nối

Server mở `ServerSocket`; cấu hình mặc định là `127.0.0.1:5050`. Client kết nối với timeout 3 giây, gửi LOGIN và chỉ thao tác nghiệp vụ sau khi xác thực thành công. Danh tính ADMIN/GUEST và bàn do server trả về, không lấy từ khai báo vai trò của client.

Client gửi heartbeat PING mỗi 5 giây sau đăng nhập. Thời gian chờ RPC là 5 giây; socket read timeout client là 20 giây và server là 60 giây. Disconnect/timeout kết thúc kết nối tương ứng, thông báo UI và khóa thao tác gửi. Đăng xuất/đóng ứng dụng đóng socket; không dùng disconnect để đóng lượt bàn. Khi server dừng, các socket và worker được đóng trước khi launcher đóng service/database.

### 6.2. Đóng khung bản tin

```text
| 4 byte độ dài N, big-endian | N byte JSON UTF-8 |
```

N phải dương và không vượt 262.144 byte. Codec đọc đủ header/body, kiểm tra UTF-8, JSON và các trường bắt buộc. EOF trước byte đầu của header là hết kết nối; EOF giữa frame là frame bị cắt. Không dùng Java native object serialization.

### 6.3. Định dạng message

Ví dụ đặc tả yêu cầu đặt hai cốc cà phê sữa; `requestId` và `visitId` dưới đây là giá trị minh họa, không phải log thực nghiệm:

```json
{"version":1,"kind":"REQUEST","requestId":"req-demo-01","action":"PLACE_ORDER","ok":true,"data":{"visitId":"visit-do-server-cap","items":[{"menuId":2,"quantity":2}],"note":"ít đá"}}
```

Response giữ `requestId` và `action`; `ok` cho biết kết quả, `data` chứa dữ liệu; lỗi có `errorCode` và `message`. Event sử dụng `kind=EVENT`, `action=STATE_UPDATED`, `data=Snapshot` và không cần request ID. Chi tiết tại [PROTOCOL.md](../cafelink-system/docs/PROTOCOL.md).

Tuần 2 dùng requestId làm command ID của mutation. GET_OUTCOME dùng RPC mới để tra ID cũ, trả found/action/fingerprint/result. LOGIN có credential tùy chọn để resume, không fallback khi sai. DISCARD_COMMAND bỏ ý định chưa nhận bằng dấu bền vững; START_NEW_VISIT cấp credential mới khi lượt cũ đã đóng. Xem PROTOCOL để biết action và lỗi bổ sung.

### 6.4. Danh sách lệnh

| Action | Payload chính | Quyền/chức năng |
|---|---|---|
| LOGIN | username, password | Xác thực một lần trên kết nối |
| GET_OUTCOME | commandId | Tra receipt theo credential; trả fingerprint/outcome |
| DISCARD_COMMAND | commandId, action, payload | Bỏ trước tiếp nhận hoặc trả outcome đã nhận |
| START_NEW_VISIT | Không có dữ liệu nghiệp vụ | GUEST; chỉ cấp quyền mới khi lượt trước đã đóng |
| PING | Không có dữ liệu nghiệp vụ | Heartbeat sau login |
| GET_STATE | Không có dữ liệu nghiệp vụ | Snapshot theo quyền |
| OPEN_TABLE | tableId | ADMIN; tạo lượt |
| PLACE_ORDER | visitId, items, note | GUEST đúng bàn/lượt; server tính giá |
| SET_ORDER_STATUS | orderId, status | ADMIN; chuyển trạng thái kế tiếp |
| CALL_SERVICE | visitId, note | GUEST; tạo ticket phục vụ |
| REQUEST_BILL | visitId, note | GUEST; tạo ticket tính tiền khi có đơn |
| HANDLE_TICKET | ticketId, reply | ADMIN; xử lý ticket |
| GET_BILL | visitId | ADMIN hoặc GUEST đúng bàn |
| PAY_AND_CLOSE | visitId | ADMIN; thanh toán mô phỏng và đóng lượt |
| CLOSE_EMPTY_TABLE | visitId | ADMIN; đóng lượt không có đơn/ticket OPEN |

### 6.5. Luồng đặt món và cập nhật

```text
Khách           CafeServer         CafeService/SQLite          Chủ quán
  | PLACE_ORDER     |                       |                      |
  |---------------->| kiểm tra/transaction |                      |
  |                 |---------------------->|                      |
  |                 |<----------------------| commit + kết quả      |
  |<----------------| RESPONSE              |                      |
  |<----------------| STATE_UPDATED         |                      |
  |                 |--------------------------------------------->|
  |                 |                      STATE_UPDATED           |
```

**Hình 3.** Luồng logic của một mutation thành công. Server xếp response vào queue trước khi publish; việc enqueue không chứng minh client đã nhận. Gửi dữ liệu trên socket diễn ra ngoài khóa nghiệp vụ.

### 6.6. Xử lý lỗi

| Nhóm lỗi | Hành vi |
|---|---|
| Sai đăng nhập/chưa đăng nhập/sai quyền | AUTH_FAILED, UNAUTHENTICATED hoặc FORBIDDEN; trả response |
| Dữ liệu sai/không tìm thấy | INVALID_INPUT hoặc NOT_FOUND; không thay đổi dữ liệu |
| Trạng thái/lượt không hợp lệ | INVALID_STATE, SESSION_CLOSED hoặc TABLE_ALREADY_OPEN |
| Ticket OPEN cùng loại | TICKET_ALREADY_OPEN; không tạo ticket OPEN thứ hai |
| Lỗi database | DATABASE_ERROR; rollback transaction; có thể tiếp tục kết nối |
| Frame sai, EOF giữa frame, timeout hoặc I/O lỗi | Đóng peer liên quan; server tiếp tục phục vụ peer khác |
| Queue gửi đầy | Đóng peer chậm; không chờ ghi socket trong khóa database |
| RPC timeout sau mutation | Hiển thị chưa rõ kết quả; không tự retry trong tuần 1 |

## 7. Triển khai hệ thống

### 7.1. Công nghệ và tổ chức mã

Mã nguồn nằm trong `cafelink-system`, là một Maven project với các package `common`, `server`, `client` và `client.ui`. Build đặt compile release 17; môi trường đã kiểm tra sử dụng JDK 24.0.2. Swing thuộc JDK; Gson 2.11.0 xử lý JSON, SQLite JDBC 3.50.3.0 truy cập dữ liệu, SLF4J Simple 2.0.16 phục vụ logging và JUnit Jupiter 5.11.4 dùng cho kiểm thử [11–13].

| Lớp/thành phần | Cách triển khai nổi bật |
|---|---|
| `FrameCodec`, `Message` | Length-prefix, giới hạn frame, version, kind và correlation ID |
| `PasswordHash` | PBKDF2WithHmacSHA256, 120.000 vòng, salt ngẫu nhiên 16 byte |
| `Database` | Foreign keys, WAL, busy timeout 5.000 ms, PreparedStatement, seed không ghi đè |
| `CafeService` | API synchronized; transaction bao gồm kiểm tra, mutation và revision |
| `CafeServer` | Reader pool giới hạn 32 worker; writer/queue riêng mỗi peer |
| `NetworkClient` | Một reader, pending futures, heartbeat, recovery và lọc snapshot cũ |
| `Outbox`, `Commands` | Atomic journal/file lock và canonical SHA-256 fingerprint |
| `FaultInjector`, `RecoveryExperimentMain` | Fault local và đối chứng REVIEW/REPLAY_ALL qua TCP |
| `LoginFrame` | Xác thực nền; mở dashboard đúng vai trò server trả |
| `AdminFrame` | Sáu bàn, đơn/ticket/hóa đơn, tiến độ và thanh toán |
| `GuestFrame` | Menu, số lượng/ghi chú, trạng thái, yêu cầu/phản hồi; xóa nháp khi đổi lượt |
| `ServerMain`, `ClientMain` | Entry point chạy độc lập; server hỗ trợ console/headless |

### 7.2. Xử lý đồng thời

`CafeServer` nhận nhiều kết nối và dùng pool reader tối đa 32 worker. Mỗi peer có writer và `ArrayBlockingQueue` chứa tối đa 64 message. Peer gửi dữ liệu sai hoặc không tiêu thụ queue được đóng riêng. Các giới hạn này là cấu hình, không phải kết quả chứng minh tải 32 client đã đạt.

Một SQLite connection được sở hữu bởi service; các public operation được tuần tự hóa bằng khóa `CafeService`. Kiểm tra lượt/trạng thái và ghi dữ liệu nằm trong cùng transaction. Luồng mạng chỉ enqueue kết quả sau khi service hoàn tất, không ghi socket trong lúc giữ khóa database. Cơ chế này tránh tranh chấp dữ liệu nhưng làm ghi nghiệp vụ tuần tự.

Client có một reader phân tuyến response theo future và event theo listener. Thao tác mạng từ UI chạy bằng `SwingWorker`; cập nhật component chạy trên Event Dispatch Thread. Không có nhiều luồng cùng đọc trực tiếp input stream của một client.

### 7.3. Trạng thái và tính nhất quán

```text
Đơn:     SUBMITTED -> PREPARING -> READY -> SERVED
Ticket:  OPEN -> HANDLED
Lượt:    active=1 -> active=0; mở lượt tiếp theo tạo UUID khác
```

Giá trong `order_items` được lấy tại server và lưu ở thời điểm đặt. `PAY_AND_CLOSE` chỉ thành công khi đủ điều kiện, ghi payment và đóng lượt trong cùng transaction; unique constraint ngăn nhiều payment cho một lượt. Với bàn không có đơn, dùng `CLOSE_EMPTY_TABLE`, không tạo hóa đơn thanh toán giả.

Business revision lưu bền vững và tăng cùng mutation. Online count là trạng thái kết nối tạm thời, không nằm trong business revision. Việc client bỏ snapshot cũ giúp tránh ghi đè trạng thái nghiệp vụ đã mới hơn, không thay thế kiểm tra quyền/lượt tại server.

### 7.4. Giao diện đã triển khai

Ảnh dưới đây được render từ JFrame thật trong UI test, dùng TCP và SQLite thật; câu trả lời hộp thoại được tự động hóa qua seam `Dialogs`. Đây là bằng chứng giao diện tại mốc tuần 1, không phải khảo sát người dùng.

![Hình 4. Màn hình chủ quán với bàn, đơn và tiến độ phục vụ.](statics/cafelink-week1/admin-serving.png)

![Hình 5. Màn hình khách nhận phản hồi yêu cầu phục vụ.](statics/cafelink-week1/guest-feedback.png)

![Hình 6. Màn hình khách khi mất kết nối.](statics/cafelink-week1/guest-disconnected.png)

![Hình 7. Khách xác nhận ý định phục vụ chưa được nhận.](statics/cafelink-week2/guest-recovery.png)

### 7.5. Đóng gói và tái lập

Script bootstrap Maven 3.9.11 tải vào `.tools` và kiểm tra SHA-512, không yêu cầu Maven trong PATH. Build tạo `target/cafelink-1.0.0.jar` và thư viện runtime tại `target/lib`. Có script build, server, client, demo và smoke. Hướng dẫn chạy đầy đủ ở [README.md](../cafelink-system/README.md).

Bản gốc có JAR/dependency/source/test và báo cáo trong ZIP baseline; `scripts/package-original.ps1` đối chiếu JAR hash với campaign, `verify-package.ps1` kiểm manifest trước sử dụng. Kiểm chạy source và runtime từ đường dẫn mới ASCII có khoảng trắng được ghi tại mục 9.2.

## 8. Thiết lập kiểm thử và thực nghiệm

### 8.1. Môi trường kiểm thử và đo bản gốc

| Thành phần | Thông tin đo/kiểm tra thực tế |
|---|---|
| Hệ điều hành | Windows 11 Home, build 26200 |
| CPU | Intel Core i7-12700H, 14 nhân vật lý / 20 luồng logic |
| RAM | 16.907.980.800 byte, xấp xỉ 15,75 GiB |
| Java | JDK 24.0.2; compile target 17, chưa thử runtime 17 riêng |
| Build/test | Maven 3.9.11, JUnit Jupiter 5.11.4 |
| Network tải | TCP 127.0.0.1; server và load-client ở hai JVM riêng; mỗi case DB mới |
| Network phục hồi | TCP loopback; mỗi case server/client cùng JVM nhưng socket/DB riêng; sáu case độc lập chạy song song |
| Persistence | SQLite JDBC 3.50.3.0, WAL; journal file riêng mỗi guest |
| UI | Desktop thật; 5 UI test không bị skip, modal có seam trả lời |
| Dữ liệu mẫu | Sáu bàn, tám đồ uống; admin và sáu tài khoản bàn |

Metadata môi trường/JAR hash: [environment.json](evidence/cafelink-original/raw/benchmark/environment.json). Chỉ có một máy; không coi loopback là LAN hai máy. Chạy headless có thể skip UI nên phải công bố số skip.

### 8.2. Nhóm kiểm thử đã thực hiện

| Nhóm | Đối tượng và kịch bản |
|---|---|
| Codec | Unicode, nhiều frame, đọc byte phân mảnh, EOF, length/JSON/UTF-8/version sai |
| Nghiệp vụ | Xác thực/quyền, dữ liệu sai, giá server, chuyển trạng thái, ticket, thanh toán, persistence |
| TCP tích hợp | Login, cô lập dữ liệu, server push, peer lỗi, reconnect thủ công, nhiều client, shutdown |
| Nhất quán dữ liệu | Race thanh toán/đơn mới; SQLite trigger gây lỗi sau insert order để kiểm tra rollback |
| UI | Form login và nút thật qua TCP/SQLite, luồng phục vụ, mất kết nối, xóa nháp khi đổi lượt |
| Ứng dụng đóng gói | Server và scenario client ở hai JVM; restart cùng DB và đối chiếu kết quả |

### 8.3. Thiết kế thực nghiệm đã chạy

**Đối chứng phục hồi:** REPLAY_ALL và REVIEW dùng cùng mã server, receipt bền vững, fingerprint, guard lượt và credential. Chỉ thay quyết định đối với ý định chưa được nhận: REPLAY_ALL gửi lại, REVIEW giữ chờ khách xác nhận. REVIEW hiện áp dụng quy tắc xác nhận cho cả đơn lẫn lời gọi, chưa có TTL hoặc policy SEMANTIC. Không triển khai B0 bỏ guard; không dùng đối chứng yếu hơn để gán toàn bộ hiệu quả chống lặp cho REVIEW.

| Kịch bản | Fault / lịch | Oracle độc lập |
|---|---|---|
| NORMAL | Không fault, không chờ offline | Một đơn, đúng receipt |
| LOST_ORDER_ACK | Ngắt sau commit đặt món, trước response | Một đơn, lấy lại outcome |
| UNACCEPTED_ORDER | Ngắt trước handler | REVIEW cần xác nhận, REPLAY_ALL có một đơn |
| UNACCEPTED_SERVICE | Ngắt trước handler gọi phục vụ | REVIEW chưa tạo ticket, REPLAY_ALL tạo một ticket |
| LOST_SERVICE_ACK | Ngắt sau commit ticket | Một ticket, lấy lại outcome |
| VISIT_CHANGED | Chưa nhận lời gọi, đóng/mở bàn trước reconnect | Không đơn/ticket ở lượt mới từ ý định cũ |

2 policy × 6 kịch bản × 3 khoảng offline (2/10/60 giây) × 5 lần = 180 ca. Lịch được shuffle với seed 20261020; sáu fixture độc lập chạy song song, không dùng thời gian này kết luận hiệu năng chính sách. Offline là khoảng không có guest kết nối, server còn chạy; đây là fault tầng ứng dụng, chưa mô phỏng packet loss vật lý. NORMAL mang nhãn cấu hình delay nhưng thời gian offline thực bằng 0; không đưa NORMAL vào phân tích ảnh hưởng offline.

**Đo tải hoạt động bình thường:** 1/5/10/20 guest, mỗi mức 5 lần; warmup 10 giây, cửa sổ đo 60 giây, 1 request/giây/guest, mỗi slot thứ năm đặt một cà phê sữa 30.000 VND, còn lại GET_STATE. Mỗi guest có một socket/worker/journal; một admin mở sáu bàn và nhận push. Các lần lặp đảo thứ tự tăng/giảm số client để giảm thiên lệch thứ tự. Server và load-client là hai JVM riêng; không chạy campaign phục hồi/build cùng lúc. Đây là workload cố định, chưa tìm điểm bão hòa hoặc đo riêng overhead trước/sau contribution.

Raw request và kết quả từng lần nằm trong `evidence/cafelink-original/raw/benchmark/`. Launcher chạy JVM thật từ java.home, ghi javaExecutable/runtimeLauncherSha256 vào environment và bắt buộc listenerClosed=True sau mỗi case. Đợt trước dùng Oracle forwarding PID đã được loại khỏi baseline cuối; xem [đính chính launcher](CafeLink_Launcher_Correction.md). DB thật còn ở `cafelink-system/target/benchmark-*` và `target/recovery-experiment-*`; analyzer mở read-only, kiểm integrity/foreign key, đếm đơn/ticket/receipt/tổng tiền. Không đưa DB chứa credential/hash hoặc private outbox vào evidence công khai.

### 8.4. Định nghĩa chỉ số thực tế

| Chỉ số | Cách đo và giới hạn |
|---|---|
| Latency request | nanoTime quanh RPC; đặt món gồm ghi journal. p50/p95 nearest-rank gộp mẫu từng mức tải, có dữ liệu từng lần. Giữ cả mẫu lỗi/timeout; không dùng thời gian suite JUnit |
| Request/s hoàn tất | Số response OK trong cửa sổ mẫu / 60 giây hoặc thời gian có drain nếu dài hơn; gồm đọc và đặt món, không chỉ mutation |
| Đơn trùng/sai lượt | Đối chiếu SQLite với số tác dụng mong đợi từng ý định/lượt; receipt đặt món phải bằng số đơn |
| Ticket chưa xác nhận lại | Ticket tự tạo ở UNACCEPTED_SERVICE trước hành động xác nhận mới của khách; không đồng nghĩa nhu cầu thực tế chắc chắn hết hiệu lực |
| Thời gian phục hồi | Reconnect + login PBKDF2 + journal/refresh/lookup/reconcile, loại thời gian offline; chưa gồm chờ người dùng xác nhận |
| Traffic | Byte guest đọc và write hoàn tất, gồm header frame 4 byte/event/heartbeat; không gồm admin/TCP/IP; partial write lỗi có thể chưa đếm |
| Storage | Journal JSON guest và kích thước DB/WAL tại mốc chụp; không phải số byte riêng receipt hoặc tổng footprint JDK |

Mốc chụp traffic sau warmup có độ lệch nhỏ với cửa sổ request; `byteCaptureStartOffsetMs` và thời gian drain được giữ trong summary. Journal/DB benchmark gồm cả warmup. Process peak có trong dữ liệu thô ở target nhưng không dùng để kết luận CPU/RAM do không lấy mẫu cửa sổ đo và peak client sau exit không đáng tin cậy.

## 9. Kết quả

### 9.1. Kiểm thử tự động bản gốc

Build đầy đủ xác nhận **59 tests, 0 failures/errors/skipped**. [Surefire summary](evidence/cafelink-original/test-summary.json) và XML đã lưu kèm evidence. Tuần 1 có 27 test, tuần 2 có 49 test; không ghi đè các báo cáo lịch sử.

| Suite | Tests | Failures | Errors | Skipped |
|---|---:|---:|---:|---:|
| OutboxTest | 5 | 0 | 0 | 0 |
| UiWorkflowTest | 5 | 0 | 0 | 0 |
| FrameCodecTest | 6 | 0 | 0 | 0 |
| BenchmarkWorkflowTest | 1 | 0 | 0 | 0 |
| CafeServiceTest | 7 | 0 | 0 | 0 |
| CommandReceiptTest | 5 | 0 | 0 | 0 |
| GuestSessionTest | 4 | 0 | 0 | 0 |
| NetworkIntegrationTest | 14 | 0 | 0 | 0 |
| RecoveryCampaignTest | 1 | 0 | 0 | 0 |
| RecoveryIntegrationTest | 11 | 0 | 0 | 0 |
| **Tổng** | **59** | **0** | **0** | **0** |

Các ca bổ sung kiểm tra byte frame, socket thứ 33 bị từ chối, peer không đọc bị ngắt khi queue đầy, cleanup thread, lock journal khi server không sẵn sàng, mất ACK lúc bỏ yêu cầu và lúc thanh toán. [Báo cáo W3.1](CafeLink_W3_Part1_Report.md) giải thích phạm vi. Các test cũ vẫn kiểm tra rollback trigger, race payment/order, 12 guest đặt đồng thời, UI và cô lập quyền.

### 9.2. Smoke ứng dụng đóng gói

ServerMain headless chạy ở một JVM, DemoSmokeMain chạy ở JVM khác. Script sử dụng DB riêng và ba guest connections; sau đó dừng tiến trình server của script, khởi động lại cùng DB và đối chiếu trạng thái [14].

| Mốc | Đơn hàng | Tổng tiền | Ticket HANDLED | Kết quả |
|---|---:|---:|---:|---|
| Populate | 3 | 190.000 VND | 1 | PASS |
| Verify restart | 3 | 190.000 VND | 1 | PASS |

Tổng tiền từ dữ liệu smoke: 1 cà phê đen × 25.000 + 2 cà phê sữa × 30.000 + 3 bạc xỉu × 35.000 = 190.000 VND. Smoke cuối sau sửa launcher dùng JVM thật, kiểm listener cũ đã đóng trước restart; artifact: `cafelink-system/target/smoke-06fc09f5c5d74f33b31044d74060cf86/`. Smoke cũ chưa có phép kiểm này không dùng làm bằng chứng restart cuối. Kết quả chỉ chứng minh persistence ở lần dừng/khởi động lại có kiểm soát; không suy rộng thành bảo đảm cho mọi sự cố mất điện.

Kiểm tra bổ sung `scripts/smoke.ps1 -Recovery` sử dụng JVM client mới sau khi server restart: một đơn 30.000 VND được giữ nguyên, journal chuyển PENDING → RESOLVED. Artifact: `target/smoke-d7d285c272ff4fbfa8542bde6fc8e33f/`. Đây là kiểm tra phục hồi mất ACK qua tiến trình.

Kiểm chạy bản đóng gói gốc mới ở đường dẫn sạch ASCII có khoảng trắng xác nhận lại cả hai smoke trên JAR đã đo tải, phát hiện file bị sửa và build source giải nén đạt 59 test không skip. [Biên bản máy đọc được](evidence/cafelink-original/package-validation.json). Đây là thư mục sạch trên cùng OS/JDK, không phải máy Windows mới; build dùng dependency cache hiện có.

### 9.3. Đối chứng chức năng tuần 2

Đã chạy 24 ca: REVIEW (B2) và REPLAY_ALL (B1), bốn kịch bản, ba lần lặp/kịch bản/chính sách. Hai bản cùng idempotency và guard; B1 replay mọi lệnh chờ, B2 lookup rồi chờ xác nhận ý định chưa nhận. Server và client có socket riêng trên loopback nhưng cùng JVM. Fault trước tiếp nhận hoặc sau commit; chưa chèn thời gian mất mạng 2/10/60 giây ở đợt này.

| Quan sát (ba lần lặp/chính sách) | B1 REPLAY_ALL | B2 REVIEW |
|---|---:|---:|
| Ca bình thường đúng một đơn | 3/3 | 3/3 |
| Mất ACK đơn: phục hồi kết quả, không trùng | 3/3 | 3/3 |
| Ticket tự tạo khi lời gọi chưa nhận, chưa xác nhận lại nhu cầu | 3 | 0 |
| Ca lời gọi cần khách xác nhận lại | 0 | 3 |
| Tác dụng sai lượt trong ca đổi khách | 0 | 0 |

CSV thực tế: [results.csv](evidence/cafelink-week2/results.csv); cấu hình: [metadata.json](evidence/cafelink-week2/metadata.json). DB/snapshot/log từng ca tại `cafelink-system/target/recovery-experiment-e8abf527-770f-4b01-8702-5fa207fca438/`. recoveryMs đo bằng nanoTime từ trước reconnect đến hoàn tất login/refresh/recovery, gồm PBKDF2 và journal I/O. Mẫu nhỏ, thứ tự chạy chưa ngẫu nhiên hóa; không rút kết luận nhanh/chậm từ các giá trị này.

Kết quả thể hiện khác biệt quyết định phục hồi, không chứng minh TTL hay lời gọi thật sự đã hết nhu cầu trong quán. Cả hai bản chống trùng/sai lượt nhờ cơ chế chung; không quy lợi ích đó riêng cho REVIEW.

### 9.4. Đo tải và phục hồi bản gốc

| Khách | Số mẫu | Lỗi | Request/s trung bình | p50 (ms) | p95 (ms) | Đặt món p95 (ms) | GET_STATE p95 (ms) |
|---|---|---|---|---|---|---|---|
| 1 | 300 | 0 | 1.00 | 4.64 | 18.40 | 20.87 | 6.42 |
| 5 | 1500 | 0 | 5.00 | 2.68 | 12.50 | 14.94 | 3.71 |
| 10 | 3000 | 0 | 10.00 | 2.60 | 11.36 | 13.43 | 3.54 |
| 20 | 6000 | 0 | 20.00 | 2.89 | 8.64 | 11.28 | 3.97 |

Tổng **10,800 request, 0 lỗi** trong 20 lần đo. Số request/s là tải đạt được với lịch 1 request/giây/guest, chưa phải công suất tối đa. p95 gộp mẫu không phải khoảng tin cậy; khoảng dao động throughput từng lần nằm trong [benchmark-summary.csv](evidence/cafelink-original/benchmark-summary.csv), latency/storage/byte từng lần trong [benchmark-runs.csv](evidence/cafelink-original/benchmark-runs.csv).

![Hình 8. Latency và request/s của workload loopback cố định; mỗi mức tải năm lần.](evidence/cafelink-original/load-results.png)

| Guest | Gửi TB (KiB) | Nhận TB (MiB) | Journal TB (KiB) | DB/WAL TB (KiB) |
|---|---:|---:|---:|---:|
| 1 | 9.69 | 0.18 | 3.66 | 760.25 |
| 5 | 48.66 | 1.58 | 18.34 | 2440.44 |
| 10 | 97.97 | 7.63 | 36.72 | 4219.55 |
| 20 | 196.17 | 44.81 | 73.55 | 4291.57 |

TB là trung bình năm lần. Traffic đo sau warmup đến khi worker kết thúc; storage gồm dữ liệu warmup, DB/WAL ở mốc launcher chụp. Số byte nhận tăng nhanh theo số client: mã hiện tại broadcast snapshot sau mutation, đồng thời nhiều guest chia sẻ cùng bàn sẽ nhận danh sách đơn dài hơn. Đây là dấu hiệu để đánh giá U5 giảm push thừa trong giai đoạn nâng cấp, chưa chứng minh U5 đã giảm byte hoặc là nút thắt tại quán thực tế.

Campaign phục hồi **180/180 ca đạt**, gồm 15 ca mỗi kịch bản/policy. Không ghi nhận đơn trùng hoặc tác dụng sai lượt trong phạm vi này. LOST_ORDER_ACK và LOST_SERVICE_ACK đều lấy lại một kết quả đã lưu. REVIEW giữ 15 đơn chưa nhận và 15 lời gọi chưa nhận chờ xác nhận; REPLAY_ALL tự gửi lại. Riêng UNACCEPTED_SERVICE, REPLAY_ALL tạo 15 ticket trước khi xác nhận lại, REVIEW tạo 0. Đây là khác biệt chính sách, không chứng minh nhu cầu tại quán thực sự đã hết hoặc REVIEW nhanh hơn.

[Raw recovery CSV](evidence/cafelink-original/raw/recovery/results.csv), [cấu hình/lịch](evidence/cafelink-original/raw/recovery/metadata.json), [nhóm theo policy/scenario/delay](evidence/cafelink-original/recovery-summary.csv), [oracle SQLite](evidence/cafelink-original/database-oracle.csv), [hash evidence](evidence/cafelink-original/evidence-sha256.json).

### 9.5. Nghiệm thu còn cần điều kiện ngoài máy hiện tại

LAN vật lý hai máy **NOT RUN** vì người dùng chỉ có một máy. Bộ lệnh và biên bản [LAN_ACCEPTANCE.md](../cafelink-system/docs/LAN_ACCEPTANCE.md) đã chuẩn bị. Bìa/thành viên hoãn theo yêu cầu; Compilatio, duyệt bố cục Word trực quan và nộp chính thức chưa có bằng chứng. Không chuyển các mục này thành PASS bằng kết quả localhost.

## 10. Thảo luận

### 10.1. Những kết quả hiện tại hỗ trợ

Kết quả codec cho thấy cách đóng khung xử lý được các tình huống phân mảnh và dữ liệu sai đã kiểm thử. TCP integration và UI workflow cho thấy luồng khách–server–chủ quán hoạt động qua mạng thật, có kiểm tra quyền và server push. Rollback và race test hỗ trợ tính nhất quán trong các lịch thực thi đã xét. Smoke hai JVM cho thấy package có thể vận hành độc lập và giữ dữ liệu trong kịch bản restart đã chạy.

### 10.2. Những kết luận chưa thể đưa ra

59 test không chứng minh không còn lỗi, khả năng mở rộng trên LAN nhiều máy hoặc hiệu năng ổn định dài hạn. Presence hiện đếm socket, không xác minh số người/thiết bị vật lý. Credential gắn lượt đã có code và test. B1/B2 cho thấy khác biệt xác nhận lời gọi chưa nhận; campaign 180 ca mở rộng số lần kiểm tra nhưng chưa đánh giá người dùng hoặc mạng Wi-Fi thực để kết luận mức giảm lỗi ngoài quán.

### 10.3. Đánh đổi của thiết kế

Khóa service đơn giản hóa consistency nhưng tuần tự hóa ghi. Snapshot đầy đủ giảm độ phức tạp phục hồi trạng thái nhưng tốn byte và bị giới hạn frame. Yêu cầu xác nhận lại lời gọi chưa được nhận giảm tự phát lại nhu cầu cũ nhưng thêm thao tác cho khách. Receipt/outbox làm tăng storage và xử lý; dung lượng journal/DB và byte toàn ứng dụng đã ghi theo từng lần nhưng chưa tách overhead riêng bằng ablation trước/sau contribution.

### 10.4. Đe dọa tính hợp lệ của thực nghiệm

Sau campaign tải, kiểm thư mục sạch phát hiện deadlock đọc stdout/stderr khi dò java.home. Bản đóng gói dùng đọc pipe đồng thời ở bước trước khởi động JVM; đường xử lý request, JAR, JVM thực thi và workload giữ nguyên. Không đo hoặc so sánh thời gian khởi động. Mã launcher lúc đo, bản diff chỉ đổi bước dò JDK và hai hash được giữ tại [hồ sơ startup patch](evidence/cafelink-original/launcher-startup-patch.json); bản đóng gói được smoke/build riêng sau vá.

Warmup cố định mười giây nhưng số thao tác warmup khác nhau giữa các mức tải; JIT, cache, CPU và dao động nền có thể ảnh hưởng. Chưa có profiling để tách nguyên nhân. Không suy từ một xu hướng p95 thành thêm client làm hệ thống nhanh hơn hoặc đã đạt công suất tối đa; cần warmup theo cả số thao tác và thời gian khi so hiệu năng chi tiết.

Mẫu khảo sát có thiên lệch lựa chọn và đọc mã tĩnh có thể bỏ sót cơ chế. Kiểm thử localhost không đại diện Wi-Fi yếu hoặc nhiều máy. Fault injection ở tầng ứng dụng có thể không bao phủ lỗi mạng thật. UI test tự động hóa modal không thay thế đánh giá khả dụng với người dùng. Khi hoàn thiện, phải công bố các giới hạn này và dùng workload bình thường cùng nhiều vị trí gây lỗi thay vì chỉ chọn trường hợp bất lợi cho baseline.

## 11. Điểm đóng góp và bằng chứng

| Đóng góp | Triển khai | Bằng chứng | Giới hạn |
|---|---|---|---|
| C1 Phục hồi theo loại/trạng thái tiếp nhận | Receipt/outbox, fingerprint, lookup, xác nhận hoặc bỏ trước nhận | Receipt/Outbox/Recovery/UI tests; 180 ca fault, 15 ca lời gọi mỗi policy | Cả đơn và lời gọi chưa nhận đều cần xác nhận; chưa TTL; chưa tách overhead từng cơ chế |
| C2 Quyền theo lượt | Credential một lượt, guard nguyên tử, scope outcome/snapshot, đổi lượt có điều kiện | GuestSessionTest, migration/restart, stale replay, đối chứng đổi khách | B1/B2 cùng guard nên không đo riêng C2; shared password là terminal demo |

Socket/UI/database là nền tảng, không tính riêng novelty. Idempotency, dấu bỏ và fencing có tiền lệ. Đóng góp cấp học phần là hợp đồng phục hồi cụ thể và kiểm chứng; chưa chứng minh thuật toán mới hoặc exactly-once delivery.

## 12. Hạn chế

Launcher Windows hiện cần đường dẫn ASCII (cho phép khoảng trắng). Ca thư mục tiếng Việt không đạt trên JDK24 dùng native.encoding=Cp1252: tham số classpath bị mất ký tự. Chưa sửa hỗ trợ trường hợp này; README ghi điều kiện cài đặt. Đây là giới hạn tên thư mục khởi chạy, không phải thay đổi encoding UTF-8 của message.

Đã có credential theo lượt và outbox nhưng dùng tài khoản bàn cố định; người biết mật khẩu có thể chủ động xin quyền terminal mới. Credential cục bộ chưa mã hóa at rest; không lưu password. TCP chưa TLS, chưa web/QR hoặc cấp quyền cho thiết bị cá nhân. Reconnect do người dùng thực hiện, không tự đăng nhập ngầm.

Đã đo tải loopback, chưa chạy LAN nhiều máy, thử dài hạn, phân trang hoặc event delta. Snapshot giới hạn 256 KiB; receipt/credential chưa GC. Atomic replace/file force không bảo đảm mọi mất điện. Không có TTL, payment gateway, sửa/hủy món đã nhận hoặc quản lý kho. Chưa khảo sát người dùng quán thực tế.

## 13. Hướng phát triển

Ưu tiên nghiệm thu LAN khi có máy thứ hai; giữ bản gốc đã đóng gói làm mốc E0 để đo phần nâng cấp. Chỉ triển khai các gói trong CafeLink_Upgrade_Plan.md khi chuyển sang giai đoạn nâng cấp. Tiếp theo có thể phát triển web HTTP/WebSocket, cấp quyền theo QR, TLS, quản lý tài khoản/menu, phân trang và delta. Sửa/hủy món đã nhận cần kiểm tra phiên bản/trạng thái nguyên tử với bắt đầu pha chế. Các hướng này chưa thuộc kết quả hiện tại.

## 14. Kết luận

CafeLink đã hoàn thành bản gốc Client/Server TCP có xác thực, nhiều client, server push, transaction SQLite, receipt/outbox và quyền theo lượt. Kết quả có 59 test đạt, smoke qua JVM và restart, 20 lần đo tải với 10,800 request/0 lỗi và 180 ca phục hồi đối chứng. REVIEW giữ lời gọi chưa nhận chờ khách xác nhận, tránh 15 ticket tự phát lại so với REPLAY_ALL trong workload đã xét; cả hai cùng cơ chế chống lặp và guard lượt.

Đóng góp là hợp đồng phục hồi ứng dụng và bộ kiểm chứng tái lập, không phải thuật toán mới hoặc bảo đảm exactly-once. Bản gốc có baseline đóng gói và evidence để chuẩn bị nâng cấp. LAN vật lý, kiểm chứng thực tế tại quán và thủ tục nộp vẫn cần bổ sung đúng điều kiện.

## 15. Tài liệu tham khảo

Các nguồn được dùng theo vai trò: [1–2] là yêu cầu học phần; [3–7] là nền tảng/tiền lệ; [8–10] là hồ sơ khảo sát nội bộ có nguồn dự án và SHA; [11–13] là thư viện; [14] là bằng chứng triển khai nội bộ. Khi xuất bản cuối, giữ citation trong nội dung và mở rộng các dự án thực sự được thảo luận thành mục tham khảo riêng theo quy định của giảng viên.

1. Giảng viên học phần. [Hướng dẫn thực hiện bài tập lớn – Lập trình mạng, năm học 2026–2027](../final-project/Instruction.md). Tài liệu học phần trong workspace.
2. Giảng viên học phần. [Hướng dẫn nộp bài Project](../final-project/Submission.md). Tài liệu học phần trong workspace.
3. IETF. [RFC 9293: Transmission Control Protocol (TCP)](https://www.rfc-editor.org/rfc/rfc9293.html), 2022.
4. Stripe. [Idempotent requests](https://docs.stripe.com/api/idempotent_requests). Nguồn được ghi nhận trong khảo sát ngày 14/10/2026.
5. AWS Builders' Library. [Making retries safe with idempotent APIs](https://aws.amazon.com/builders-library/making-retries-safe-with-idempotent-APIs/). Nguồn được ghi nhận trong khảo sát ngày 14/10/2026.
6. OASIS. [MQTT Version 5.0](https://docs.oasis-open.org/mqtt/mqtt/v5.0/os/mqtt-v5.0-os.html), 2019, phần Message Expiry Interval.
7. Martin Kleppmann. [How to do distributed locking](https://martin.kleppmann.com/2016/02/08/how-to-do-distributed-locking.html), 2016, phần fencing.
8. [CafeLink Student Survey A](CafeLink_Student_Survey_A.md). Hồ sơ khảo sát nội bộ, 14/10/2026.
9. [CafeLink Student Survey B](CafeLink_Student_Survey_B.md). Hồ sơ khảo sát nội bộ, 14/10/2026.
10. [CafeLink Student Survey C](CafeLink_Student_Survey_C.md). Hồ sơ khảo sát nội bộ, 14/10/2026.
11. Google. [Gson](https://github.com/google/gson). Thư viện JSON, phiên bản sử dụng 2.11.0.
12. Xerial. [SQLite JDBC](https://github.com/xerial/sqlite-jdbc). Phiên bản sử dụng 3.50.3.0.
13. JUnit. [JUnit 5.11.4 User Guide](https://docs.junit.org/5.11.4/user-guide/).
14. [CafeLink – Báo cáo tích hợp và đóng gói tuần 1](CafeLink_W1_Part5_Report.md), [bàn giao tuần 1](CafeLink_Week1_Handoff.md), artifact `cafelink-system/target/surefire-reports/` và `target/smoke-5d9e7ec88cab4ff39f996d2f933a558a/`, 14/10/2026.

## 16. Phụ lục

### A. Hướng dẫn tái lập baseline

Chạy từ thư mục `cafelink-system`:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/demo.ps1
```

Demo mở server và ba client khách. Trên server console mở login quản trị; đăng nhập `admin / CafeLink@123`. Khách dùng `ban1 / Ban1@123`, `ban2 / Ban2@123`, `ban3 / Ban3@123`. Chủ quán mở bàn trước khi đặt. Đây là mật khẩu demo, không phải tài khoản triển khai thực tế.

Chạy kiểm thử và smoke đóng gói:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/maven.ps1 -B test
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/smoke.ps1
```

Không ghi đè DB demo để tạo kết quả; smoke tự tạo thư mục riêng. Kiểm tra GUI trên môi trường có hiển thị. LAN và tùy chọn cổng/IP/database nằm trong README.

### B. Ma trận truy vết yêu cầu học phần

| Thành phần báo cáo theo hướng dẫn [1] | Vị trí |
|---|---|
| Title, Abstract, Keywords | Trang đầu, Tóm tắt, Từ khóa |
| Introduction | Mục 1 |
| Background / Related Work | Mục 2 |
| Problem Definition | Mục 3 |
| Proposed Approach | Mục 4 |
| System Architecture | Mục 5 |
| Network Communication Design | Mục 6 |
| Implementation | Mục 7 |
| Experimental Setup | Mục 8 |
| Results | Mục 9 |
| Discussion | Mục 10 |
| Novelty and Contributions | Mục 11 |
| Limitations / Future Work / Conclusion | Mục 12–14 |
| References / Appendix | Mục 15–16 |

### C. Báo cáo tiến độ và bằng chứng chi tiết

| Mốc | Nội dung | Tài liệu |
|---|---|---|
| W1.1 | Build, DTO và codec | [Part 1](CafeLink_W1_Part1_Report.md) |
| W1.2 | Schema, xác thực và nghiệp vụ | [Part 2](CafeLink_W1_Part2_Report.md) |
| W1.3 | TCP, push và đồng thời | [Part 3](CafeLink_W1_Part3_Report.md) |
| W1.4 | Swing workflow | [Part 4](CafeLink_W1_Part4_Report.md) |
| W1.5 | Tích hợp, package và restart smoke | [Part 5](CafeLink_W1_Part5_Report.md) |
| W2 | Receipt, outbox và guard lượt | [Tuần 2](CafeLink_Week2_Handoff.md) |
| W3 | Test, đo tải/fault, báo cáo và đóng gói | [Bản gốc](CafeLink_Original_Handoff.md), [truy vết](CafeLink_Requirements_Traceability.md) |

### D. Phân công và sử dụng AI

**[CẦN ĐIỀN]** Bổ sung từng thành viên và công việc thực tế vào bảng đầu báo cáo; thêm bảng nhiệm vụ/commit nếu cần. Không gán phần việc cho người chưa thực hiện hoặc tự khai mức đóng góp.

AI đã hỗ trợ phân tích, thiết kế, viết mã, kiểm thử và soạn bản thảo trong quá trình thực hiện. **[CẦN ĐIỀN]** Nhóm bổ sung tên công cụ, phần được hỗ trợ và cách từng thành viên đã kiểm tra/hiểu kết quả. Theo hướng dẫn học phần [1], sinh viên chịu trách nhiệm về source code, architecture, thực nghiệm, dữ liệu, tài liệu tham khảo và nội dung nộp; có thể phải giải thích hoặc sửa mã khi bảo vệ.

### E. Danh sách hoàn thiện trước khi nộp

- [ ] Điền trường, khoa, giảng viên, lớp, số nhóm, thành viên và phân công thực tế.
- [x] Hoàn thành code/test C1/C2 và cập nhật protocol/schema tuần 2.
- [x] Ghi CPU/RAM/OS/network, policy, seed và workload trong metadata.
- [x] Chạy 24 ca đối chứng chức năng và lưu CSV/metadata tuần 2.
- [x] Benchmark loopback, campaign offline và biểu đồ bản gốc; raw data/oracle lưu kèm.
- [ ] LAN vật lý hai máy: NOT RUN, một máy hiện có; runbook đã chuẩn bị.
- [x] Cập nhật Abstract, Discussion, Contributions và Conclusion theo evidence bản gốc.
- [x] Giữ nguồn/citation và tách rõ placeholder, giới hạn cùng công việc ngoài máy.
- [x] Xuất DOCX kỹ thuật tương ứng Markdown; cần người xem bố cục Word và đổi tên thành `NhomXX_CafeLink_Report.docx` với số nhóm thật.
- [ ] Kiểm tra Compilatio theo quy định học phần, lưu kết quả thực tế; chưa có kết quả kiểm tra trong bản này.
- [x] Đóng gói source/runtime/báo cáo baseline, manifest; trước nộp đổi tên nhóm theo [hướng dẫn nộp](../final-project/Submission.md); kiểm tra hạn 23:59 ngày 31/10/2026.

### F. Chỉnh sửa và xuất Word

File Markdown này là nguồn nội dung. Bản Word đi kèm là bản thảo tương ứng, không phải bản đã sẵn sàng nộp. Để tái tạo DOCX sau khi sửa nội dung, từ workspace chạy:

```powershell
python report/tools/export_cafelink_report.py
```

Script yêu cầu `python-docx` và `Markdown`; có thể cài bằng `python -m pip install python-docx Markdown` nếu chưa có. Sơ đồ text được giữ nguyên trong Word; có thể thay bằng hình vector khi hoàn thiện bản nộp. Kiểm tra lại ngắt trang, độ rộng bảng và ảnh trong Word trước khi nộp.
