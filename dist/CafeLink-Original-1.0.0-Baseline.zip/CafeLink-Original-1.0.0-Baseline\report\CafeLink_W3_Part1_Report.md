# W3.1 — Rà soát và kiểm thử các ranh giới còn thiếu

Ngày thực hiện: 20/10/2026. **Đạt: 59 tests, 0 failures/errors/skipped** trong lần build đầy đủ trước đo tải. Baseline đầu phiên có 49 test. Báo cáo tổng và evidence cuối lưu tại `evidence/cafelink-original/` sau khi campaign kết thúc.

## Thay đổi và bằng chứng

| Phần | Kiểm chứng qua giao diện công khai | Kết quả |
|---|---|---|
| Byte ứng dụng | Frame PING qua socket thật; đối chiếu số byte gửi/nhận với frame encode | Đạt |
| Giới hạn kết nối | ADMIN + 31 socket giữ chỗ; socket thứ 33 bị đóng; ADMIN vẫn truy vấn được | Đạt |
| Client không đọc | Socket receive buffer nhỏ, không đọc; gửi cập nhật đến khi queue đầy; peer bị ngắt, client hợp lệ vẫn đúng dữ liệu | Đạt |
| Dọn tài nguyên | Đóng sáu guest, owner và server; kiểm tra connection count và thread CafeLink kết thúc | Đạt |
| Server không sẵn sàng | Kết nối thất bại không giữ file lock outbox | Đạt |
| Bỏ yêu cầu mất ACK | DISCARD được commit nhưng phản hồi mất; reconnect tra lại dấu bỏ, lệnh gốc gửi muộn bị chặn | Đạt |
| Bỏ sau tiếp nhận | Đã có ticket thì lấy kết quả; không hủy ticket đã nhận | Đạt |
| Thanh toán mất ACK | ADMIN mới tra/replay cùng ID nhận cùng phiếu sau đóng lượt | Đạt |
| Workload đo tải | Hai guest qua TCP/SQLite, kiểm tra raw CSV, số mẫu/lỗi và tổng tiền | Đạt |
| Campaign phục hồi | Sáu kịch bản × hai policy ở delay 0; 12 ca và raw CSV có đủ cột | Đạt |

`NetworkClient.Traffic` đếm byte đọc thực tế và write hoàn tất, gồm header 4 byte. Không phải packet capture; write thất bại một phần có thể chưa được đếm. Fault hook được mở rộng cho `DISCARD_COMMAND` để kiểm tra mất ACK của dấu bỏ; không thêm quyền kích hoạt fault từ client.

Các ca được chạy riêng trong quá trình triển khai; sau cùng `scripts/build.ps1` chạy toàn bộ 59 test và package thành công. JUnit UI chạy trên desktop thật, không bị skip; modal được cấp câu trả lời qua seam Dialogs, các thao tác vẫn đi qua TCP/SQLite. Không quy 59 test thành độ phủ 100% dòng mã hoặc bảo đảm không còn mọi lỗi.

## Tái lập

```powershell
cd cafelink-system
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build.ps1
```

Suite mới: BenchmarkWorkflowTest và RecoveryCampaignTest. Suite mở rộng: NetworkIntegrationTest, RecoveryIntegrationTest, OutboxTest. Giao thức, schema và nghiệp vụ gốc giữ wire version 1 / schema 3; chưa triển khai các gói nâng cấp U1–U5.
