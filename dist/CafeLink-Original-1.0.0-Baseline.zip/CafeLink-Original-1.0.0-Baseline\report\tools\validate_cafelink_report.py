"""Structural Markdown/DOCX checks; this is not visual Word layout review."""
from pathlib import Path
import argparse
import json
import re
import zipfile
import xml.etree.ElementTree as ET

import markdown
from docx import Document
from PIL import Image


def validate(report_dir, output):
    source = report_dir / "CafeLink_Project_Report.md"
    text = source.read_text(encoding="utf-8")
    summary = json.loads((report_dir / "evidence/cafelink-original/summary.json").read_text(encoding="utf-8"))
    links = re.findall(r"\]\(([^)]+)\)", text)
    local = [link for link in links if not link.startswith(("http:", "https:", "#"))]
    missing = [link for link in local if not (report_dir / link).is_file()]
    if missing:
        raise ValueError(f"Missing local links/images: {missing}")
    parsed = ET.fromstring("<root>" + markdown.markdown(text, extensions=["tables", "fenced_code"]) + "</root>")
    images = list(parsed.iter("img"))
    for image in images:
        with Image.open(report_dir / image.attrib["src"]) as bitmap:
            bitmap.verify()
    docx = report_dir / "CafeLink_Project_Report_Draft.docx"
    with zipfile.ZipFile(docx) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError(f"Broken DOCX entry: {bad}")
    document = Document(docx)
    if len(document.inline_shapes) != len(images) or len(document.tables) != len(list(parsed.iter("table"))):
        raise ValueError("DOCX table/image count differs from Markdown")
    extracted = "\n".join([paragraph.text for paragraph in document.paragraphs] + [cell.text for table in document.tables for row in table.rows for cell in row.cells])
    for needle in (f"{summary['tests']['tests']} tests", f"{summary['requests']:,} request", "180/180", "NOT RUN"):
        if needle not in text or needle not in extracted:
            raise ValueError(f"Measured report content missing in Markdown or DOCX: {needle}")
    references = text.split("## 15. Tài liệu tham khảo", 1)[1].split("## 16.", 1)[0]
    reference_ids = set(re.findall(r"^(\d+)\.", references, flags=re.MULTILINE))
    cited_ids = set(re.findall(r"\[(\d+)\]", text))
    if cited_ids - reference_ids:
        raise ValueError(f"Undefined reference numbers: {cited_ids-reference_ids}")
    result = dict(status="PASS", localReferences=len(local), images=len(images), tables=len(document.tables), paragraphs=len(document.paragraphs),
                  numberedReferences=len(reference_ids), retainedMetadataPlaceholders=text.count("[CẦN ĐIỀN]"),
                  scope="Markdown local links/images, measured content, DOCX ZIP structure/table/image counts and numbered reference existence; no visual pagination/layout approval",
                  pending="Physical two-machine LAN, group metadata, visual Word review, Compilatio and official submission remain outside automated checks")
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-dir", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    validate(args.report_dir, args.output)
