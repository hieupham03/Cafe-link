# CafeLink: khảo sát mã nguồn đồ án sinh viên — mẫu B

Ngày khảo sát: 14/10/2026. Nguồn chính: repository công khai do tác giả tự mô tả là đồ án môn học hoặc cuộc thi mini-project của trường. Không chạy ứng dụng; kết luận dựa trên tài liệu và mã nguồn ở commit được ghi lại. Các kết quả chỉ nói về đường đi đã kiểm tra, không khẳng định sản phẩm hoàn toàn không có một tính năng.

## Phương pháp và tiêu chí

Truy vấn khám phá, thực hiện trước khi phân loại tính năng:

- `github "restaurant" "socket" "project" java`
- `github "cafe" "lập trình mạng"`
- `github "restaurant ordering" "college project"`
- `github "cafe management" "final project"`
- `site.github.com "restaurant" "ordering" "semester project"`
- Mở topic GitHub `cafeteria-management` và `ordering-system`, sau đó đọc repository gốc.

Chọn dự án có bằng chứng học thuật từ tác giả, có mã nguồn đặt món/quản lý quán, và các đường đi liên quan có thể đọc được. Đây là mẫu chủ đích/thuận tiện từ kết quả tìm kiếm, không phải mẫu ngẫu nhiên. Không lựa chọn dự án theo việc có hay không có cơ chế CafeLink đề xuất. Admin và Customer của K23 được tính là **một dự án**, không phải hai quan sát độc lập.

Mã phân loại:

- **Y:** có bằng chứng mã nguồn cho đúng định nghĩa tính năng.
- **N:** chưa ghi nhận trong các đường đi và schema đã kiểm tra; không suy ra từ README im lặng.
- **U:** chưa đủ phạm vi kiểm tra để phân loại.
- **—:** chức năng/bối cảnh không có trong dự án, không đưa vào mẫu số của tiêu chí đó.

Định nghĩa tính năng:

- **I:** ID lệnh sinh trước khi gửi, được giữ nguyên qua retry, có kết quả lưu phía server để đối chiếu. ID đơn sinh sau khi insert hoặc ID thanh toán của cổng không tự đáp ứng.
- **Q:** khôi phục kết quả lệnh theo ID gốc khi client chưa nhận response; không chỉ GET một đơn mà client đã biết ID.
- **E:** hạn tiếp nhận cho yêu cầu phục vụ/tính tiền chưa được nhận, kết hợp quyết định có phát lại sau reconnect. JWT/password/card expiry không đáp ứng.
- **F:** server phân biệt từng lượt khách sử dụng cùng một bàn, đổi phiên khi kết thúc lượt và dùng nó để ngăn tác dụng của lệnh cũ. HTTP login session, QR token đổi thủ công hoặc orderToken không tự đáp ứng.
- **R:** có hợp đồng phục hồi lệnh theo loại và vòng đời nghiệp vụ, thay vì chỉ reconnect hoặc lưu giỏ hàng.

## B1 — Cafeteria Management System, bhavankumar2911

- Repository: https://github.com/bhavankumar2911/cafeteria-management-system
- Commit: `17bd127daa1470bc6a2356d21de0ce59b9b6a0a9`.
- Bằng chứng học thuật: [README dòng 7](https://github.com/bhavankumar2911/cafeteria-management-system/blob/17bd127daa1470bc6a2356d21de0ce59b9b6a0a9/README.md#L7) tự mô tả mini-project contest của college.
- Bối cảnh: đặt đồ ăn trước ngày ăn/nhận tại điểm lấy trong campus; không có phiên khách ngồi bàn.
- Đã đọc: `server/controllers/order/create.js`, `server/models/order.js`, `server/models/orderDetail.js` qua schema liên quan, `client/pages/user/cart.jsx`; tìm thêm trong `server` và `client` với offline/reconnect/retry/idempotency/requestId/session/expiry/socket.
- [create.js dòng 60–89](https://github.com/bhavankumar2911/cafeteria-management-system/blob/17bd127daa1470bc6a2356d21de0ce59b9b6a0a9/server/controllers/order/create.js#L60) tạo đơn với ID chứa `Date.now()` phía server rồi trả response. Model lưu các ID Razorpay, nhưng chưa ghi nhận unique client-command ID và lookup kết quả theo ID đó trong luồng này.
- [cart.jsx dòng 45](https://github.com/bhavankumar2911/cafeteria-management-system/blob/17bd127daa1470bc6a2356d21de0ce59b9b6a0a9/client/pages/user/cart.jsx#L45) gửi POST sau callback thanh toán; catch hiển thị lỗi. Cổng thanh toán là thành phần ngoài repository nên không kết luận về toàn bộ bảo đảm của Razorpay.
- `socket.io-client` có trong dependency nhưng chưa ghi nhận việc dùng nó ở đường đi đặt món; dependency không được tính là realtime đã triển khai.
- Phân loại: **I=N, Q=N, E=—, F=—, R=N**.

## B2 — MangaBrew-Cafe, Areyzxc

- Repository: https://github.com/Areyzxc/MangaBrew-Cafe
- Commit: `d2953914e28922d9df777325111d70364128e59c`.
- Bằng chứng học thuật: [README dòng 2](https://github.com/Areyzxc/MangaBrew-Cafe/blob/d2953914e28922d9df777325111d70364128e59c/README.md#L2) tự mô tả group project môn Technopreneurship.
- Bối cảnh: tài khoản, giỏ hàng và giờ lấy đồ; không có phiên sử dụng bàn.
- Đã đọc: `process_order.php`, luồng submit trong `orders.php`, schema `database/mangabrew_schema.sql`; tìm cơ chế recovery trong PHP/JavaScript/SQL của dự án, loại dump dữ liệu không liên quan.
- [process_order.php dòng 81](https://github.com/Areyzxc/MangaBrew-Cafe/blob/d2953914e28922d9df777325111d70364128e59c/process_order.php#L81) bắt đầu transaction, INSERT đơn và item, commit tại dòng 136, xóa giỏ hàng session rồi redirect.
- CSRF token và HTTP session được dùng; chưa ghi nhận stable command ID, outbox phục hồi hoặc kết quả lệnh theo ID gốc. Việc xóa giỏ có thể ngăn một số lần submit tiếp theo trong session, nên không khẳng định mọi retry sẽ tạo trùng.
- Các trường expiry đã thấy thuộc thẻ, remember token hoặc password reset; không tính là thời hạn yêu cầu phục vụ.
- Phân loại: **I=N, Q=N, E=—, F=—, R=N**.

## B3 — Smart Restaurant, K23-Smart-Restaurant (Admin + Customer)

- [Admin repository](https://github.com/K23-Smart-Restaurant/smart-restaurant-admin), commit `74efaf3b976a751531ef2ad416c0bd8845e768ca`.
- [Customer repository](https://github.com/K23-Smart-Restaurant/smart-restaurant-customer), commit `7a5d3c0ebffba6ceb6fea42e45687190154d00cf`.
- Bằng chứng học thuật: [Admin README dòng 155](https://github.com/K23-Smart-Restaurant/smart-restaurant-admin/blob/74efaf3b976a751531ef2ad416c0bd8845e768ca/README.md#L155) và Customer README mô tả HCMUS Web Application Development Course.
- Bối cảnh: QR theo bàn, guest/auth user, gọi món, bếp/nhân viên, yêu cầu hóa đơn; phù hợp hơn với CafeLink so với các mẫu takeaway.
- Đã đọc Admin: `SocketService.js`, `TableService.js`, `OrderService.js`, đoạn hoàn tất thanh toán của `BillService.js`, `QRCodeService.js`, `SocketContext.tsx`, `useWaiterSocket.ts`, `useKitchenSocket.ts`, schema Prisma và tài liệu kiến trúc.
- Đã đọc Customer: `order.service.js` (create/get/addItems/requestBill/status), `OrderContext.tsx`, `SocketContext.tsx`, `order.types.ts`, schema Prisma; tìm requestId/idempotency/epoch/visit/expiry/offline trong source không bao gồm generated code.
- [Customer SocketContext dòng 123](https://github.com/K23-Smart-Restaurant/smart-restaurant-customer/blob/7a5d3c0ebffba6ceb6fea42e45687190154d00cf/client/src/contexts/SocketContext.tsx#L123) bật reconnect; [Admin useWaiterSocket](https://github.com/K23-Smart-Restaurant/smart-restaurant-admin/blob/74efaf3b976a751531ef2ad416c0bd8845e768ca/client/src/hooks/useWaiterSocket.ts#L27) join lại room và nhận bill/order events. Vì vậy realtime và reconnect đã có bằng chứng, không thể tự nhận là khác biệt.
- [Customer createOrder dòng 215](https://github.com/K23-Smart-Restaurant/smart-restaurant-customer/blob/7a5d3c0ebffba6ceb6fea42e45687190154d00cf/server/src/services/order.service.js#L215) dùng transaction và chặn tạo đơn mới khi bàn còn đơn chưa thanh toán. Đây là guard nghiệp vụ chống một lớp đơn mới; không tương đương receipt của command ID ổn định qua retry.
- [OrderContext dòng 277](https://github.com/K23-Smart-Restaurant/smart-restaurant-customer/blob/7a5d3c0ebffba6ceb6fea42e45687190154d00cf/client/src/contexts/OrderContext.tsx#L277) gửi tableId/qrToken/items rồi mới lưu orderId/orderToken khi response thành công. Có tra cứu đơn đã biết ID; chưa ghi nhận đối chiếu kết quả theo ID lệnh trước khi server sinh đơn.
- [requestBill dòng 796](https://github.com/K23-Smart-Restaurant/smart-restaurant-customer/blob/7a5d3c0ebffba6ceb6fea42e45687190154d00cf/server/src/services/order.service.js#L796) xác thực quyền trên đơn, kiểm tra chưa PAID, cập nhật billRequested và phát event; chưa ghi nhận admission deadline cho lệnh đang phục hồi.
- [OrderSession](https://github.com/K23-Smart-Restaurant/smart-restaurant-customer/blob/7a5d3c0ebffba6ceb6fea42e45687190154d00cf/client/src/types/order.types.ts#L206) chứa orderId/orderToken/tableId/qrToken. QR token có TTL và đổi khi regenerate thủ công; đoạn hoàn tất thanh toán đổi bàn thành AVAILABLE. Chưa ghi nhận epoch của từng lượt khách hoặc quy tắc đổi epoch nguyên tử cùng close bàn.
- Phân loại: **I=N, Q=N, E=N, F=N, R=N** trong đường đi đã kiểm tra. Các N không phủ nhận những guard nghiệp vụ và bảo vệ token thực sự đã có.

## Tổng hợp mẫu B

| Dự án | Bàn ăn / lượt khách | I | Q | E | F | R |
|---|---:|---:|---:|---:|---:|---:|
| B1 campus cafeteria | Không | N | N | — | — | N |
| B2 MangaBrew | Không | N | N | — | — | N |
| B3 K23 Smart Restaurant | Có | N | N | N | N | N |

Mẫu B ghi nhận 0/3 cho I/Q/R trong luồng khảo sát; E chỉ có 1 mẫu áp dụng, F cũng chỉ có 1 mẫu áp dụng. Không được biến E hoặc F thành 0/3. Cỡ mẫu này tự thân không đủ để ước lượng mức phổ biến rộng.

## Dự án không đưa vào mẫu chính

- `karthik-d/cafeteria-management-system`, commit `76b8c8b437e0cdef3a03499b5f6404e1eb008274`: đã đọc controller/model/schema. Topic GitHub có capstone, nhưng README không xác nhận khóa học/trường; loại khỏi mẫu chính dùng tiêu chí bằng chứng học thuật rõ. Có thể dùng làm comparator bổ sung, không cộng vào mẫu số chính.
- `henryfedotov1/Bagrut`: tự mô tả dự án phục vụ trường; không chọn tiếp để tránh trộn một ứng dụng trường học chưa rõ cấp học với corpus khóa học đại học.
- `alishakanwal2312/QuickBite-SRE-Project`: có bằng chứng học thuật nhưng chủ yếu SRS/Figma, không đủ mã nguồn luồng runtime để phân loại.

## Giới hạn

Khảo sát có thiên lệch công khai mã nguồn, tìm kiếm và lựa chọn chủ đích. Chưa chạy fault injection trên các dự án. Nhiều bối cảnh không có call-service hoặc phiên bàn, phải dùng mẫu số phù hợp. Không thấy một tổ hợp cơ chế trong mẫu là bằng chứng về khoảng trống **của mẫu đã kiểm tra**, không phải bằng chứng thế giới chưa có hoặc tỷ lệ phổ biến toàn ngành thấp.
