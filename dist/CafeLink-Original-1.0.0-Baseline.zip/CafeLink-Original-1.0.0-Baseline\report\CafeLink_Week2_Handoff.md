# CafeLink – Bàn giao tuần 2

**Đính chính 21/10/2026:** smoke cũ chưa kiểm tra listener đã đóng khi dừng Oracle Java wrapper, nên không dùng riêng nó làm bằng chứng JVM restart cuối. Xem [đính chính launcher](CafeLink_Launcher_Correction.md) và [bàn giao bản gốc](CafeLink_Original_Handoff.md) với smoke kiểm cổng sau sửa. Kết quả JUnit/campaign cùng JVM không bị thay đổi bởi lỗi launcher này.

Ngày **20/10/2026**. W2.1–W2.4 đã hoàn thành: code, kiểm thử từng phần, báo cáo và package. Không đánh dấu tuần 3 hoàn thành.

## Kết quả đã kiểm chứng

- **49 JUnit tests đạt**, 0 failures/errors/skipped; có 5 UI workflow tests qua Swing/TCP/SQLite thật.
- Receipt lưu cùng transaction nghiệp vụ; ID/nội dung cũ không tạo đơn mới, đổi nội dung bị chặn. Lỗi ghi receipt rollback cả đơn/revision.
- Credential guest gắn đúng một lượt, được giữ khi reconnect/restart; credential cũ không xem hoặc thao tác lượt mới, vẫn lấy outcome của chính nó.
- Outbox ghi trước gửi, lưu ID/payload/credential bằng atomic replace và file lock; không lưu password, không ghi đè dữ liệu hỏng.
- Đăng nhập lại đối chiếu outcome; chưa nhận thì cần khách xác nhận; sai lượt thành STALE. DISCARD_COMMAND ngăn ý định chưa nhận bị handler muộn tạo lại, không hủy đơn đã nhận.
- GUI có tab Phục hồi; bắt đầu lượt mới cần server xác nhận lượt cũ đã đóng và client đã giải quyết journal.
- Packaged smoke hai JVM và 24 ca đối chứng chức năng đạt.

## Báo cáo theo phần

| Mốc | Kiểm thử tại mốc | Tài liệu |
|---|---|---|
| W2.1 Receipt/outcome | 32 test đạt | [Part 1](CafeLink_W2_Part1_Report.md) |
| W2.2 Credential/lượt | 36 test đạt | [Part 2](CafeLink_W2_Part2_Report.md) |
| W2.3 Outbox/recovery | 48 test đạt | [Part 3](CafeLink_W2_Part3_Report.md) |
| W2.4 UI/package/đối chứng | 49 test + smoke + 24 ca | [Part 4](CafeLink_W2_Part4_Report.md) |

Các số là cumulative tại từng mốc, không cộng lại. [Bằng chứng ổn định](evidence/cafelink-week2/test-summary.json), [CSV](evidence/cafelink-week2/results.csv), [metadata](evidence/cafelink-week2/metadata.json). Source/raw artifact vẫn ở target; không chia sẻ journal vì chứa credential.

## Chạy và demo

Từ `D:\BTL-LTM\cafelink-system`:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/demo.ps1
```

Admin `admin / CafeLink@123`; bàn 1 `ban1 / Ban1@123` (tương tự 2–6). DB tự migration schema 1 → 3, không xóa dữ liệu. Journal GUI ở `data/client-state` theo host/cổng/tài khoản. Đóng cửa sổ cũ trước khi đăng nhập lại cùng tài khoản. Sau khi bàn đổi khách, không tự nhận lượt mới: dùng lựa chọn Bắt đầu lượt khách mới ở login.

Demo mất phản hồi: chạy server riêng `scripts/run-server.ps1 -DatabasePath data/recovery-demo.db -Fault drop-order-ack`, mở client admin/ban1, mở bàn và đặt. Server có đơn, khách mất kết nối. Đăng nhập lại cùng host/cổng/tài khoản, giữ credential mặc định: lấy đúng outcome, không có đơn thứ hai. Chi tiết [DEMO](../cafelink-system/docs/DEMO.md).

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/smoke.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/smoke.ps1 -Recovery
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/recovery-experiment.ps1 -Repetitions 3
```

## Ý nghĩa và giới hạn

Smoke `-Recovery` xác nhận bằng các tiến trình riêng: trước restart một đơn 30.000 VND, journal PENDING; sau restart vẫn một đơn, journal RESOLVED. Xem [populate](evidence/cafelink-week2/recovery-populate.json) và [restart](evidence/cafelink-week2/recovery-restart.json).

Đối chứng REPLAY_ALL có cùng receipt/idempotency/guard với REVIEW. Trong ba ca lời gọi chưa nhận, REPLAY_ALL tự tạo ba ticket; REVIEW giữ ba ca chờ xác nhận. Cả hai không tạo đơn trùng hoặc tác dụng sai lượt trong các ca tương ứng. Đây là khác biệt chính sách, không phải bằng chứng nhanh hơn hoặc thuật toán mới.

Không TTL/grant; cả đơn và lời gọi chưa nhận đều cần xác nhận rõ, với thông báo theo loại. Không tự reconnect ngầm, chưa TLS, chưa mã hóa credential at rest, chưa GC receipt/credential. Shared password mô phỏng thiết bị bàn, không phải xác minh khách ngoài đời. Chưa benchmark tải/LAN nhiều máy, phân tích thống kê hoặc so sánh B0 bỏ guard. Tuần 3 cần hoàn thiện các đo lường này và báo cáo trước hạn học phần 31/10/2026.

## Tài liệu đã cập nhật

[Báo cáo chính](CafeLink_Project_Report.md), [Word](CafeLink_Project_Report_Draft.docx), [README](../cafelink-system/README.md), [PROTOCOL](../cafelink-system/docs/PROTOCOL.md), [ADR-002](../cafelink-system/docs/architecture/ADR-002-recovery.md). Maven classes tách khỏi target/classes của IDE; jar vẫn tại target/cafelink-1.0.0.jar.

![Tab Phục hồi từ UI test thật](statics/cafelink-week2/guest-recovery.png)
