package com.cafelink.common;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;

/** Shared command classification and deterministic content fingerprints. */
public final class Commands {
    private Commands() { }
    private static final Set<String> MUTATIONS = Set.of("OPEN_TABLE", "PLACE_ORDER", "SET_ORDER_STATUS",
            "CALL_SERVICE", "REQUEST_BILL", "HANDLE_TICKET", "PAY_AND_CLOSE", "CLOSE_EMPTY_TABLE");
    public static boolean mutation(String action) { return MUTATIONS.contains(action); }
    public static boolean guestMutation(String action) { return Set.of("PLACE_ORDER", "CALL_SERVICE", "REQUEST_BILL").contains(action); }
    public static String fingerprint(String action, JsonObject data) { return digest(action + "\n" + canonical(data)); }
    public static String digest(String value) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8))); }
        catch (NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }
    private static String canonical(JsonElement value) {
        if (value.isJsonObject()) {
            StringJoiner result = new StringJoiner(",", "{", "}");
            new TreeSet<>(value.getAsJsonObject().keySet()).forEach(key -> result.add(Json.GSON.toJson(key) + ":" + canonical(value.getAsJsonObject().get(key))));
            return result.toString();
        }
        if (value.isJsonArray()) {
            StringJoiner result = new StringJoiner(",", "[", "]"); value.getAsJsonArray().forEach(item -> result.add(canonical(item))); return result.toString();
        }
        return value.toString();
    }
}
