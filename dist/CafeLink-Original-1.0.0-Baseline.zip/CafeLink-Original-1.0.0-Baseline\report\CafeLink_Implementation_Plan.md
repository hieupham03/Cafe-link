# Kế hoạch triển khai CafeLink — 3 tuần

Chốt 14/10/2026. Ba tuần là các mốc công việc tương đối theo yêu cầu; hạn nộp học phần hiện ghi 31/10/2026 trong Submission.md nên cần ưu tiên thực nghiệm/báo cáo trước hạn đó. Không suy ra hạn nộp được gia hạn thêm 21 ngày.

**Cập nhật bản gốc:** W1/W2 hoàn thành; W3 đã đo và kiểm chạy trên một máy: 59/59 test Java (0 failures/errors/skipped), 3 test bộ phân tích Python, 180/180 ca phục hồi, 20/20 lần đo tải với 10,800 request và 0 lỗi. Xem [bản gốc](CafeLink_Original_Handoff.md), [truy vết](CafeLink_Requirements_Traceability.md). LAN hai máy NOT RUN, metadata nhóm hoãn theo người dùng; thủ tục nộp chưa thực hiện.

**Kế hoạch nâng cấp bổ sung:** [CafeLink_Upgrade_Plan.md](CafeLink_Upgrade_Plan.md) cụ thể hóa công việc 21–31/10 sau khi đối chiếu repo TOEIC: JOIN/resume/reconnect, policy phục hồi khác nhau thật sự, dashboard/menu và thực nghiệm/đóng gói. Các gói U0–U6 hiện là kế hoạch, chưa triển khai tính năng U1–U5; dùng baseline gốc đã đóng gói làm E0. Lịch, ưu tiên P0/P1 và điểm cắt phạm vi nằm trong tài liệu đó.

## Phạm vi và quyết định

Một quán, 6 bàn, 8 đồ uống, chủ quán và khách tại bàn. Java 17+, Swing, TCP Socket, JSON có tiền tố độ dài, SQLite/JDBC. Một Maven project với package common/server/client; ứng dụng Server, Quản trị và Khách là các entry point riêng. Mã tạo mới, không kế thừa repository khảo sát.

Tuần 1 hoàn thành baseline có thể demo xuyên suốt: khởi động server, đăng nhập, mở bàn, đặt nhiều món, chủ quán chuyển trạng thái, gọi phục vụ/yêu cầu hóa đơn, xử lý ticket, tính tiền và đóng bàn; lưu dữ liệu qua restart; nhiều client và server push. Auth gắn với TCP connection; quyền và bàn do server quyết định. Đây là bản LAN demo, TCP chưa có TLS. Giá và tổng tiền tính trên server bằng số nguyên VND.

Baseline chưa tự phát lại thao tác chưa rõ kết quả. Khi connection lỗi client phải kết nối lại/đăng nhập và đọc trạng thái trước khi thao tác. Request ID dùng tương quan phản hồi tuần 1; receipt bền vững và outbox là contribution tuần 2. Vòng đời bàn được tạo ngay để tránh phải sửa schema lớn; week 2 bổ sung hợp đồng phục hồi và thực nghiệm đối chứng.

## Tuần 1 — các phần phải triển khai, kiểm thử, báo cáo

| Phần | Deliverable | Kiểm thử trước khi tiếp tục |
|---|---|---|
| W1.1 Nền tảng | pom, Maven bootstrap, DTO, frame codec/version/giới hạn frame | Unicode, nhiều frame, chia nhỏ bytes, EOF giữa frame, length/JSON/version sai |
| W1.2 Dữ liệu/nghiệp vụ | schema seed, password hash, service/transactions, menu, bàn, đơn/ticket/hóa đơn | login, quyền, validation, giá server, trạng thái, rollback, đóng bàn, restart |
| W1.3 TCP | accept/read/write, auth connection, RPC, server push, giới hạn kết nối/hàng đợi | socket thật: roles, isolation, broadcasts, malformed client, disconnect, concurrent clients |
| W1.4 Giao diện | server console, login, bảng chủ quán và màn hình khách | kiểm tra component/actions và smoke trên desktop nếu môi trường cho phép |
| W1.5 Tích hợp/bàn giao | scripts, README, protocol, demo, dữ liệu mẫu, artifact kiểm thử | workflow đầu-cuối qua TCP, restart, đóng server, build package từ script |

Mỗi phần có báo cáo `CafeLink_W1_PartN_Report.md`, ghi trạng thái, file chính, câu lệnh chạy, kết quả thực tế và giới hạn. Không tự bịa số test/latency. Khi gặp lỗi: sửa nguyên nhân rồi chạy lại kiểm thử liên quan, sau đó tiếp tục phần tiếp theo. Report tổng hợp cuối tuần phân biệt kiểm thử tự động với kiểm tra giao diện thủ công.

## Tuần 2 — contribution

Đã hoàn thành, báo cáo chi tiết [W2.1](CafeLink_W2_Part1_Report.md), [W2.2](CafeLink_W2_Part2_Report.md), [W2.3](CafeLink_W2_Part3_Report.md), [W2.4](CafeLink_W2_Part4_Report.md). Phạm vi thu hẹp được ghi trong ADR-002: không TTL/grant; các ý định chưa nhận cần xác nhận lại, có giải thích theo loại; reconnect chủ động. Đối chứng đã có REPLAY_ALL (idempotency + guard) và REVIEW; B0 không guard chưa triển khai.

1. Ledger receipt: request ID + principal + phiên + fingerprint; transaction cùng mutation; query outcome sau mất ACK.
2. Client outbox bền vững, phục hồi theo loại: đối chiếu đơn trước replay; lời gọi phục vụ chưa nhận cần khách xác nhận lại.
3. Guard phiên bàn nguyên tử khi mở/đóng; handler/outbox cũ không tác động khách mới.
4. Fault injection sau commit/trước ACK và trước tiếp nhận; baseline đã có idempotency để so sánh chính sách.

## Tuần 3 — kiểm chứng và báo cáo

Workload bình thường + mất mạng ngắn/dài + đổi lượt khách + nhiều client. Đo đơn trùng, sai phiên, yêu cầu cũ, phục hồi median/p95, byte mạng và số lần khách xác nhận lại. Cùng workload/fault schedule cho baseline/proposed. Hoàn thiện báo cáo paper, README chạy từ máy sạch, demo và tài liệu bảo vệ.

## Quy tắc nghiệp vụ bản đầu

- Chủ quán mở phiên trước khi khách đặt. Guest login trước lúc mở vẫn xem menu nhưng không gửi mutation.
- Một bàn có tối đa một phiên active. Login/connection không tự tạo hoặc kết thúc lượt khách.
- Đơn đi theo SUBMITTED → PREPARING → READY → SERVED. Không bỏ qua trạng thái. Sửa/hủy món là mở rộng.
- Ticket CALL_SERVICE/REQUEST_BILL có OPEN → HANDLED; có phản hồi của chủ quán. Một loại ticket OPEN mỗi phiên để hạn chế bấm nhiều lần.
- Thanh toán mô phỏng chỉ khi có đơn và tất cả đơn SERVED, các ticket đã xử lý. Tổng do server tính; ghi một hóa đơn/phiên và đóng phiên trong một transaction.
- Khách chỉ đọc/đặt cho bàn được tài khoản gán; chủ quán xem toàn bộ. Password lưu PBKDF2 có salt, không ghi request login vào log.
- Request lỗi trả error code, không kết thúc server. Frame sai được cô lập ở connection đó. Hàng đợi gửi giới hạn; client chậm không giữ khóa database khi server ghi socket.

## Tiêu chí hoàn thành tuần 1

Build/run/test bằng script; không cần Maven cài toàn hệ thống. Server và ít nhất 3 client demo được đầy đủ luồng. Có SQLite seed và persistence. Có kiểm thử socket thật và test nghiệp vụ có ý nghĩa. README ghi tài khoản demo, cách chạy LAN, trạng thái baseline và những phần contribution chưa thực hiện.
