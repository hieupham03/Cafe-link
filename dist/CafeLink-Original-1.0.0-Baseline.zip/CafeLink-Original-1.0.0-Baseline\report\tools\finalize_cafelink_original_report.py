"""Fill measured sections only after the original-baseline evidence audit passed."""
from pathlib import Path
import csv
import json

REPORT = Path(__file__).resolve().parents[1]
EVIDENCE = REPORT / "evidence/cafelink-original"


def replace_section(text, heading, next_heading, body):
    start, end = text.index(heading), text.index(next_heading, text.index(heading))
    return text[:start] + body.rstrip() + "\n\n" + text[end:]


def main():
    summary = json.loads((EVIDENCE / "summary.json").read_text(encoding="utf-8"))
    tests = json.loads((EVIDENCE / "test-summary.json").read_text(encoding="utf-8"))
    if summary["status"] != "PASS":
        raise ValueError("Audited passing evidence required")
    env, recovery = summary["environment"], summary["recoveryEnvironment"]
    if (env["clientCounts"], env["repetitions"], env["durationSeconds"], env["warmupSeconds"], env["periodMillis"], recovery["repetitions"], recovery["offlineSeconds"]) != ([1, 5, 10, 20], 5, 60, 10, 1000, 5, [2, 10, 60]):
        raise ValueError("This report template requires the documented original-baseline campaign configuration")
    total = tests["totals"]["tests"]
    source = REPORT / "CafeLink_Project_Report.md"
    text = source.read_text(encoding="utf-8")
    status = "**Trạng thái bản thảo:** bản gốc tuần 1–3 đã hoàn tất các phần kiểm chứng được trên một máy: " + f"{total} test đạt, {summary['benchmarkCases']} lần đo tải và {summary['recoveryCases']} ca phục hồi. Có dữ liệu thô, biểu đồ, oracle SQLite và bộ đóng gói baseline. LAN vật lý hai máy chưa chạy; bìa/thành viên hoãn theo người dùng. Compilatio và thủ tục nộp chưa thực hiện. Xem [bàn giao bản gốc](CafeLink_Original_Handoff.md). Các gói nâng cấp U1–U5 vẫn là đề xuất."
    text = replace_section(text, "**Trạng thái bản thảo:**", "## Tóm tắt", status)
    abstract = f"""## Tóm tắt (Abstract)

CafeLink giải quyết gọi món và điều phối phục vụ cho một quán café theo mô hình Client/Server. Client Swing giao tiếp TCP Socket bằng JSON có tiền tố độ dài; server xác thực, lưu SQLite và chủ động gửi cập nhật. Receipt nguyên tử, outbox ghi trước gửi và credential gắn lượt giúp lấy lại kết quả sau mất phản hồi, yêu cầu khách xác nhận ý định chưa được nhận và chặn yêu cầu của lượt cũ. Bản gốc đạt {total} test; {summary['benchmarkCases']} lần đo tải 1/5/10/20 guest trên loopback ghi nhận {summary['requests']:,} request, {summary['errors']} lỗi; {summary['recoveryCases']} ca phục hồi ở khoảng offline 2/10/60 giây đạt. Trong 15 ca lời gọi chưa nhận của mỗi policy, REVIEW không tự tạo ticket, REPLAY_ALL tạo 15 ticket trước khi khách xác nhận lại. Hai policy cùng idempotency/guard và không ghi nhận đơn trùng hoặc tác dụng sai lượt trong các ca đã xét. Kết quả hỗ trợ tính đúng của hợp đồng phục hồi trong phạm vi thực nghiệm; chưa đo LAN vật lý, công suất tối đa hoặc hiệu quả tại quán thực tế.

**Từ khóa:** Client/Server; TCP Socket; giao thức ứng dụng; xử lý đồng thời; phục hồi kết nối; phiên sử dụng bàn.
"""
    text = replace_section(text, "## Tóm tắt", "## Mục lục", abstract)
    environment = """### 8.1. Môi trường kiểm thử và đo bản gốc

| Thành phần | Thông tin đo/kiểm tra thực tế |
|---|---|
| Hệ điều hành | Windows 11 Home, build 26200 |
| CPU | Intel Core i7-12700H, 14 nhân vật lý / 20 luồng logic |
| RAM | 16.907.980.800 byte, xấp xỉ 15,75 GiB |
| Java | JDK 24.0.2; compile target 17, chưa thử runtime 17 riêng |
| Build/test | Maven 3.9.11, JUnit Jupiter 5.11.4 |
| Network tải | TCP 127.0.0.1; server và load-client ở hai JVM riêng; mỗi case DB mới |
| Network phục hồi | TCP loopback; mỗi case server/client cùng JVM nhưng socket/DB riêng; sáu case độc lập chạy song song |
| Persistence | SQLite JDBC 3.50.3.0, WAL; journal file riêng mỗi guest |
| UI | Desktop thật; 5 UI test không bị skip, modal có seam trả lời |
| Dữ liệu mẫu | Sáu bàn, tám đồ uống; admin và sáu tài khoản bàn |

Metadata môi trường/JAR hash: [environment.json](evidence/cafelink-original/raw/benchmark/environment.json). Chỉ có một máy; không coi loopback là LAN hai máy. Chạy headless có thể skip UI nên phải công bố số skip.
"""
    text = replace_section(text, "### 8.1.", "### 8.2.", environment)
    setup = """### 8.3. Thiết kế thực nghiệm đã chạy

**Đối chứng phục hồi:** REPLAY_ALL và REVIEW dùng cùng mã server, receipt bền vững, fingerprint, guard lượt và credential. Chỉ thay quyết định đối với ý định chưa được nhận: REPLAY_ALL gửi lại, REVIEW giữ chờ khách xác nhận. REVIEW hiện áp dụng quy tắc xác nhận cho cả đơn lẫn lời gọi, chưa có TTL hoặc policy SEMANTIC. Không triển khai B0 bỏ guard; không dùng đối chứng yếu hơn để gán toàn bộ hiệu quả chống lặp cho REVIEW.

| Kịch bản | Fault / lịch | Oracle độc lập |
|---|---|---|
| NORMAL | Không fault, không chờ offline | Một đơn, đúng receipt |
| LOST_ORDER_ACK | Ngắt sau commit đặt món, trước response | Một đơn, lấy lại outcome |
| UNACCEPTED_ORDER | Ngắt trước handler | REVIEW cần xác nhận, REPLAY_ALL có một đơn |
| UNACCEPTED_SERVICE | Ngắt trước handler gọi phục vụ | REVIEW chưa tạo ticket, REPLAY_ALL tạo một ticket |
| LOST_SERVICE_ACK | Ngắt sau commit ticket | Một ticket, lấy lại outcome |
| VISIT_CHANGED | Chưa nhận lời gọi, đóng/mở bàn trước reconnect | Không đơn/ticket ở lượt mới từ ý định cũ |

2 policy × 6 kịch bản × 3 khoảng offline (2/10/60 giây) × 5 lần = 180 ca. Lịch được shuffle với seed 20261020; sáu fixture độc lập chạy song song, không dùng thời gian này kết luận hiệu năng chính sách. Offline là khoảng không có guest kết nối, server còn chạy; đây là fault tầng ứng dụng, chưa mô phỏng packet loss vật lý. NORMAL mang nhãn cấu hình delay nhưng thời gian offline thực bằng 0; không đưa NORMAL vào phân tích ảnh hưởng offline.

**Đo tải hoạt động bình thường:** 1/5/10/20 guest, mỗi mức 5 lần; warmup 10 giây, cửa sổ đo 60 giây, 1 request/giây/guest, mỗi slot thứ năm đặt một cà phê sữa 30.000 VND, còn lại GET_STATE. Mỗi guest có một socket/worker/journal; một admin mở sáu bàn và nhận push. Các lần lặp đảo thứ tự tăng/giảm số client để giảm thiên lệch thứ tự. Server và load-client là hai JVM riêng; không chạy campaign phục hồi/build cùng lúc. Đây là workload cố định, chưa tìm điểm bão hòa hoặc đo riêng overhead trước/sau contribution.

Raw request và kết quả từng lần nằm trong `evidence/cafelink-original/raw/benchmark/`. Launcher chạy JVM thật từ java.home, ghi javaExecutable/runtimeLauncherSha256 vào environment và bắt buộc listenerClosed=True sau mỗi case. Đợt trước dùng Oracle forwarding PID đã được loại khỏi baseline cuối; xem [đính chính launcher](CafeLink_Launcher_Correction.md). DB thật còn ở `cafelink-system/target/benchmark-*` và `target/recovery-experiment-*`; analyzer mở read-only, kiểm integrity/foreign key, đếm đơn/ticket/receipt/tổng tiền. Không đưa DB chứa credential/hash hoặc private outbox vào evidence công khai.

### 8.4. Định nghĩa chỉ số thực tế

| Chỉ số | Cách đo và giới hạn |
|---|---|
| Latency request | nanoTime quanh RPC; đặt món gồm ghi journal. p50/p95 nearest-rank gộp mẫu từng mức tải, có dữ liệu từng lần. Giữ cả mẫu lỗi/timeout; không dùng thời gian suite JUnit |
| Request/s hoàn tất | Số response OK trong cửa sổ mẫu / 60 giây hoặc thời gian có drain nếu dài hơn; gồm đọc và đặt món, không chỉ mutation |
| Đơn trùng/sai lượt | Đối chiếu SQLite với số tác dụng mong đợi từng ý định/lượt; receipt đặt món phải bằng số đơn |
| Ticket chưa xác nhận lại | Ticket tự tạo ở UNACCEPTED_SERVICE trước hành động xác nhận mới của khách; không đồng nghĩa nhu cầu thực tế chắc chắn hết hiệu lực |
| Thời gian phục hồi | Reconnect + login PBKDF2 + journal/refresh/lookup/reconcile, loại thời gian offline; chưa gồm chờ người dùng xác nhận |
| Traffic | Byte guest đọc và write hoàn tất, gồm header frame 4 byte/event/heartbeat; không gồm admin/TCP/IP; partial write lỗi có thể chưa đếm |
| Storage | Journal JSON guest và kích thước DB/WAL tại mốc chụp; không phải số byte riêng receipt hoặc tổng footprint JDK |

Mốc chụp traffic sau warmup có độ lệch nhỏ với cửa sổ request; `byteCaptureStartOffsetMs` và thời gian drain được giữ trong summary. Journal/DB benchmark gồm cả warmup. Process peak có trong dữ liệu thô ở target nhưng không dùng để kết luận CPU/RAM do không lấy mẫu cửa sổ đo và peak client sau exit không đáng tin cậy.
"""
    text = replace_section(text, "### 8.3.", "## 9.", setup)
    table = ["### 9.1. Kiểm thử tự động bản gốc", "", f"Build đầy đủ xác nhận **{total} tests, 0 failures/errors/skipped**. [Surefire summary](evidence/cafelink-original/test-summary.json) và XML đã lưu kèm evidence. Tuần 1 có 27 test, tuần 2 có 49 test; không ghi đè các báo cáo lịch sử.", "", "| Suite | Tests | Failures | Errors | Skipped |", "|---|---:|---:|---:|---:|"]
    for row in tests["suites"]:
        table.append(f"| {row['suite'].split('.')[-1]} | {row['tests']} | {row['failures']} | {row['errors']} | {row['skipped']} |")
    table += [f"| **Tổng** | **{total}** | **0** | **0** | **0** |", "", "Các ca bổ sung kiểm tra byte frame, socket thứ 33 bị từ chối, peer không đọc bị ngắt khi queue đầy, cleanup thread, lock journal khi server không sẵn sàng, mất ACK lúc bỏ yêu cầu và lúc thanh toán. [Báo cáo W3.1](CafeLink_W3_Part1_Report.md) giải thích phạm vi. Các test cũ vẫn kiểm tra rollback trigger, race payment/order, 12 guest đặt đồng thời, UI và cô lập quyền."]
    text = replace_section(text, "### 9.1.", "### 9.2.", "\n".join(table))
    results = (EVIDENCE / "RESULTS.md").read_text(encoding="utf-8").splitlines()
    rows = [line for line in results if line.startswith("|")]
    storage_rows = ["| Guest | Gửi TB (KiB) | Nhận TB (MiB) | Journal TB (KiB) | DB/WAL TB (KiB) |", "|---|---:|---:|---:|---:|"]
    for row in summary["load"]:
        storage_rows.append(f"| {row['clients']} | {row['meanSentKiB']:.2f} | {row['meanReceivedKiB']/1024:.2f} | {row['meanJournalKiB']:.2f} | {row['meanDatabaseKiB']:.2f} |")
    measured = """### 9.4. Đo tải và phục hồi bản gốc

""" + "\n".join(rows) + f"""

Tổng **{summary['requests']:,} request, {summary['errors']} lỗi** trong 20 lần đo. Số request/s là tải đạt được với lịch 1 request/giây/guest, chưa phải công suất tối đa. p95 gộp mẫu không phải khoảng tin cậy; khoảng dao động throughput từng lần nằm trong [benchmark-summary.csv](evidence/cafelink-original/benchmark-summary.csv), latency/storage/byte từng lần trong [benchmark-runs.csv](evidence/cafelink-original/benchmark-runs.csv).

![Hình 8. Latency và request/s của workload loopback cố định; mỗi mức tải năm lần.](evidence/cafelink-original/load-results.png)

""" + "\n".join(storage_rows) + f"""

TB là trung bình năm lần. Traffic đo sau warmup đến khi worker kết thúc; storage gồm dữ liệu warmup, DB/WAL ở mốc launcher chụp. Số byte nhận tăng nhanh theo số client: mã hiện tại broadcast snapshot sau mutation, đồng thời nhiều guest chia sẻ cùng bàn sẽ nhận danh sách đơn dài hơn. Đây là dấu hiệu để đánh giá U5 giảm push thừa trong giai đoạn nâng cấp, chưa chứng minh U5 đã giảm byte hoặc là nút thắt tại quán thực tế.

Campaign phục hồi **180/180 ca đạt**, gồm 15 ca mỗi kịch bản/policy. Không ghi nhận đơn trùng hoặc tác dụng sai lượt trong phạm vi này. LOST_ORDER_ACK và LOST_SERVICE_ACK đều lấy lại một kết quả đã lưu. REVIEW giữ 15 đơn chưa nhận và 15 lời gọi chưa nhận chờ xác nhận; REPLAY_ALL tự gửi lại. Riêng UNACCEPTED_SERVICE, REPLAY_ALL tạo 15 ticket trước khi xác nhận lại, REVIEW tạo 0. Đây là khác biệt chính sách, không chứng minh nhu cầu tại quán thực sự đã hết hoặc REVIEW nhanh hơn.

[Raw recovery CSV](evidence/cafelink-original/raw/recovery/results.csv), [cấu hình/lịch](evidence/cafelink-original/raw/recovery/metadata.json), [nhóm theo policy/scenario/delay](evidence/cafelink-original/recovery-summary.csv), [oracle SQLite](evidence/cafelink-original/database-oracle.csv), [hash evidence](evidence/cafelink-original/evidence-sha256.json).

### 9.5. Nghiệm thu còn cần điều kiện ngoài máy hiện tại

LAN vật lý hai máy **NOT RUN** vì người dùng chỉ có một máy. Bộ lệnh và biên bản [LAN_ACCEPTANCE.md](../cafelink-system/docs/LAN_ACCEPTANCE.md) đã chuẩn bị. Bìa/thành viên hoãn theo yêu cầu; Compilatio, duyệt bố cục Word trực quan và nộp chính thức chưa có bằng chứng. Không chuyển các mục này thành PASS bằng kết quả localhost.
"""
    text = replace_section(text, "### 9.4.", "## 10.", measured)
    text = text.replace("49 test không chứng minh", f"{total} test không chứng minh")
    text = text.replace("chưa có B0 không guard hoặc đánh giá đủ lớn để kết luận mức giảm lỗi thực tế.", "campaign 180 ca mở rộng số lần kiểm tra nhưng chưa đánh giá người dùng hoặc mạng Wi-Fi thực để kết luận mức giảm lỗi ngoài quán.")
    text = text.replace("Receipt/outbox làm tăng storage và xử lý; chi phí này chưa được đo riêng. Các chi phí sau cùng phải được đo để tránh chỉ báo cáo lợi ích.", "Receipt/outbox làm tăng storage và xử lý; dung lượng journal/DB và byte toàn ứng dụng đã ghi theo từng lần nhưng chưa tách overhead riêng bằng ablation trước/sau contribution.")
    text = text.replace("Receipt/Outbox/Recovery integration/UI tests; ba ca lời gọi B1/B2 khác nhau", "Receipt/Outbox/Recovery/UI tests; 180 ca fault, 15 ca lời gọi mỗi policy")
    text = text.replace("chưa TTL/benchmark |", "chưa TTL; chưa tách overhead từng cơ chế |")
    text = text.replace("Chưa benchmark tải/LAN nhiều máy, thử dài hạn, phân trang hoặc event delta.", "Đã đo tải loopback, chưa chạy LAN nhiều máy, thử dài hạn, phân trang hoặc event delta.")
    text = text.replace("Ưu tiên hoàn thiện thực nghiệm tải/LAN và đánh giá chi phí C1/C2 trước khi mở rộng tính năng.", "Ưu tiên nghiệm thu LAN khi có máy thứ hai; giữ bản gốc đã đóng gói làm mốc E0 để đo phần nâng cấp. Chỉ triển khai các gói trong CafeLink_Upgrade_Plan.md khi chuyển sang giai đoạn nâng cấp.")
    conclusion = f"""## 14. Kết luận

CafeLink đã hoàn thành bản gốc Client/Server TCP có xác thực, nhiều client, server push, transaction SQLite, receipt/outbox và quyền theo lượt. Kết quả có {total} test đạt, smoke qua JVM và restart, 20 lần đo tải với {summary['requests']:,} request/{summary['errors']} lỗi và 180 ca phục hồi đối chứng. REVIEW giữ lời gọi chưa nhận chờ khách xác nhận, tránh 15 ticket tự phát lại so với REPLAY_ALL trong workload đã xét; cả hai cùng cơ chế chống lặp và guard lượt.

Đóng góp là hợp đồng phục hồi ứng dụng và bộ kiểm chứng tái lập, không phải thuật toán mới hoặc bảo đảm exactly-once. Bản gốc có baseline đóng gói và evidence để chuẩn bị nâng cấp. LAN vật lý, kiểm chứng thực tế tại quán và thủ tục nộp vẫn cần bổ sung đúng điều kiện.
"""
    text = replace_section(text, "## 14.", "## 15.", conclusion)
    text = text.replace("| Tiếp theo | C1/C2 và thực nghiệm | [Kế hoạch triển khai](CafeLink_Implementation_Plan.md) |", "| W2 | Receipt, outbox và guard lượt | [Tuần 2](CafeLink_Week2_Handoff.md) |\n| W3 | Test, đo tải/fault, báo cáo và đóng gói | [Bản gốc](CafeLink_Original_Handoff.md), [truy vết](CafeLink_Requirements_Traceability.md) |")
    text = text.replace("- [ ] Ghi cấu hình CPU/RAM/OS/network và cấu hình từng đối chứng.", "- [x] Ghi CPU/RAM/OS/network, policy, seed và workload trong metadata.")
    text = text.replace("- [ ] Hoàn thành benchmark tải/LAN và biểu đồ tuần 3.", "- [x] Benchmark loopback, campaign offline và biểu đồ bản gốc; raw data/oracle lưu kèm.\n- [ ] LAN vật lý hai máy: NOT RUN, một máy hiện có; runbook đã chuẩn bị.")
    text = text.replace("- [ ] Cập nhật Abstract, Discussion, Contributions và Conclusion theo kết quả cuối.", "- [x] Cập nhật Abstract, Discussion, Contributions và Conclusion theo evidence bản gốc.")
    text = text.replace("- [ ] Rà lại citation, nguồn dự án và trạng thái các placeholder.", "- [x] Giữ nguồn/citation và tách rõ placeholder, giới hạn cùng công việc ngoài máy.")
    text = text.replace("- [ ] Xuất DOCX; đổi tên thành", "- [x] Xuất DOCX kỹ thuật tương ứng Markdown; cần người xem bố cục Word và đổi tên thành")
    text = text.replace("- [ ] Đóng gói source chạy được và báo cáo theo", "- [x] Đóng gói source/runtime/báo cáo baseline, manifest; trước nộp đổi tên nhóm theo")
    source.write_text(text, encoding="utf-8")
    print(f"Updated {source}; measured facts read from audited evidence.")


if __name__ == "__main__":
    main()
