# Đối chiếu contribution và prior art của năm đề tài

Ngày kiểm tra: 14/10/2026. Phạm vi: nguồn gốc của các cơ chế, khả năng đề xuất contribution hẹp và cách đánh giá. Đây là khảo sát có giới hạn, không phải kết luận về toàn bộ nghiên cứu hay tỷ lệ phổ biến của đề tài sinh viên.

## Kết luận

Các contribution ban đầu — retry/idempotency, giữ chỗ theo TTL, ACK, snapshot/delta, giao lại công việc và chỉ giữ bản cập nhật mới nhất — đều có tiền lệ rõ. Không thể dùng chúng để khẳng định “thực sự mới”. Ghép nhiều cơ chế đã có cũng chưa tự tạo ra novelty. Những biến thể dưới đây là **ứng viên chính sách hoặc thiết kế riêng cần kiểm chứng**, chưa có kết quả thực nghiệm và chưa đủ bằng chứng để tuyên bố mới trên thế giới hoặc ít phổ biến toàn ngành.

Một contribution có thể bảo vệ ở cấp bài tập lớn cần nêu: trường hợp baseline xử lý kém; quy tắc nhóm tự đề xuất; khác biệt với nguồn đã có; điều kiện áp dụng; thực nghiệm cả lợi ích và chi phí. Xếp hạng đề xuất bên dưới là nhận định về giá trị triển khai và đánh giá, không phải mức novelty đã xác minh.

## 1. CafeLink: yêu cầu ngoại tuyến bị thay thế hoặc hủy

**Cập nhật sau khi chốt đề tài:** contribution cuối cùng là phục hồi yêu cầu theo loại và phiên sử dụng bàn, xem [CafeLink_Final_Proposal.md](CafeLink_Final_Proposal.md). Đã khảo sát 11 dự án sinh viên/môn học và một đối chứng cuối khóa Java. Trong luồng đã đọc chưa ghi nhận receipt/outcome theo ID lệnh ở 11 mẫu chính; guard lượt khách nguyên tử chưa ghi nhận ở 5 mẫu sinh viên có bàn. Tiêu chí deadline phục vụ/tính tiền chỉ có một mẫu áp dụng, chưa đủ kết luận về độ phổ biến. Đây là khảo sát sơ bộ có chủ đích, không đại diện toàn bộ bài tập lớn; các mẫu, SHA và bằng chứng nằm trong Survey A/B/C. Phần ý định sửa/hủy bên dưới là hướng mở rộng, không phải contribution bắt buộc.

**Tiền lệ:** [Stripe](https://docs.stripe.com/api/idempotent_requests) đã cung cấp idempotency key để retry mà không tạo thao tác trùng. [Cassandra](https://cassandra.apache.org/doc/latest/cassandra/managing/operating/compaction/tombstones.html) dùng tombstone để dữ liệu xóa không bị hồi sinh từ bản cũ. Đặc biệt, [Apache Seata TCC](https://seata.apache.org/zh-cn/blog/seata-tcc/#如何处理悬挂) mô tả đúng tình huống Cancel tới trước Try do trễ mạng và ghi trạng thái để chặn Try đến muộn. Vì vậy, “hủy tới trước tạo + dấu hủy” đã có tương đương rất trực tiếp.

**Ứng viên hẹp:** protocol biểu diễn ý định của một bàn bằng `(tableSession, intentId, revision)`; một ý định chưa bắt đầu phục vụ có thể tăng revision hoặc hủy; server không để revision cũ tái tạo đơn. Lượt khách mới có tableSession do server cấp; gói của lượt khách cũ không thể sửa đơn mới. Sau khi server chuyển đơn sang “bắt đầu chế biến”, việc hủy tự động chấm dứt và trả kết quả rõ. Barrier này cần được kiểm tra nguyên tử với việc áp dụng revision.

**Contribution có thể viết:** thiết kế quy tắc áp dụng ý định ngoại tuyến có ranh giới bắt đầu phục vụ, và đánh giá khả năng chống hồi sinh yêu cầu, gửi thừa và thay đổi nhầm lượt bàn. Điều này là ứng dụng chuyên biệt của versioning/tombstone/fencing, chưa chứng minh là thuật toán mới.

**Đánh giá:** baseline phải đã có idempotency. So sánh retry mọi thao tác với protocol ý định theo revision; đảo thứ tự thao tác ở tầng ứng dụng qua các lần reconnect; ngắt trước/sau barrier. Đo đơn bị hồi sinh, lệnh bị từ chối đúng/sai, byte truyền và bộ nhớ lưu trạng thái. TCP không đảo byte trong cùng kết nối; sự đảo thứ tự cần đến từ hàng đợi ứng dụng, nhiều kết nối hoặc reconnect. Tombstone không được xóa khi còn khả năng chấp nhận request cũ.

## 2. SeatLink: giảm ưu thế mạng nhanh trong tranh ghế

**Tiền lệ:** [Redis TTL locks](https://redis.io/docs/latest/develop/clients/patterns/distributed-locks/) đã có khóa hết hạn. [Frequent Batch Auctions](https://doi.org/10.1093/qje/qjv027) đã xem việc gom thao tác theo khoảng thời gian là cách giảm cuộc đua tốc độ. [DBO — SIGCOMM 2023](https://www.microsoft.com/en-us/research/wp-content/uploads/2023/09/sigcomm23-final811.pdf) nghiên cứu thứ tự công bằng dưới chênh lệch độ trễ. Gom cửa sổ hoặc tính độ trễ không phải ý tưởng mới tự thân.

**Ứng viên hẹp:** server đo RTT/jitter trước khi mở tranh ghế, dùng chính sách cửa sổ có giới hạn; mỗi danh tính xác thực chỉ có một yêu cầu hợp lệ cho mỗi ghế trong cửa sổ; chọn ngẫu nhiên giữa các yêu cầu hợp lệ, không lấy timestamp client làm thứ tự. So sánh cửa sổ cố định với cửa sổ dựa trên phân phối độ trễ đã quan sát.

**Contribution có thể viết:** đề xuất và khảo sát chính sách cân bằng xác suất thắng và thời gian phản hồi cho mô hình đặt ghế có cửa sổ tranh chấp. Phải phát biểu rằng công bằng chỉ trong tập yêu cầu tới kịp cửa sổ; không bảo đảm người bấm trước thắng hay công bằng tuyệt đối.

**Đánh giá:** so sánh first-arrival, cửa sổ cố định và cửa sổ thích nghi; lặp nhiều vòng có các lớp độ trễ; đo xác suất thắng theo lớp mạng, độ trễ p95 và tỷ lệ trượt cửa sổ. Phải xét client cố tình trì hoãn echo để làm RTT tăng, danh tính trùng và bất đối xứng đường truyền. LAN tốt có ít chênh lệch RTT: lợi ích cần được kiểm chứng trong điều kiện thực tế, cùng kịch bản trễ có kiểm soát.

## 3. QueueLink: bù mất lượt có giới hạn theo bằng chứng hiển thị

**Tiền lệ:** [Twilio delivery receipts](https://www.twilio.com/docs/conversations-classic/delivery-receipts-overview) phân biệt sent/delivered/read. [RabbitMQ ACK](https://www.rabbitmq.com/docs/confirms) phân biệt xác nhận broker với xác nhận consumer xử lý. [Qmatic Serve view](https://docs.qmatic.io/en/staff-user-guides/user-guide--serve-view.html) đã có Recall, No-show và Recycle về đầu hàng đợi. ACK ở tầng giao diện và quay lại hàng đợi đều không mới.

**Ứng viên hẹp:** phân biệt CALL_SENT, CALL_DISPLAYED và USER_CONFIRMED; thời gian phản hồi bắt đầu sau CALL_DISPLAYED nhưng tổng giữ quầy bị chặn bởi hard deadline từ lúc gọi. Nếu chưa có bằng chứng hiển thị tới hạn, nhường quầy và cấp quyền phục hồi vị trí có giới hạn; giới hạn số lần bù và thời gian hiệu lực để tránh giữ chỗ vô hạn. CALL_DISPLAYED cần gắn đúng callId và phiên client.

**Contribution có thể viết:** chính sách bù mất lượt có ngân sách thời gian theo bằng chứng giao thông báo, đánh giá đánh đổi giữa mất lượt do sự cố mạng và quầy bị giữ bởi client không phản hồi. Đây là hướng có câu hỏi đo lường rõ, nhưng vẫn cần tìm thêm prior art trước khi khẳng định mới.

**Đánh giá:** baseline timeout cố định phải có retry/ACK cơ bản; thêm đối chứng “đợi DISPLAYED vô hạn” và chính sách bị chặn thời gian. Đo lượt chưa được hiển thị nhưng bị loại, thời gian quầy nhàn rỗi, độ trễ người phía sau và lạm dụng quyền phục hồi. Thiếu ACK không chứng minh thông báo chưa hiển thị; có DISPLAYED không chứng minh con người đã đọc hay đã tới quầy. Do đó chỉ kết luận dựa trên bằng chứng mà protocol thu được.

## 4. TaskFarm: dự đoán chi phí toàn bộ trước khi chọn worker

**Tiền lệ:** [HEFT gốc](https://disco.ethz.ch/courses/fs14/seminar/paper/Jochen/4.pdf) đã tính chi phí compute và communication; [Network-Aware HEFT](https://pmc.ncbi.nlm.nih.gov/articles/PMC3919093/) tiếp tục nghiên cứu mô hình mạng. [Dask Work Stealing](https://distributed.dask.org/en/stable/work-stealing.html) xét tỷ lệ compute/communication, backlog và thời gian hoàn tất dự đoán; có EWMA từ các tác vụ trước. [LATE, OSDI 2008](https://www.usenix.org/legacy/event/osdi08/tech/full_papers/zaharia/zaharia_html/) đã chọn node nhanh và giới hạn speculative copies. Vì vậy, “worker nhanh/mạng nhanh”, retry hoặc chạy bản sao khi chậm đều đã được nghiên cứu.

**Ứng viên hẹp:** với tác vụ ảnh độc lập, mô hình thời gian gồm chờ + truyền ảnh đầu vào + xử lý theo megapixel/tác vụ + trả kết quả; đo hai chiều mạng riêng. Chính sách lựa chọn có biên bất định và ngưỡng cải thiện tối thiểu để tránh đảo lựa chọn theo nhiễu đo. So sánh rõ các thành phần với lựa chọn chỉ dựa CPU và lựa chọn end-to-end không có ngưỡng.

**Contribution có thể viết:** mô hình và chính sách được hiệu chỉnh cho tập tác vụ ảnh trong LAN không đồng nhất; chứng minh trường hợp máy CPU nhanh nhưng đường truyền chậm khiến lựa chọn theo CPU kém hơn. Đây là contribution về thiết kế/đánh giá mô hình hẹp; thêm biên bất định hoặc hysteresis chưa đủ tự chứng minh mới.

**Đánh giá:** round-robin, worker đang rảnh, CPU-only, end-to-end và bản có ngưỡng; trộn ảnh nhỏ/lớn và mạng biến động. Đo makespan, p95, byte truyền, sai số dự đoán và số lần đổi kế hoạch. Cần ablation để biết biên bất định có tác dụng. Chưa nên thêm speculation nếu thời gian hạn chế: nó làm tăng độ khó và có prior art rất rõ. Worker chết vẫn cần attemptId; chấp nhận một kết quả không có nghĩa tác vụ chỉ chạy đúng một lần.

## 5. ScreenHub: hàng đợi biết ngữ nghĩa của nhiều phần màn hình

**Tiền lệ:** [ZeroMQ CONFLATE](https://libzmq.readthedocs.io/en/latest/zmq_setsockopt.html#zmq-conflate-keep-only-last-message) đã giữ message mới nhất; [Akka conflate](https://doc.akka.io/libraries/akka-core/current/stream/operators/Source-or-Flow/conflate.html) gộp dữ liệu dưới backpressure. [Hazelcast](https://docs.hazelcast.org/docs/3.6.6/manual/html-single/index.html) đã coalesce theo key. [RabbitMQ priority](https://www.rabbitmq.com/docs/priority) đã có ưu tiên. [BrightSign](https://docs.brightsign.biz/technical/video-wall-sync-architecture) đã đồng bộ trạng thái nhiều màn hình qua thời điểm và đồng hồ PTP. Cả “prepare/commit để đổi cảnh” lẫn “latest-only” đều không nên quảng bá là mới.

**Ứng viên hẹp:** định nghĩa nhóm widget độc lập; mỗi nhóm chỉ giữ trạng thái mới nhất chưa gửi, nhưng event bắt buộc như chuỗi cảnh báo vẫn giữ thứ tự. Event có phụ thuộc revision tạo barrier để không bị gửi với nội dung chưa phù hợp. Lịch gửi dùng ngân sách byte, kích thước frame/chunk giới hạn và mức phục vụ tối thiểu cho từng loại dữ liệu. Nếu các widget phải đổi cùng nhau, phải dùng cùng nhóm revision thay vì gộp độc lập.

**Contribution có thể viết:** chính sách gộp cập nhật và lập lịch theo phụ thuộc ngữ nghĩa cho màn hình client chậm, đánh giá độ mới nội dung và độ trễ sự kiện bắt buộc. Đây là thiết kế chuyên biệt; combination không chứng minh novelty.

**Đánh giá:** FIFO, latest-only toàn màn hình, latest-per-widget và policy có dependency/barrier + ngân sách byte. Đo trạng thái thiếu/sai, tuổi dữ liệu, p95 cảnh báo, byte truyền và starvation. Ngân sách byte chỉ điều khiển dữ liệu chưa ghi vào socket, không thu hồi byte đã gửi; cần giới hạn kernel/application buffers và tránh frame quá lớn. Không bảo đảm độ trễ tuyệt đối khi mất kết nối. [RFC 8290](https://www.rfc-editor.org/rfc/rfc8290.html) là prior art liên quan của lập lịch và giảm head-of-line blocking ở tầng packet, không phải chứng cứ rằng policy widget đã mới.

## Khuyến nghị thực tế

- **QueueLink:** câu hỏi contribution dễ phát biểu, tác động của lỗi mạng trực tiếp tới người dùng và dễ tạo demo; cần quy tắc bù chặt để khác với ACK + recall thông thường.
- **TaskFarm:** mạnh về đo lường lập trình mạng; chọn mô hình hẹp, đối chứng mạnh và ablation; không tuyên bố network-aware scheduling là phát minh mới.
- **SeatLink:** demo đẹp nhưng fairness khó định nghĩa, nhiều prior art và có đánh đổi độ trễ; không nên chọn nếu nhóm không muốn làm nhiều thực nghiệm.
- **CafeLink:** giữ được nghiệp vụ dễ hiểu nhưng cancellation/tombstone có prior art gần như trực tiếp; phù hợp contribution cấp môn học hơn yêu cầu novelty mạnh.
- **ScreenHub:** có khả năng demo tốt; bản cơ bản rất phổ biến, bản có phụ thuộc và lập lịch mới có câu hỏi kỹ thuật đủ sâu.

Các ứng viên đều chưa được triển khai hay kiểm nghiệm trong lượt nghiên cứu này. Cần thống nhất với giảng viên “mới” là mới ở cấp đồ án có cải tiến so với baseline hay đòi hỏi novelty nghiên cứu; tài liệu này không tự giải quyết được yêu cầu thứ hai.

## Nguồn đối chiếu bổ sung

- [Mantri — Microsoft Research](https://www.microsoft.com/en-us/research/publication/reining-outliers-map-reduce-clusters-using-mantri/) đã xử lý tác vụ chậm dựa trên nguyên nhân và chi phí tài nguyên, gồm bố trí có xét mạng. Vì vậy, thêm chi phí mạng vào retry/speculation cũng chưa tạo ra thuật toán mới. TaskFarm nên giới hạn nghiên cứu vào chính sách biên bất định và ngưỡng đổi kế hoạch, so sánh với bộ lập lịch đã xét chi phí truyền dữ liệu.
- [Scheduling Policies for Minimizing Age of Information in Broadcast Wireless Networks](https://arxiv.org/abs/1801.01803) đã nghiên cứu lập lịch theo độ mới thông tin có trọng số. ScreenHub có thể tham khảo hướng này, nhưng áp dụng AoI hoặc đổi công thức ưu tiên chưa chứng minh novelty. Mô hình LAN/TCP, nhóm nội dung phụ thuộc và sự kiện bắt buộc cần được phát biểu riêng, cùng đối chứng phù hợp.

Không có khảo sát định lượng về mức phổ biến của những cơ chế trên trong đồ án sinh viên hoặc sản phẩm toàn ngành. Không dùng việc chưa tìm thấy triển khai giống hệt làm bằng chứng rằng một cơ chế mới hoặc ít phổ biến.
