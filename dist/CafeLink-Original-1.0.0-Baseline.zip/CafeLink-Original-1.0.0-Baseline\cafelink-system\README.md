# CafeLink — Bản gốc

Cập nhật bản gốc: **59 test Java đạt, 180 ca phục hồi đạt và 20 lần đo tải đạt (10,800 request, 0 lỗi)**. Có raw data, biểu đồ, oracle SQLite và bản đóng gói kiểm chạy từ đường dẫn sạch. Xem [bàn giao](../report/CafeLink_Original_Handoff.md), [số liệu](../report/evidence/cafelink-original/RESULTS.md). LAN vật lý hai máy chưa chạy vì chỉ có một máy. U1–U5 vẫn là kế hoạch.

Ứng dụng desktop Client/Server TCP cho một quán café: 6 bàn, 8 đồ uống, đặt món, gọi phục vụ, yêu cầu tính tiền, phản hồi, tiến độ đơn và thanh toán mô phỏng. Server giữ SQLite, guest chỉ thấy bàn được tài khoản gán. Giá tính tại server bằng số nguyên VND.

## Kiến trúc

```
Client khách (Swing) ── TCP length-prefix JSON ── CafeServer ── CafeService ── SQLite
Client chủ quán ────────────────────────────────────┘
Server console: start/log/stop + mở màn hình đăng nhập chủ quán
```

32 reader connections tối đa; writer + queue 64 message mỗi connection. Một reader ở client phân tuyến response/event. Server push snapshot theo quyền và business revision. Socket I/O không giữ lock database. JDBC truy cập được tuần tự hóa; đây là thiết kế cho phạm vi quán nhỏ, không phải benchmark mở rộng.

## Yêu cầu và build

JDK **17+**, PowerShell trên Windows, Internet cho lần tải dependency đầu. Môi trường phát triển đã kiểm tra JDK 24.0.2. Maven bootstrap 3.9.11 vào `.tools`, kiểm tra SHA-512; không cần Maven trong PATH.

**Đường dẫn cài đặt:** dùng thư mục ASCII, ví dụ `D:\CafeLink Demo\`, có thể có khoảng trắng. Ca chạy từ thư mục có dấu tiếng Việt chưa đạt trên JDK24/Windows hiện tại (`native.encoding=Cp1252` làm hỏng tham số classpath); xem giới hạn này trước khi giải nén. Nội dung tiếng Việt trong giao diện/message vẫn được kiểm tra bằng UTF-8; giới hạn ở tên thư mục launcher.

Tại `cafelink-system`:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build.ps1
```

Build chạy tests và tạo `target/cafelink-1.0.0.jar`, `target/lib/`. Build nhanh khi đã có test evidence: thêm `-SkipTests`. Sau khi sửa code phải build lại trước khi chạy app. Linux/macOS có thể dùng Maven đã cài: `mvn package`, rồi Java classpath với dấu `:` thay `;`.

Thư viện runtime: Gson 2.11.0, SQLite JDBC 3.50.3.0, SLF4J Simple 2.0.16. Test: JUnit Jupiter 5.11.4. GUI Swing thuộc JDK, không sử dụng code từ các repository khảo sát.

## Chạy server và client

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/run-server.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/run-client.ps1 -Username admin
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/run-client.ps1 -Username ban1
```

Mỗi lệnh chạy ở terminal riêng. Server console cũng có nút mở màn hình chủ quán. `scripts/demo.ps1` mở một server và ba client tương tác trong các cửa sổ riêng; nhập mật khẩu tại giao diện. Nếu cổng 5050 đang dùng, chọn `-Port 5051` cho tất cả ứng dụng; script không dừng tiến trình không thuộc demo.

| Tài khoản | Mật khẩu demo | Quyền |
|---|---|---|
| admin | CafeLink@123 | Chủ quán |
| ban1 … ban6 | Ban1@123 … Ban6@123 | Chỉ bàn tương ứng |

Mật khẩu demo được seed một lần, lưu hash PBKDF2/salt; không ghi password vào log. Đây là ứng dụng LAN demo, TCP không mã hóa; không dùng mật khẩu thật/triển khai Internet với cấu hình này.

LAN: server dùng `-BindAddress 0.0.0.0`, client dùng `-ServerAddress <IPv4 máy server>` và cùng cổng. Cho phép cổng TCP qua firewall bằng cấu hình mạng của máy. Không cần database server bên ngoài. Client trên máy khác chỉ cần JDK + jar/lib/scripts. [Bộ nghiệm thu LAN](docs/LAN_ACCEPTANCE.md) có lệnh probe và checklist; hiện NOT RUN trên hai máy vật lý.

Database mặc định `data/cafelink.db`, tạo thư mục/schema/menu/accounts tự động; seed không ghi đè dữ liệu có sẵn. Có thể chọn `-DatabasePath <file.db>` để demo trên database mới. Giữ cả DB/WAL trong lúc server chạy; dừng server trước khi sao lưu. Schema hiện tại là 3; tự bổ sung receipt/credential vào DB tuần 1, không xóa dữ liệu.

## Workflow demo

1. Đăng nhập admin và các bàn 1–3. Guest xem menu nhưng chưa đặt khi chủ quán chưa mở bàn.
2. Chủ quán chọn bàn và Mở bàn. Guest nhận cập nhật tự động.
3. Khách chọn số lượng, note, Đặt món. Chủ quán nhìn đơn đúng giá và lần lượt chuyển Chờ tiếp nhận → Đang chuẩn bị → Sẵn sàng → Đã phục vụ.
4. Khách Gọi nhân viên/Yêu cầu tính tiền. Chủ quán chọn ticket, nhập phản hồi; guest nhận phản hồi.
5. Xem hóa đơn. Khi mọi đơn được phục vụ và ticket đã phản hồi, chủ quán xác nhận Thanh toán & đóng bàn. Phiếu lưu DB, phiên kết thúc. Bàn trống có thao tác đóng riêng, không tạo thanh toán giả.
6. Ngắt client: màn hình báo mất kết nối và khóa mutation. Đăng nhập lại cùng host/cổng/tài khoản: credential và ID được lấy từ outbox, kết quả đã nhận được tra cứu, yêu cầu chưa nhận xuất hiện trong tab Phục hồi. Chỉ gửi lại khi khách xác nhận; không tự chuyển yêu cầu sang lượt mới.
7. Khi đổi khách, client cũ mất quyền xem/thao tác lượt mới. Sau khi xử lý outbox, đăng nhập lại và chọn “Bắt đầu lượt khách mới”; server chỉ cho phép khi lượt trước đã đóng.

Client GUI lưu journal trong `data/client-state/` theo host/cổng/tài khoản; không lưu mật khẩu, có lưu credential phục hồi. Không chia sẻ file này cho người khác. Hai cửa sổ cùng journal bị chặn bằng file lock; dùng client khác tài khoản cho các bàn khác. Đóng cửa sổ cũ trước khi đăng nhập lại. Outbox lỗi không tự bị ghi đè. Với API `NetworkClient` trong kiểm thử, constructor không có Path vẫn là client không lưu journal; GUI luôn bật journal.

## Kiểm thử và bằng chứng

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/maven.ps1 -B test
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/smoke.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/smoke.ps1 -Recovery
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/recovery-experiment.ps1 -Repetitions 3
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/recovery-experiment.ps1 -Repetitions 5 -OfflineSeconds '2,10,60' -Parallelism 6
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/benchmark.ps1 -ClientCounts '1,5,10,20' -Repetitions 5 -DurationSeconds 60 -WarmupSeconds 10
```

JUnit reports: `target/surefire-reports`. UI screenshots từ Swing thật: `target/ui-smoke`. UI tests chạy actual TCP+SQLite, chỉ thay câu trả lời modal; môi trường headless skip chúng nên phải ghi nhận skip, không coi là UI verified.

Smoke chạy packaged ServerMain và DemoSmokeMain ở **hai JVM riêng**, ba guest connections, server restart dùng cùng SQLite. Mỗi lần tạo thư mục `target/smoke-<id>` có DB/log/kết quả JSON, không đụng database demo của người dùng. Script cố ý dừng server process của chính nó để kiểm tra persistence sau ngắt tiến trình; không đánh giá crash/power-loss trong mọi tình huống.

Kết quả chi tiết tại [bàn giao bản gốc](../report/CafeLink_Original_Handoff.md). Tests localhost không chứng minh throughput trên LAN nhiều máy. `recovery-experiment.ps1` so sánh REVIEW với REPLAY_ALL (đều có durable idempotency + guard lượt), lưu CSV/log/metadata ở target/recovery-experiment-ID. Campaign phục hồi có fixture socket thật trong cùng JVM, độc lập mỗi ca; chạy song song chỉ kiểm tính đúng. `benchmark.ps1` đo workload bình thường ở hai JVM riêng, giữ CSV từng request, metadata và DB đối chiếu. Không chạy đồng thời hai campaign nếu muốn diễn giải latency tải.

Analyzer `../report/tools/analyze_cafelink_experiments.py` đọc raw CSV và SQLite read-only; xuất p50/p95, throughput, byte/storage, biểu đồ và oracle. Cần Python + matplotlib để phân tích, không cần Python để mở ứng dụng. Lỗi/timeout được giữ trong dữ liệu; byte đếm ở tầng ứng dụng, không gồm TCP/IP.

## Contribution và giới hạn hiện tại

Mutation có command ID ổn định, fingerprint và receipt cùng transaction; GET_OUTCOME lấy lại kết quả sau mất phản hồi. Credential guest được gắn một lượt, không tự chuyển lượt. Outbox ghi trước gửi, đăng nhập lại dùng credential cũ và đối chiếu outcome. Yêu cầu chưa nhận cần xác nhận; DISCARD_COMMAND bỏ ý định chưa nhận bằng dấu chặn bền vững, không hủy đơn đã nhận. START_NEW_VISIT chỉ cấp quyền mới khi lượt cũ đóng. Wire frame vẫn version 1; các action/Identity mới được mô tả ở PROTOCOL.

Không triển khai TTL/grant, tự reconnect ngầm hoặc lưu mật khẩu. Bản thu hẹp yêu cầu người dùng chủ động kết nối lại và xác nhận nhu cầu chưa được nhận, áp dụng cho cả đơn và lời gọi. LAN vật lý nhiều máy cần nghiệm thu bổ sung khi có máy thứ hai. Maven output nằm tại target/maven-classes và maven-test-classes để tách khỏi output language server của IDE.

Không có sửa/hủy món đã nhận, tồn kho, nhiều cửa hàng, payment gateway hoặc TLS. Chủ quán xác nhận trạng thái pha/phục vụ thực tế; không claim exactly-once delivery/hành động vật lý. Tài khoản bàn là mô hình terminal demo: người biết mật khẩu có thể chủ động xin credential mới bằng client khác. Chưa là cơ chế xác minh danh tính khách hoặc cấp quyền QR cho thiết bị cá nhân.

## Tài liệu và nguồn

- [Kế hoạch nâng cấp trước 31/10](../report/CafeLink_Upgrade_Plan.md): các gói đề xuất sau tuần 2, ưu tiên và tiêu chí nghiệm thu; chưa phải tính năng đã triển khai.
- [Báo cáo dự án](../report/CafeLink_Project_Report.md), [bản Word](../report/CafeLink_Project_Report_Draft.docx), [truy vết yêu cầu](../report/CafeLink_Requirements_Traceability.md). Bìa/thành viên hoãn theo người dùng; không có kết quả Compilatio hoặc LAN hai máy.
- [Protocol](docs/PROTOCOL.md), [demo và bảo vệ](docs/DEMO.md).
- Học phần: `../final-project/Instruction.md`, `Topics.md`, `Submission.md`.
- [Gson](https://github.com/google/gson), [SQLite JDBC](https://github.com/xerial/sqlite-jdbc), [JUnit](https://docs.junit.org/5.11.4/user-guide/), [Maven](https://maven.apache.org/).
- Khảo sát contribution: `../report/CafeLink_Final_Proposal.md` và các Survey A/B/C. Kỹ thuật đơn lẻ đã có tiền lệ; không tuyên bố novelty toàn cầu.
