package com.cafelink.server;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** A single SQLite connection, owned and serialized by CafeService. */
final class Database implements AutoCloseable {
    @FunctionalInterface interface Mapper<T> { T map(ResultSet row) throws SQLException; }
    @FunctionalInterface interface Work<T> { T run() throws SQLException; }
    private final Connection connection;
    Database(Path path) throws Exception {
        Path absolute = path.toAbsolutePath(); Files.createDirectories(absolute.getParent());
        connection = DriverManager.getConnection("jdbc:sqlite:" + absolute);
        try (Statement s = connection.createStatement()) {
            s.execute("PRAGMA foreign_keys=ON"); s.execute("PRAGMA busy_timeout=5000"); s.execute("PRAGMA journal_mode=WAL");
        }
        int version = query("PRAGMA user_version", r -> r.getInt(1)).get(0);
        if (version < 0 || version > 3) { close(); throw new SQLException("Unsupported database schema " + version); }
        String[] schema = {
            "CREATE TABLE IF NOT EXISTS cafe_tables(id INTEGER PRIMARY KEY,name TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS accounts(username TEXT PRIMARY KEY,password_hash TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('ADMIN','GUEST')),table_id INTEGER REFERENCES cafe_tables(id))",
            "CREATE TABLE IF NOT EXISTS visits(id TEXT PRIMARY KEY,table_id INTEGER NOT NULL REFERENCES cafe_tables(id),active INTEGER NOT NULL CHECK(active IN(0,1)),opened_at TEXT NOT NULL,closed_at TEXT)",
            "CREATE UNIQUE INDEX IF NOT EXISTS one_active_visit ON visits(table_id) WHERE active=1",
            "CREATE TABLE IF NOT EXISTS menu(id INTEGER PRIMARY KEY,name TEXT NOT NULL,price_vnd INTEGER NOT NULL CHECK(price_vnd>0),category TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,visit_id TEXT NOT NULL REFERENCES visits(id),status TEXT NOT NULL CHECK(status IN('SUBMITTED','PREPARING','READY','SERVED')),note TEXT NOT NULL,created_at TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS order_items(order_id INTEGER NOT NULL REFERENCES orders(id),menu_id INTEGER NOT NULL REFERENCES menu(id),name TEXT NOT NULL,quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 20),unit_price_vnd INTEGER NOT NULL CHECK(unit_price_vnd>0),PRIMARY KEY(order_id,menu_id))",
            "CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY AUTOINCREMENT,visit_id TEXT NOT NULL REFERENCES visits(id),type TEXT NOT NULL CHECK(type IN('CALL_SERVICE','REQUEST_BILL')),status TEXT NOT NULL CHECK(status IN('OPEN','HANDLED')),note TEXT NOT NULL,reply TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL)",
            "CREATE UNIQUE INDEX IF NOT EXISTS one_open_ticket ON tickets(visit_id,type) WHERE status='OPEN'",
            "CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,visit_id TEXT NOT NULL UNIQUE REFERENCES visits(id),total_vnd INTEGER NOT NULL CHECK(total_vnd>0),method TEXT NOT NULL,paid_at TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS metadata(name TEXT PRIMARY KEY,value INTEGER NOT NULL)",
            "INSERT OR IGNORE INTO metadata(name,value) VALUES('revision',0)",
            "CREATE TABLE IF NOT EXISTS command_receipts(principal TEXT NOT NULL,command_id TEXT NOT NULL,action TEXT NOT NULL,fingerprint TEXT NOT NULL,result_json TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(principal,command_id))",
            "CREATE TABLE IF NOT EXISTS guest_credentials(token_hash TEXT PRIMARY KEY,username TEXT NOT NULL REFERENCES accounts(username),visit_id TEXT REFERENCES visits(id),created_at TEXT NOT NULL)",
            "PRAGMA user_version=3"
        };
        try { for (String sql : schema) update(sql); seed(); }
        catch (Exception e) { close(); throw e; }
    }
    private void seed() throws SQLException {
        transaction(() -> {
            for (int table = 1; table <= 6; table++) {
                update("INSERT OR IGNORE INTO cafe_tables VALUES(?,?)", table, "Bàn " + table);
                if (query("SELECT username FROM accounts WHERE username=?", r -> r.getString(1), "ban" + table).isEmpty())
                    update("INSERT INTO accounts VALUES(?,?,?,?)", "ban" + table, PasswordHash.create("Ban" + table + "@123"), "GUEST", table);
            }
            if (query("SELECT username FROM accounts WHERE username='admin'", r -> r.getString(1)).isEmpty())
                update("INSERT INTO accounts VALUES(?,?,?,NULL)", "admin", PasswordHash.create("CafeLink@123"), "ADMIN");
            String[] names = {"Cà phê đen", "Cà phê sữa", "Bạc xỉu", "Latte", "Trà đào", "Trà chanh", "Cacao", "Nước suối"};
            long[] prices = {25000, 30000, 35000, 45000, 40000, 25000, 40000, 15000};
            for (int i = 0; i < names.length; i++) update("INSERT OR IGNORE INTO menu VALUES(?,?,?,?)", i + 1, names[i], prices[i], i < 4 ? "Cà phê" : "Đồ uống khác");
            return null;
        });
    }
    <T> List<T> query(String sql, Mapper<T> mapper, Object... args) throws SQLException {
        try (PreparedStatement statement = prepare(sql, args); ResultSet rows = statement.executeQuery()) {
            List<T> result = new ArrayList<>(); while (rows.next()) result.add(mapper.map(rows)); return result;
        }
    }
    int update(String sql, Object... args) throws SQLException { try (PreparedStatement s = prepare(sql, args)) { return s.executeUpdate(); } }
    long insert(String sql, Object... args) throws SQLException { update(sql, args); return query("SELECT last_insert_rowid()", r -> r.getLong(1)).get(0); }
    private PreparedStatement prepare(String sql, Object... args) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(sql);
        try { for (int i = 0; i < args.length; i++) statement.setObject(i + 1, args[i]); return statement; }
        catch (SQLException e) { statement.close(); throw e; }
    }
    <T> T transaction(Work<T> work) throws SQLException {
        connection.setAutoCommit(false);
        try { T value = work.run(); connection.commit(); return value; }
        catch (SQLException | RuntimeException e) { connection.rollback(); throw e; }
        finally { connection.setAutoCommit(true); }
    }
    @Override public void close() throws SQLException { connection.close(); }
}
