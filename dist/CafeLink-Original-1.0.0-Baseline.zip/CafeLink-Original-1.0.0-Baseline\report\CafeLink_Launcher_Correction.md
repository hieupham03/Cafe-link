# Đính chính nghiệm thu launcher — 21/10/2026

## Nguyên nhân và sửa chữa đã kiểm chứng

`Get-Command java` trên máy này trỏ tới Oracle `javapath/java.exe`, là process chuyển tiếp. `Start-Process` lấy PID của process này; `Stop-Process` dừng wrapper nhưng có thể để JVM con vẫn giữ cổng. Một smoke cũ có thể kết nối lại server cũ và in PASS mà chưa thực sự restart. Trong campaign tải cũ, JVM của case trước còn sống khi case sau bắt đầu.

`scripts/runtime.ps1` nay lấy `java.home` bằng probe không có classpath, sau đó chạy trực tiếp `java.home/bin/java.exe`. `smoke.ps1` dừng JVM thật và bắt buộc xác nhận TCP listener đã đóng trước khi mở server mới. `benchmark.ps1` xác nhận cổng đã đóng sau từng case; CSV có `listenerClosed`. Analyzer từ chối case thiếu bằng chứng này. Validator package yêu cầu dòng chứng minh đóng listener trong stdout smoke.

Hai smoke trực tiếp sau sửa đã đạt:

| Ca | Kết quả | Artifact |
|---|---|---|
| Bình thường | 3 đơn, 190.000 VND, 1 ticket HANDLED sau JVM restart; listener cũ đã đóng | `target/smoke-06fc09f5c5d74f33b31044d74060cf86/` |
| Mất ACK | 1 đơn, 30.000 VND, journal PENDING→RESOLVED qua JVM mới; listener cũ đã đóng | `target/smoke-d7d285c272ff4fbfa8542bde6fc8e33f/` |

Đã dừng 25 JVM xác định bằng đúng thư mục fixture do task tạo; inventory lưu ở `evidence/cafelink-diagnostics/owned-orphan-processes.csv`. Không dừng server dữ liệu demo/người dùng hoặc Java language server.

## Dữ liệu nào còn dùng được

- 59 JUnit và 180 ca phục hồi cùng JVM không dùng launcher process ngoài này, giữ kết quả với giới hạn đã nêu.
- Campaign tải cũ `benchmark-5372d5c03aa047739b62c50fd4160788` có 10.800 request đối chiếu đúng DB, nhưng **không dùng latency/isolation làm E0 cuối**. Evidence được giữ ở `evidence/cafelink-original-superseded/`, có SUPERSEDED.txt.
- Smoke cũ chưa xác nhận listener đóng không được dùng làm bằng chứng restart cuối. Main report dùng hai smoke mới và package validation sau sửa.
- Đã chạy lại và nghiệm thu đủ 20 lần (1/5/10/20 guest × 5), 10 giây warmup và 60 giây đo. Chỉ dữ liệu có listenerClosed=True ở mọi case được chấp nhận.

## Giới hạn thư mục có dấu

Kiểm thư mục sạch còn tái hiện probe java.home bị kẹt vì đọc hai pipe tuần tự. Đã sửa đọc đồng thời trước khởi động server/client; payload/request/JAR/JVM thực thi không đổi, benchmark không đo startup latency. Hồ sơ `evidence/cafelink-original/launcher-startup-patch.json` giữ hash nguồn khi đo và khi đóng gói, kèm source/diff chính xác. Dùng kiểm smoke/build của gói sau vá làm bằng chứng khởi chạy; không coi startup này đã được benchmark.

Thử JDK trực tiếp trên Windows hiện tại ghi `native.encoding=Cp1252`; classpath có tên thư mục tiếng Việt bị mất ký tự, dù manifest file đúng. Thư mục ASCII có khoảng trắng tải được lớp. Chưa sửa hỗ trợ đường dẫn tiếng Việt; README/runbook quy định thư mục ASCII. Đây là giới hạn riêng, không bị gộp vào PASS của thư mục ASCII; message UTF-8 vẫn có test riêng.

Kết quả cuối có 20/20 listenerClosed=True, đủ 10.800 request và oracle SQLite đạt; xem `evidence/cafelink-original/` và bàn giao bản gốc.
