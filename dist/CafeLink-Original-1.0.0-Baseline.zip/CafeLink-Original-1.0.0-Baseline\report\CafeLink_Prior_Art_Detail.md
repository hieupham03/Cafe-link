# CafeLink: đối chiếu prior art và phạm vi contribution có thể bảo vệ

Ngày khảo sát: 14/10/2026. Nguồn: đặc tả, tài liệu nhà cung cấp và tác giả cơ chế. Đây là khảo sát cơ chế kỹ thuật; không phải mẫu thống kê đề tài sinh viên.

## 1. Kết luận

Không nên đăng ký contribution dưới tên “retry/chống đơn trùng”, “offline ordering”, “TTL”, hoặc “session bàn”. Các ý tưởng này có tiền lệ rõ. Phần có thể đầu tư ở cấp bài tập lớn là **thiết kế và đánh giá một hợp đồng phục hồi yêu cầu theo vòng đời nghiệp vụ, có hàng rào phiên sử dụng bàn**.

Hợp đồng này trả lời đồng thời bốn câu hỏi:

1. Yêu cầu đã được server chấp nhận hay chưa khi client mất xác nhận?
2. Yêu cầu nào cần được phục hồi và yêu cầu nào cần xác nhận lại vì đã cũ?
3. Một yêu cầu của lượt khách trước có được phép thay đổi bàn ở lượt khách sau?
4. Một yêu cầu sửa/hủy được phục hồi khi nhân viên đã bắt đầu chế biến phải được xử lý thế nào?

Đây là contribution về thiết kế giao thức ứng dụng và thực nghiệm. Việc phối hợp kỹ thuật đã có không tự chứng minh novelty toàn cầu. Mức “ít gặp trong bài tập lớn” phải được kiểm tra trên một mẫu dự án sinh viên độc lập, với tiêu chí công khai và kiểm tra mã nguồn khi khả thi.

## 2. Những tiền lệ trực tiếp

| Nguồn gốc | Hành vi được nguồn mô tả | Giới hạn đối với claim CafeLink |
|---|---|---|
| [Stripe — Idempotent requests](https://docs.stripe.com/api/idempotent_requests) | Dùng cùng idempotency key để lấy lại kết quả, tránh tạo thay đổi trùng; đối chiếu tham số | `requestId` và chống tạo đơn trùng là kỹ thuật có sẵn |
| [AWS Builders' Library — Making retries safe](https://aws.amazon.com/builders-library/making-retries-safe-with-idempotent-APIs/) | Phân biệt request trùng bằng ID; ghi ID và thay đổi nguyên tử; xử lý retry đến muộn và tham số thay đổi | Kết quả tương đương, thời hạn lưu ID và late retry đều có tiền lệ |
| [Square — Update Orders](https://developer.squareup.com/docs/orders-api/manage-orders/update-orders) | Yêu cầu `order.version` hiện hành; thay đổi mới dùng idempotency key mới | Kiểm tra revision và idempotency cho sửa đơn không phải ý tưởng mới |
| [Odoo 19 — Workflow, Offline POS](https://www.odoo.com/documentation/19.0/applications/sales/point_of_sale/use.html) | Cache dữ liệu, lưu đơn ngoại tuyến và đồng bộ khi kết nối lại; một số chức năng phụ thuộc backend không hoạt động ngoại tuyến | “Lưu đơn offline rồi sync” đã là chức năng thương mại |
| [Toast — Offline mode overview](https://doc.toasttab.com/doc/platformguide/adminOfflineModeOverview.html) | Đơn được lưu trên thiết bị khi offline; local hub có thể phân phối giữa thiết bị trong LAN; cảnh báo lượng đơn sau khôi phục có thể làm quá tải bếp | Mất mạng và đồng bộ đơn là vấn đề thực tế nhưng không mới |
| [MQTT 5.0, §3.3.2.3.3](https://docs.oasis-open.org/mqtt/mqtt/v5.0/os/mqtt-v5.0-os.html) | `Message Expiry Interval` cho phép loại bản message chưa bắt đầu chuyển tiếp khi hết hạn | “Không giao message đã hết hạn” có trong đặc tả chuẩn |
| [Apache Seata — TCC](https://seata.apache.org/blog/seata-tcc/) | Cancel có thể đến trước Try; ghi trạng thái ngăn Try đến muộn gây giữ tài nguyên | Tombstone/hủy trước tạo không thể quảng bá là mới |
| [Martin Kleppmann — Fencing](https://martin.kleppmann.com/2016/02/08/how-to-do-distributed-locking.html) | Token tăng theo lần cấp quyền; nơi ghi dữ liệu từ chối thao tác với token cũ | Epoch bàn chặn client cũ là ứng dụng của version/fencing |

Các nguồn nhà cung cấp trên mô tả một số hành vi, không phải toàn bộ nội bộ sản phẩm. Không được chuyển “không thấy đặc tả cùng tổ hợp” thành “sản phẩm không hỗ trợ” hoặc “CafeLink là đầu tiên”.

Nguồn Odoo được thu thập qua kết quả tìm kiếm trang chính thức; truy cập trực tiếp trang có lúc timeout. Cần kiểm tra lại nếu đưa đoạn mô tả cụ thể vào báo cáo nộp cuối cùng.

## 3. Đề xuất contribution chính

> Nhóm thiết kế và đánh giá giao thức phục hồi yêu cầu CafeLink theo vòng đời nghiệp vụ. Giao thức đối chiếu kết quả đã lưu trước khi gửi lại; áp dụng chính sách phục hồi khác nhau cho đặt món, yêu cầu phục vụ và yêu cầu sửa/hủy; đồng thời ràng buộc mỗi thay đổi vào phiên bàn hiện hành nhằm hạn chế thao tác trùng, yêu cầu hết hiệu lực và thay đổi nhầm lượt khách khi mạng gián đoạn.

Điểm đáng khảo sát là **tính đúng của việc phục hồi**, không chỉ số lần message được giao. Một retry thành công về mặt kỹ thuật vẫn có thể sai về mặt sử dụng: gọi nhân viên sau khi khách đã rời đi, gửi lại yêu cầu tính tiền sau khi bàn đã đóng, hoặc hủy món đã bắt đầu pha.

Toast nêu trực tiếp tình huống đơn đến dồn sau sự cố có thể gây quá tải bếp. Điều này hỗ trợ tính thực tế của việc xét lại yêu cầu phục hồi; không chứng minh rằng một ngưỡng hết hạn CafeLink cụ thể sẽ có lợi. [Toast Offline mode overview](https://doc.toasttab.com/doc/platformguide/adminOfflineModeOverview.html).

### 3.1 Bảng chính sách

| Loại | Đã được server chấp nhận nhưng client mất ACK | Server chưa ghi nhận | Ràng buộc khi phục hồi |
|---|---|---|---|
| `PLACE_ORDER` | Trả lại outcome và trạng thái đơn hiện hành, không tạo lại | Có thể gửi lại cùng ID nếu phiên bàn còn hiệu lực và nội dung được khách xác nhận còn cần | Đơn chờ lâu không được tự gửi chỉ vì đó là dữ liệu bền vững |
| `CALL_SERVICE` | Lấy trạng thái yêu cầu đã có; không tạo cuộc gọi mới | Nếu hết admission deadline, trả `EXPIRED`; client đề nghị khách gọi lại | Hết deadline không xóa lịch sử hay âm thầm hủy công việc đã được nhận |
| `REQUEST_BILL` | Lấy trạng thái yêu cầu hoặc snapshot hóa đơn hiện hành | Kiểm tra thời hạn và phiên; yêu cầu mới sau phục hồi cần khách xác nhận | Đây là yêu cầu phục vụ, không phải lệnh thanh toán tiền thật |
| `EDIT_ORDER` / `CANCEL_ORDER` | Trả lại kết quả lệnh cũ và trạng thái mới nhất | Kiểm tra `expectedVersion` và trạng thái trước chế biến trong cùng transaction | Nếu đã `PREPARING`, trả lý do từ chối; không hiển thị hủy thành công cục bộ |
| `CHAT` | Phục hồi lịch sử tin và ID đã được nhận | Chính sách lưu/gửi tin riêng theo phiên | Có thể bỏ khỏi contribution để giữ phạm vi nhỏ |

Chính sách cụ thể là lựa chọn thiết kế của nhóm, chưa có kết quả đánh giá. Quy tắc gọi phục vụ hết hiệu lực cần giải thích với chủ quán; không coi mọi yêu cầu trợ giúp đều có cùng TTL.

### 3.2 Hàng rào phiên bàn

Server quản lý `tableId`, `tableSessionId` và `sessionEpoch`; mở lượt sử dụng mới cấp một epoch mới. Mỗi command phải mang phiên được cấp, đồng thời token xác thực phải gắn đúng phiên. Epoch là kiểm tra độ mới, không thay thế xác thực.

Server tuần tự hóa thao tác đóng/mở phiên với tiếp nhận command. Trong một transaction hoặc critical section nhất quán, server kiểm tra phiên hiện hành, ràng buộc ID, deadline và trạng thái đơn trước khi áp dụng thay đổi. Không được kiểm tra phiên rồi thả khóa, sau đó ghi đơn khi phiên đã đổi.

Sau khi đóng bàn, outcome của lệnh đã được chấp nhận có thể được tra cứu có kiểm soát cho chủ thể cũ, nhưng command chưa từng ghi nhận của phiên cũ bị từ chối. Một snapshot cũ không được ghi đè phiên mới trên client.

### 3.3 Thời gian do server quyết định

Không tin timestamp do client gửi để kết luận “lệnh chưa hết hạn”. Phương án nhỏ và rõ: server cấp `grantId` và deadline cho một cửa sổ tiếp nhận; client chỉ mang grant, còn server lưu và kiểm tra deadline. Grant được ràng buộc phiên, loại lệnh và chủ thể. Lúc mạng ngắt quá hạn, client giữ nội dung làm nháp và đề nghị gửi mới sau khi xác thực lại.

Nếu nhóm không muốn triển khai grant, quy tắc an toàn và dễ hơn là không tự gửi lại yêu cầu phục vụ chưa được ghi nhận sau reconnect. Tra cứu outcome trước, rồi yêu cầu khách chủ động gửi một yêu cầu mới. Nhóm cần phát biểu contribution tương ứng, không tuyên bố đo chính xác tuổi offline bằng clock client.

TTL trong hợp đồng này là giới hạn **tiếp nhận lệnh mới**. Nó khác vòng đời xử lý của ticket đã được chấp nhận. Một ticket được nhận đúng hạn có thể vẫn chờ phục vụ sau deadline; việc đóng hoặc hủy ticket cần một chuyển trạng thái có lý do và có log.

### 3.4 Trình tự phục hồi

1. Client kết nối, xác thực và đối chiếu phiên bàn.
2. Client gửi danh sách ID còn chưa rõ kết quả, không gửi lại payload ngay.
3. Server trả kết quả đã lưu và snapshot với số phiên bản.
4. Với ID chưa ghi nhận, áp dụng bảng chính sách; command cũ không đủ điều kiện được giữ làm nháp hoặc trả trạng thái hết hiệu lực.
5. Command sửa/hủy kiểm tra trạng thái đơn hiện hành; phản hồi của server là kết quả chính thức.
6. Client cập nhật giao diện và chỉ bỏ khỏi outbox sau khi có outcome bền vững hoặc một trạng thái kết thúc đã xác nhận.

Tra cứu trước retry là giảm rủi ro, chưa đủ nếu thiếu bảo vệ nguyên tử server. Lookup có thể nói “chưa biết” trong lúc socket cũ vẫn có một handler đang commit. ID unique + transaction quyết định kết quả khi bản gửi lại đến.

## 4. Tình huống demo và cơ chế kiểm chứng

### S1 — Đơn đã nhận, ACK bị mất

Đóng socket sau commit và trước khi gửi response. Chủ quán bắt đầu chế biến trong lúc client offline. Client reconnect, lấy outcome và hiển thị `PREPARING`; không tạo đơn thứ hai và không cho biết “chưa nhận” như sự thật đã xác định.

### S2 — Cuộc gọi chưa nhận và đã cũ

Chặn command gọi nhân viên trước handler server; để deadline/grant hết hạn; sau reconnect bản cũ bị từ chối. Client có nút “Gọi lại” rõ ràng. Biến thể: command đã được nhận trước deadline, ACK mất; khi reconnect vẫn lấy được ticket đã nhận.

### S3 — Bàn đổi lượt khách

Client cũ còn outbox. Chủ quán xử lý xong lượt cũ, đóng phiên và mở lượt mới. Cho handler cũ hoặc bản retry tiếp tục. Server từ chối mutation vào lượt mới, đồng thời không tạo nhầm đơn ở bàn mới.

### S4 — Hủy cạnh tranh với bắt đầu chế biến

Đồng thời gửi `CANCEL_ORDER` và thao tác chủ quán `START_PREPARING`. Một trong hai thắng theo thứ tự commit; kết quả được ghi nhất quán. Không để trạng thái “đã hủy” đồng thời với “đang chế biến”.

TCP không đảo thứ tự byte trong một kết nối hoạt động. Các race cần demo đến từ handler đồng thời, thao tác quản trị, socket cũ còn xử lý và reconnect ở tầng ứng dụng; không mô tả sai là TCP tự đảo message.

## 5. Baseline và số liệu cần có

Baseline mạnh phải đã có unique request ID, idempotency bền vững và xác thực. Nó phục hồi bằng cách gửi lại mọi command đang chờ trong phiên được client ghi nhận. So sánh thêm baseline có session guard sẽ tránh quy toàn bộ lợi ích cho epoch đơn thuần.

| Phiên bản | Mục đích |
|---|---|
| B0: idempotency + replay mọi command | Quan sát stale replay dù chống lặp đúng |
| B1: B0 + guard phiên bàn | Tách tác dụng ngăn command của lượt cũ |
| B2: B1 + phân loại phục hồi + deadline/grant | Tách tác dụng đối với yêu cầu tạm thời |
| B3: B2 + kiểm tra version và barrier chế biến | Tách tác dụng đối với sửa/hủy cạnh tranh |

Đo số đơn trùng, command sai phiên được chấp nhận, ticket hết hiệu lực bị tạo mới, cancellation sai trạng thái, thời gian phục hồi median/p95, byte mạng và kích thước log. Đo thêm command vẫn có ích nhưng bị chặn, số thao tác khách phải xác nhận lại và số lỗi chưa rõ kết quả: đây là chi phí của chính sách.

Không dùng bộ lỗi chỉ được tạo để baseline chắc chắn thất bại. Chạy workload bình thường, mất mạng ngắn, mất mạng dài, client mới/cũ và workload nhiều client; dùng cùng lịch fault injection cho mọi phiên bản. Đối chiếu log theo ID với một oracle trạng thái server độc lập với giao diện.

Trạng thái không rõ không được đánh dấu “thất bại chắc chắn”. Nhóm không nên tuyên bố exactly-once delivery. Có thể bảo vệ phát biểu nhỏ hơn: nhiều lần truyền một command logic tạo tối đa một mutation trong phạm vi retention và phiên đã xác thực, khi transaction/log được đảm bảo.

## 6. Cách phát biểu mức khác biệt

Có thể viết ngay: “Contribution vận dụng các kỹ thuật đã có để xây dựng hợp đồng phục hồi dành cho tương tác tại bàn; nhóm kiểm thử các tình huống mất ACK, yêu cầu hết hiệu lực, đổi phiên bàn và cạnh tranh sửa/hủy.”

Chỉ viết sau khi có khảo sát sinh viên: “Trong N dự án nguồn mở thuộc mẫu khảo sát, M dự án có mô tả hoặc triển khai toàn bộ các tiêu chí trên; đây là dấu hiệu về mức hiện diện trong mẫu, không phải tỷ lệ phổ biến của mọi bài tập lớn.”

Không viết: “TTL/idempotency/epoch bàn là mới”, “không có nhà hàng nào làm”, “không thấy README nên source chắc chắn không có”, “contribution được chứng minh ít phổ biến giống SeatLink”. SeatLink trước đây cũng mới là ứng viên thiết kế được đối chiếu prior art, chưa có bằng chứng thống kê mức phổ biến của đồ án.

Contribution CafeLink đủ sức bảo vệ ở cấp môn học nếu đặc tả rõ, baseline hợp lý và thực nghiệm chỉ ra lợi ích cùng giới hạn. Một mẫu khảo sát nhỏ có thể hỗ trợ lựa chọn, nhưng không thay thế bằng chứng cải tiến.
