# Hoàn tất bản gốc CafeLink trước nâng cấp

Mốc bắt đầu: 20/10/2026, baseline tuần 2 có 49 test đạt. Người dùng yêu cầu hoàn tất cẩn thận các phần còn lại của dự án ban đầu. **Chưa triển khai U1–U5 của kế hoạch nâng cấp.**

## Phạm vi nghiệm thu

| Mốc | Nội dung | Kết quả cuối trên một máy |
|---|---|---|
| W3.1 | Rà soát yêu cầu, hồi quy, bổ sung ca lỗi/giới hạn còn thiếu | Đạt 59/59 test; xem W3 Part 1 |
| W3.2 | Bộ đo traffic, latency/throughput, workload 1/5/10/20 client | Đạt 20/20 lần đo; raw data, biểu đồ và oracle đã lưu |
| W3.3 | Campaign phục hồi với thời gian offline 2/10/60 giây và đối chứng | Đạt 180/180 ca; oracle SQLite độc lập đạt |
| W3.4 | Đóng gói bản gốc, manifest, kiểm chạy từ thư mục sạch, bộ LAN | Đạt trên một máy; LAN hai máy NOT RUN |
| W3.5 | Raw data, biểu đồ, báo cáo/Word, ma trận truy vết và bàn giao | Hoàn tất nội dung kỹ thuật; bìa/nộp/duyệt Word trực quan còn bên ngoài |

“Đầy đủ” được kiểm tra theo yêu cầu/kịch bản và bằng chứng, không tự nhận 100% dòng mã được phủ hoặc không còn mọi lỗi. Số test đạt được ghi từ Surefire từng lần chạy.

## Điều kiện người dùng đã xác nhận

- Hiện chỉ có một máy: tự động hóa và nghiệm thu localhost trên máy này; LAN vật lý hai máy ghi NOT RUN, chuẩn bị runbook và scripts để chạy sau. Không dùng nhiều JVM trên một máy làm bằng chứng LAN hai máy.
- Chưa cần điền bìa/thành viên/giảng viên: giữ placeholder, không tự bịa dữ liệu hoặc gán công việc cho thành viên.

## Ranh giới kiểm thử đã chốt

Giao thức qua FrameCodec, nghiệp vụ qua CafeService, giao tiếp qua NetworkClient/TCP, journal qua Outbox và thao tác qua GUI. Các bổ sung tập trung rollback, replay, ranh giới tài nguyên, timeout/disconnect và chạy đóng gói; không đổi nghiệp vụ sang phiên bản nâng cấp.

## Nhật ký kết quả

- Đính chính 21/10: phát hiện Oracle Java wrapper gây PID cleanup sai; đã sửa runtime launcher, thêm chứng minh listener đóng, chạy lại cả hai smoke đạt và đang chạy lại 20 lần đo tải. Evidence performance cũ được giữ ở `cafelink-original-superseded/`, không dùng làm E0. Xem [launcher correction](CafeLink_Launcher_Correction.md).

- Hồi quy đầu phiên: `scripts/build.ps1`, 49 tests, 0 failures/errors/skipped; package thành công. Kết quả sẽ được bổ sung theo từng mốc, không dùng số dự kiến.
- W3.1: thêm 10 test có ý nghĩa; build đầy đủ đạt 59 tests, 0 failures/errors/skipped. Báo cáo [W3 Part 1](CafeLink_W3_Part1_Report.md).
- W3.3: `recovery-experiment.ps1 -Repetitions 5 -OfflineSeconds '2,10,60' -Parallelism 6` kết thúc PASS lúc 16:30:33 UTC ngày 20/10/2026. Có 180 ca; raw data ở `cafelink-system/target/recovery-experiment-7df3aa31-0638-444d-a0c3-1355f4c7770f/`.
- W3.2: campaign độc lập bắt đầu sau khi W3.3 kết thúc; JAR giữ nguyên hash. Không chạy Maven hoặc các thử nghiệm tải khác đồng thời.

- Nghiệm thu bản gốc: 59/59 test Java (0 failures/errors/skipped), 3 test bộ phân tích Python, 180/180 ca phục hồi, 20/20 lần đo tải với 10,800 request và 0 lỗi. Xem [bàn giao cuối](CafeLink_Original_Handoff.md), evidence và giới hạn cụ thể.
