"""Audit original-baseline raw evidence; never publish credentials or databases.

Python 3 + matplotlib. Percentiles use nearest rank, including failed request
latencies; per-run values remain available so pooled percentiles are not
mistaken for confidence intervals or independent repetitions.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
import sqlite3
import statistics
from collections import defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        raise ValueError(f"No rows: {path}")
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def percentile(values, quantile):
    values = sorted(values)
    if not values or not 0 < quantile <= 1:
        raise ValueError("Nonempty samples and 0 < quantile <= 1 required")
    return values[math.ceil(len(values) * quantile) - 1]


def audit_samples(rows, summary):
    if not rows or len({row["sampleId"] for row in rows}) != len(rows):
        raise ValueError("Missing samples or duplicate sample IDs")
    successes = sum(row["outcome"] == "OK" for row in rows)
    if (len(rows), successes, len(rows) - successes) != (summary["requests"], summary["successes"], summary["errors"]):
        raise ValueError("Raw request outcomes disagree with summary")
    for row in rows:
        start, end, latency = (float(row[key]) for key in ("startedMs", "endedMs", "latencyMs"))
        if not all(math.isfinite(n) for n in (start, end, latency)) or start < 0 or latency < 0 or abs(end - start - latency) > 0.00001:
            raise ValueError("Invalid request timing")
    return successes


def database_oracle(path):
    # A read-only connection: a missing DB cannot silently become an empty DB.
    with sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True) as db:
        if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError(f"Database integrity check failed: {path}")
        if db.execute("PRAGMA foreign_key_check").fetchall():
            raise ValueError(f"Foreign-key check failed: {path}")
        scalar = lambda sql: db.execute(sql).fetchone()[0]
        return dict(orders=scalar("SELECT COUNT(*) FROM orders"),
                    totalVnd=scalar("SELECT COALESCE(SUM(quantity*unit_price_vnd),0) FROM order_items"),
                    tickets=scalar("SELECT COUNT(*) FROM tickets"),
                    orderReceipts=scalar("SELECT COUNT(*) FROM command_receipts WHERE action='PLACE_ORDER'"),
                    activeVisits=scalar("SELECT COUNT(*) FROM visits WHERE active=1"))


def copy_public(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def analyze(benchmark, recovery, surefire, output):
    output.mkdir(parents=True, exist_ok=False)
    env = read_json(benchmark / "environment.json")
    campaign = read_json(benchmark / "campaign-summary.json")
    cases = read_csv(benchmark / "cases.csv")
    metadata = read_json(recovery / "metadata.json")
    recovery_rows = read_csv(recovery / "results.csv")
    if campaign["status"] != "PASS" or metadata["status"] != "PASS":
        raise ValueError("A campaign failed or is incomplete; raw evidence must be inspected")
    if len(cases) != campaign["cases"] or len(recovery_rows) != metadata["cases"]:
        raise ValueError("Missing campaign cases")
    expected_load = {(n, r) for n in env["clientCounts"] for r in range(1, env["repetitions"] + 1)}
    actual_load = [(int(row["clients"]), int(row["repeat"])) for row in cases]
    if set(actual_load) != expected_load or len(actual_load) != len(expected_load):
        raise ValueError("Duplicate or missing load configuration")
    expected_recovery = {(policy, scenario, delay, r) for policy in ("REVIEW", "REPLAY_ALL")
                         for scenario in ("NORMAL", "LOST_ORDER_ACK", "UNACCEPTED_ORDER", "UNACCEPTED_SERVICE", "LOST_SERVICE_ACK", "VISIT_CHANGED")
                         for delay in metadata["offlineSeconds"] for r in range(1, metadata["repetitions"] + 1)}
    actual_recovery = [(row["policy"], row["scenario"], int(row["scheduledOfflineSeconds"]), int(row["repetition"])) for row in recovery_rows]
    if set(actual_recovery) != expected_recovery or len(actual_recovery) != len(expected_recovery):
        raise ValueError("Duplicate or missing recovery configuration")
    benchmark_rows, oracle_rows = [], []
    pooled = defaultdict(list)
    for case in cases:
        folder = benchmark / case["folder"]
        measured = folder / "measurements"
        summary = read_json(measured / "summary.json")
        samples = read_csv(measured / "requests.csv")
        audit_samples(samples, summary)
        oracle = database_oracle(folder / "server.db")
        if case["status"] != "PASS" or case.get("listenerClosed") != "True" or summary["status"] != "PASS" or summary["errors"] or (oracle["orders"], oracle["totalVnd"]) != (summary["persistedOrders"], summary["persistedTotalVnd"]) or oracle["orderReceipts"] != oracle["orders"]:
            raise ValueError(f"Benchmark reconciliation failed: {case['folder']}")
        n = int(case["clients"])
        row = dict(clients=n, repetition=int(case["repeat"]), requests=len(samples), errors=summary["errors"],
                   completedRps=summary["completedRequestsPerSecond"], sentBytes=summary["sentBytes"], receivedBytes=summary["receivedBytes"],
                   persistedOrders=oracle["orders"], totalVnd=oracle["totalVnd"], journalBytes=summary["journalBytes"], databaseBytes=int(case["databaseBytes"]))
        for action in ("ALL", "PLACE_ORDER", "GET_STATE"):
            latencies = [float(sample["latencyMs"]) for sample in samples if action == "ALL" or sample["action"] == action]
            row[action + "_p50_ms"] = percentile(latencies, .5)
            row[action + "_p95_ms"] = percentile(latencies, .95)
            pooled[n, action].extend(latencies)
        benchmark_rows.append(row)
        oracle_rows.append(dict(campaign="benchmark", case=case["folder"], **oracle))
        for filename in ("requests.csv", "summary.json", "config.json"):
            copy_public(measured / filename, output / "raw/benchmark" / case["folder"] / filename)
    load_rows = []
    for n in sorted({row["clients"] for row in benchmark_rows}):
        runs = [row for row in benchmark_rows if row["clients"] == n]
        load_rows.append(dict(clients=n, repetitions=len(runs), requests=sum(row["requests"] for row in runs), errors=sum(row["errors"] for row in runs),
                              offeredRps=n * 1000 / env["periodMillis"], meanCompletedRps=statistics.mean(row["completedRps"] for row in runs),
                              minCompletedRps=min(row["completedRps"] for row in runs), maxCompletedRps=max(row["completedRps"] for row in runs),
                              p50_ms=percentile(pooled[n, "ALL"], .5), p95_ms=percentile(pooled[n, "ALL"], .95),
                              order_p95_ms=percentile(pooled[n, "PLACE_ORDER"], .95), read_p95_ms=percentile(pooled[n, "GET_STATE"], .95),
                              meanReceivedKiB=statistics.mean(row["receivedBytes"] for row in runs)/1024,
                              meanSentKiB=statistics.mean(row["sentBytes"] for row in runs)/1024,
                              meanJournalKiB=statistics.mean(row["journalBytes"] for row in runs)/1024,
                              meanDatabaseKiB=statistics.mean(row["databaseBytes"] for row in runs)/1024))
    groups = defaultdict(list)
    for row in recovery_rows:
        if row["status"] != "PASS":
            raise ValueError(f"Failed recovery row: {row}")
        oracle = database_oracle(recovery / row["caseFolder"] / "server.db")
        if (oracle["orders"], oracle["tickets"]) != (int(row["orders"]), int(row["tickets"])) or oracle["orderReceipts"] != oracle["orders"]:
            raise ValueError(f"Recovery DB disagreement: {row['caseFolder']}")
        scenario, policy = row["scenario"], row["policy"]
        expected_orders = int(scenario in ("NORMAL", "LOST_ORDER_ACK") or (scenario == "UNACCEPTED_ORDER" and policy == "REPLAY_ALL"))
        expected_tickets = int(scenario == "LOST_SERVICE_ACK" or (scenario == "UNACCEPTED_SERVICE" and policy == "REPLAY_ALL"))
        if (oracle["orders"], oracle["tickets"]) != (expected_orders, expected_tickets):
            raise ValueError("Independent recovery oracle failed")
        expected_confirmation = int(policy == "REVIEW" and scenario in ("UNACCEPTED_ORDER", "UNACCEPTED_SERVICE"))
        if int(row["confirmationRequired"]) != expected_confirmation:
            raise ValueError("Unexpected confirmation policy")
        if scenario != "NORMAL" and float(row["actualOfflineMs"]) < int(row["scheduledOfflineSeconds"]) * 1000 - 5:
            raise ValueError("Offline interval shorter than configured")
        for metric in ("duplicateOrders", "wrongVisitEffects"):
            if int(row[metric]) != 0:
                raise ValueError(f"Invariant violation: {metric}")
        groups[policy, scenario, int(row["scheduledOfflineSeconds"])].append(row)
        oracle_rows.append(dict(campaign="recovery", case=row["caseFolder"], **oracle))
    recovery_summary = []
    for (policy, scenario, delay), rows in sorted(groups.items()):
        recovery_summary.append(dict(policy=policy, scenario=scenario, offlineSeconds=delay, cases=len(rows),
                                     orders=sum(int(row["orders"]) for row in rows), tickets=sum(int(row["tickets"]) for row in rows),
                                     confirmationRequired=sum(int(row["confirmationRequired"]) for row in rows),
                                     unconfirmedServiceTickets=sum(int(row["unconfirmedServiceTickets"]) for row in rows),
                                     recovery_p50_ms=percentile([float(row["recoveryMs"]) for row in rows], .5),
                                     recovery_p95_ms=percentile([float(row["recoveryMs"]) for row in rows], .95)))
    suites = []
    for path in sorted(surefire.glob("TEST-*.xml")):
        root = ET.parse(path).getroot()
        suites.append(dict(suite=root.attrib["name"], **{key: int(root.attrib[key]) for key in ("tests", "failures", "errors", "skipped")}))
        copy_public(path, output / "surefire" / path.name)
    if not suites or any(row[key] for row in suites for key in ("failures", "errors", "skipped")):
        raise ValueError("Complete passing Surefire suite required")
    tests = dict(totals={key: sum(row[key] for row in suites) for key in ("tests", "failures", "errors", "skipped")}, suites=suites)
    write_json(output / "test-summary.json", tests)
    write_csv(output / "benchmark-runs.csv", benchmark_rows)
    write_csv(output / "benchmark-summary.csv", load_rows)
    write_csv(output / "recovery-summary.csv", recovery_summary)
    write_csv(output / "database-oracle.csv", oracle_rows)
    for source, target in ((benchmark / "environment.json", "raw/benchmark/environment.json"), (benchmark / "cases.csv", "raw/benchmark/cases.csv"),
                           (benchmark / "campaign-summary.json", "raw/benchmark/campaign-summary.json"), (recovery / "metadata.json", "raw/recovery/metadata.json"),
                           (recovery / "results.csv", "raw/recovery/results.csv")):
        copy_public(source, output / target)
    summary = dict(status="PASS", tests=tests["totals"], benchmarkCases=len(cases), recoveryCases=len(recovery_rows),
                   requests=sum(row["requests"] for row in load_rows), errors=sum(row["errors"] for row in load_rows),
                   unconfirmedServiceTickets={policy: sum(int(row["unconfirmedServiceTickets"]) for row in recovery_rows if row["policy"] == policy) for policy in ("REVIEW", "REPLAY_ALL")},
                   load=load_rows, environment=env, recoveryEnvironment=metadata,
                   evidenceScope="Read-only SQLite integrity/foreign-key/count/receipt oracles checked locally. Public bundle excludes DBs and credentials. Loopback only; no physical LAN or maximum capacity claim.")
    write_json(output / "summary.json", summary)
    plot(output, load_rows)
    lines = ["# Kết quả đo bản gốc CafeLink", "", "Dữ liệu và oracle SQLite đã đối chiếu tự động; xem summary.json và database-oracle.csv.", "",
             "| Khách | Số mẫu | Lỗi | Request/s trung bình | p50 (ms) | p95 (ms) | Đặt món p95 (ms) | GET_STATE p95 (ms) |", "|---|---|---|---|---|---|---|---|"]
    for row in load_rows:
        lines.append(f"| {row['clients']} | {row['requests']} | {row['errors']} | {row['meanCompletedRps']:.2f} | {row['p50_ms']:.2f} | {row['p95_ms']:.2f} | {row['order_p95_ms']:.2f} | {row['read_p95_ms']:.2f} |")
    lines += ["", f"Mỗi mức tải chạy {env['repetitions']} lần × {env['durationSeconds']} giây, warmup {env['warmupSeconds']} giây, {1000/env['periodMillis']:g} request/giây/khách (mỗi slot thứ năm đặt món). p50/p95 nearest-rank gộp mẫu; từng lần giữ trong benchmark-runs.csv. Đây là tải chủ động quy định, chưa đo công suất tối đa.", "",
              f"Campaign phục hồi: {len(recovery_rows)} ca, 2 policy × 6 kịch bản × {len(metadata['offlineSeconds'])} khoảng offline × {metadata['repetitions']} lần. REVIEW tạo {summary['unconfirmedServiceTickets']['REVIEW']} ticket chưa được khách xác nhận lại; REPLAY_ALL tạo {summary['unconfirmedServiceTickets']['REPLAY_ALL']}. Cả hai có idempotency/guard lượt. Không đo độ hài lòng hoặc lượng nhu cầu thực sự hết hiệu lực.", "",
              "Traffic là byte ứng dụng của guest gồm header frame/event/heartbeat; không gồm admin/TCP/IP. Timing phục hồi gồm login PBKDF2 và journal, chạy các ca song song nên chỉ là số mô tả. NORMAL không chờ offline. LAN vật lý hai máy: NOT RUN."]
    (output / "RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    hashes = [dict(path=str(path.relative_to(output)).replace("\\", "/"), sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in sorted(output.rglob("*")) if path.is_file()]
    write_json(output / "evidence-sha256.json", hashes)
    return summary


def plot(output, rows):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    counts = [row["clients"] for row in rows]
    for key, label in (("p95_ms", "All requests"), ("order_p95_ms", "PLACE_ORDER"), ("read_p95_ms", "GET_STATE")):
        axes[0].plot(counts, [row[key] for row in rows], marker="o", label=label)
    axes[0].set(xlabel="Guest clients", ylabel="Latency p95 (ms)", title="Loopback: pooled request samples")
    axes[0].legend(fontsize=8)
    axes[1].plot(counts, [row["offeredRps"] for row in rows], "--", label="Scheduled")
    axes[1].errorbar(counts, [row["meanCompletedRps"] for row in rows], yerr=[[row["meanCompletedRps"]-row["minCompletedRps"] for row in rows], [row["maxCompletedRps"]-row["meanCompletedRps"] for row in rows]], marker="o", label="Completed: mean, min/max runs")
    axes[1].set(xlabel="Guest clients", ylabel="Requests / second", title="Fixed offered load; not maximum capacity")
    axes[1].legend(fontsize=8)
    for axis in axes:
        axis.set_xticks(counts)
        axis.grid(alpha=.25)
    fig.tight_layout()
    fig.savefig(output / "load-results.png", dpi=180)
    fig.savefig(output / "load-results.svg")
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("benchmark", "recovery", "surefire", "output"):
        parser.add_argument("--" + key, type=Path, required=True)
    options = parser.parse_args()
    result = analyze(options.benchmark, options.recovery, options.surefire, options.output)
    print(json.dumps({key: result[key] for key in ("status", "tests", "benchmarkCases", "recoveryCases", "requests", "errors")}, indent=2))
