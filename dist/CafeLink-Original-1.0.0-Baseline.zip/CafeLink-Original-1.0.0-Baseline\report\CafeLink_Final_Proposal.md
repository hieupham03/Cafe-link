# CafeLink — Đề xuất cuối cùng

Ngày chốt: 14/10/2026. Baseline tuần 1 đã triển khai và kiểm thử, xem [CafeLink_Week1_Handoff.md](CafeLink_Week1_Handoff.md). Contribution phục hồi tuần 2 và số liệu thực nghiệm hiệu năng vẫn chưa hoàn thành.

## 1. Tên đăng ký

**Thiết kế và xây dựng hệ thống gọi món và điều phối yêu cầu phục vụ tại quán café theo mô hình Client/Server, hỗ trợ phục hồi giao tiếp theo loại yêu cầu và phiên sử dụng bàn.**

Tên ngắn: **CafeLink**.

## 2. Bài toán và phạm vi

Khách tại bàn đặt món, gọi nhân viên, yêu cầu tính tiền và nhận phản hồi. Chủ quán tiếp nhận, trả lời và cập nhật tiến độ. Server quản lý dữ liệu chính thức; các client khách và quản trị giao tiếp hai chiều qua mạng.

Phạm vi bản đầu: một quán, 6 bàn, 8 đồ uống, một vai trò chủ quán và nhiều client tại bàn. Xác thực bằng tài khoản; tuần 2 ràng buộc quyền với mã phiên do server cấp. Thanh toán mô phỏng do chủ quán xác nhận. Công nghệ đã chọn: Java TCP Socket, Swing, SQLite/JDBC. Protocol có framing theo độ dài; metadata JSON. Một server trung tâm, hàng đợi ghi ra socket cho từng kết nối và quản lý trạng thái dùng chung an toàn.

## 3. Contribution chính

> Nhóm thiết kế và đánh giá giao thức phục hồi yêu cầu sau mất kết nối theo loại yêu cầu và phiên sử dụng bàn. Giao thức đối chiếu kết quả đã lưu trước khi gửi lại, xử lý riêng yêu cầu đặt món và yêu cầu phục vụ có thời hạn, đồng thời chặn các thay đổi từ lượt khách đã kết thúc. Nhóm đánh giá khả năng hạn chế thao tác trùng, yêu cầu không còn hiệu lực và thao tác sai lượt khách so với baseline có retry và idempotency.

Đây là contribution về **thiết kế giao thức ứng dụng và đánh giá khả năng phục hồi**, vận dụng kỹ thuật đã có. Không tự nhận phát minh idempotency, TTL hay fencing, không tuyên bố exactly-once delivery.

### C1 — Đối chiếu kết quả và quyết định gửi lại theo loại yêu cầu

Client giữ request ID và payload bất biến cho yêu cầu chưa rõ kết quả. Server lưu receipt và thay đổi dữ liệu nghiệp vụ trong cùng transaction; chỉ trả xác nhận thành công sau commit. Request ID được ràng buộc với chủ thể và phiên bàn, đồng thời kiểm tra fingerprint payload để tránh dùng cùng ID cho hai nội dung khác nhau.

Khi reconnect: xác thực lại; đối chiếu phiên; gửi danh sách ID chưa rõ kết quả; lấy outcome và snapshot; sau đó mới quyết định gửi lại. Lookup trước replay không thay thế unique constraint/transaction: handler cũ có thể đang commit trong lúc lookup trả chưa thấy.

| Yêu cầu | Đã được server nhận nhưng mất phản hồi | Chưa được server nhận |
|---|---|---|
| Đặt món | Lấy lại đơn và trạng thái hiện tại, không tạo đơn mới | Chỉ gửi lại cùng ID khi vẫn thuộc phiên hiện hành và còn được phép; nếu đã chờ lâu, khách xác nhận lại |
| Gọi phục vụ | Lấy lại ticket đã nhận | Sau reconnect, không tự phát lại yêu cầu đã hết hiệu lực; khách có thể bấm Gọi lại |
| Yêu cầu tính tiền | Lấy lại yêu cầu/snapshot hiện hành | Kiểm tra phiên và hiệu lực; yêu cầu quá hạn cần khách gửi mới |

Bản triển khai nhỏ có thể luôn yêu cầu khách xác nhận lại các lời gọi phục vụ chưa được ghi nhận sau reconnect. Nếu tự retry trong thời hạn, server cần cấp grant có deadline do server lưu/kiểm tra; không dùng timestamp client làm nguồn quyết định. Grant gắn với phiên, chủ thể, ID và loại lệnh. Chi phí handshake phải được đo.

Deadline giới hạn **tiếp nhận yêu cầu mới**, không xóa ticket đã nhận đúng hạn. Đơn đặt món chờ lâu cũng không được tự tạo chỉ vì payload còn trong outbox. Trạng thái chưa rõ kết quả phải được hiển thị đúng, không mặc định thất bại.

### C2 — Ràng buộc thay đổi vào lượt khách hiện hành

Server cấp `tableSessionId` mới khi chủ quán mở một lượt khách. Mỗi request mang phiên này; phiên không phải table ID, socket ID hoặc HTTP login session. Token xác thực phải gắn đúng phiên, session ID không thay thế xác thực.

Khi đóng lượt khách, server đóng phiên và mở lượt mới với ID khác. Kiểm tra phiên và ghi thay đổi phải nguyên tử với thao tác đóng/mở bàn, bằng transaction/khóa nhất quán. Request hoặc callback cũ đến muộn không tạo tác dụng vào lượt mới. Outcome cũ được giữ để đối chiếu theo quyền, không để khách mới đọc dữ liệu của khách trước. Không tự gắn outbox cũ vào phiên mới.

Quy tắc đóng bàn cần xử lý rõ đơn/ticket đang hoạt động; không âm thầm mất dữ liệu đã nhận. Mã phiên được giữ qua reconnect của cùng lượt, chỉ thay khi lượt khách thực sự kết thúc.

### Phần mở rộng, không bắt buộc ở bản đầu

Sửa/hủy món theo `expectedVersion`, với kiểm tra trạng thái trước `PREPARING` trong cùng transaction. Lệnh hủy cạnh tranh với bắt đầu pha chỉ có một kết quả chính thức. Version/tombstone/cancel-before-create là kỹ thuật có tiền lệ; không dùng chúng làm contribution mới riêng. Có thể bổ sung sau khi C1/C2 chạy ổn.

## 4. Bằng chứng khảo sát và cách phát biểu độ ít phổ biến

Đã kiểm tra tĩnh 12 dự án học tập ở commit cố định: **11 dự án tự mô tả là đồ án môn học/đồ án sinh viên/cuộc thi mini-project của trường**, và **1 dự án cuối khóa đào tạo lại Java** làm đối chứng socket. Cặp Admin/Customer của K23 tính một dự án. Các truy vấn, căn cứ học thuật, file nguồn, SHA và giới hạn nằm trong:

- [Mẫu A: 6 dự án](CafeLink_Student_Survey_A.md).
- [Mẫu B: 3 dự án](CafeLink_Student_Survey_B.md).
- [Mẫu C: 3 dự án theo bàn](CafeLink_Student_Survey_C.md).
- [Tiền lệ công nghiệp và đặc tả](CafeLink_Prior_Art_Detail.md).

Trong bảng dưới, “chưa ghi nhận” chỉ nói về luồng và schema đã đọc, không phải chứng minh toàn bộ source/hạ tầng không có tính năng.

| Tiêu chí chính xác | Mẫu sinh viên áp dụng | Có bằng chứng implementation đáp ứng |
|---|---:|---:|
| Client giữ ID lệnh qua retry, server có receipt và tra cứu outcome chưa rõ | 11 | 0 được ghi nhận |
| Phiên riêng cho từng lượt khách, kiểm tra nguyên tử với đóng/mở bàn | 5 dự án có bàn | 0 được ghi nhận |
| Deadline phục vụ/tính tiền chưa nhận được xét lúc phục hồi | 1 dự án có loại yêu cầu tương ứng | 0 được ghi nhận; mẫu quá ít để kết luận phổ biến |

Mẫu bàn sinh viên: jedrzej-p/self-order, K23 Smart Restaurant, sulemaniftikhar/final-year-project, user7121/Restaurant-Management-System, tomisin-ogunn/Restaurant-Management-System. Nếu cộng đối chứng Java NatasaTM thì số mẫu bàn là 6, nhưng không gộp nó vào mẫu số sinh viên chính.

Các tiền lệ được ghi nhận đầy đủ: K23/Suleman có realtime/reconnect; nhiều dự án có transaction trước response; K23/User7121 có guard bàn còn đơn; Samosabucket có Stripe idempotency key nhưng sinh mới trong mỗi POST. Không lấy những điểm đã có này làm contribution riêng.

**Phát biểu dùng được:** “Khảo sát sơ bộ mã nguồn 11 đồ án học tập công khai chưa ghi nhận hợp đồng phục hồi kết quả lệnh theo ID như định nghĩa; trong 5 mẫu đặt món theo bàn chưa ghi nhận cơ chế kiểm tra phiên lượt khách nguyên tử như đề xuất. Đây là bằng chứng giới hạn về khoảng trống trong mẫu khảo sát để định hướng thiết kế CafeLink.”

Đây là mẫu có chủ đích từ tìm kiếm, không phải mẫu ngẫu nhiên. Không suy ra tỷ lệ của mọi bài tập lớn, không dùng 0/11 như tỷ lệ phổ biến toàn ngành, không suy ra absence từ README. Phần deadline riêng còn ít mẫu đối chiếu. SeatLink trước đó cũng chưa có khảo sát mức phổ biến, nên chưa có căn cứ so hai đề tài bằng tỷ lệ.

Idempotency, expiry và offline POS đã có trong [Stripe](https://docs.stripe.com/api/idempotent_requests), [MQTT 5.0](https://docs.oasis-open.org/mqtt/mqtt/v5.0/os/mqtt-v5.0-os.html) và [Toast](https://doc.toasttab.com/doc/platformguide/adminOfflineModeOverview.html). Contribution của CafeLink nằm ở contract cụ thể và thực nghiệm; chưa chứng minh novelty toàn cầu.

## 5. Baseline và thực nghiệm phải làm

Giữ cùng UI, dữ liệu, xác thực, unique ID và transaction trong các phiên bản; thay đổi chính sách phục hồi bằng cấu hình.

- **B0:** reconnect + idempotency + snapshot; gửi lại mọi request chưa rõ kết quả.
- **B1:** B0 + guard phiên bàn nguyên tử.
- **B2 (CafeLink):** B1 + đối chiếu outcome trước replay + quyết định theo loại/hiệu lực request.
- **B3 (đối chứng bổ sung):** B1 + một TTL chung cho yêu cầu chưa được nhận; so với chính sách riêng từng loại. Ticket/đơn đã nhận vẫn được lưu ở mọi bản.

| Kịch bản | Điểm gây lỗi có kiểm soát | Chỉ số |
|---|---|---|
| Mất phản hồi đặt món | Ngắt sau commit, trước response | Đơn trùng; tỷ lệ phục hồi đúng outcome |
| Gọi phục vụ đã cũ | Giữ lệnh trước tiếp nhận rồi reconnect muộn | Ticket không còn hiệu lực bị tạo; yêu cầu còn có ích bị chặn |
| Đổi lượt khách | Đóng/mở phiên trước khi retry/handler cũ ghi | Số tác dụng sai phiên |
| Đã nhận đúng hạn, reconnect sau hạn | Mất ACK của ticket đã được nhận | Outcome/ticket có được giữ đúng không |
| Nhiều client | 1, 5, 10, 20 client theo điều kiện máy | Độ trễ median/p95; phục hồi; byte mạng |

Tham số thử nghiệm là đề xuất: mất kết nối 2/10/60 giây; deadline ngắn/dài theo loại request; chạy lặp với cùng lịch sự cố. Trộn tình huống bình thường và lỗi. Đo cả chi phí: handshake, outbox/receipt storage, thao tác xác nhận lại và yêu cầu hợp lệ bị từ chối. Không có số liệu hiệu năng được tạo trong tài liệu này.

TCP không đảo byte trong một kết nối hoạt động. Sự cố demo là mất kết nối, mất phản hồi ở tầng ứng dụng, handler cũ, reconnect và thao tác quản trị đồng thời. Hiệu ứng vật lý pha món nằm ngoài bảo đảm transaction của phần mềm.

## 6. Demo cuối cùng

Ba client đặt món/gọi phục vụ/yêu cầu tính tiền. Cố ý làm mất phản hồi một đơn đã lưu: client reconnect và thấy chính đơn đang được pha. Cho một yêu cầu gọi nhân viên chưa nhận chờ quá hạn: nó không tự tạo ticket cũ, khách có thể gọi lại. Đóng lượt khách tại một bàn rồi mở lượt mới: replay từ client cũ bị từ chối và không đổi dữ liệu lượt mới. Màn hình quản trị có log kỹ thuật để đối chiếu request ID; màn hình khách dùng thông báo trạng thái dễ hiểu.

Ưu tiên triển khai: baseline giao tiếp và nghiệp vụ nhỏ → receipt/outcome/outbox → guard phiên → chính sách phục hồi → fault injection và đo lường → báo cáo. Chốt C1/C2 làm contribution; phần sửa/hủy nâng cao là mở rộng.
