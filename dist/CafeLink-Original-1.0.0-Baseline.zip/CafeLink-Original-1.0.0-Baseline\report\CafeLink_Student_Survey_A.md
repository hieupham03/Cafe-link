# CafeLink: khảo sát mã nguồn dự án học tập A

Ngày khảo sát: 14/10/2026 (Asia/Saigon). Đây là phần khảo sát dự án công khai, phục vụ lựa chọn contribution ở cấp bài tập lớn. Không tuyên bố novelty toàn cầu và không ước lượng tỷ lệ trong toàn bộ đề tài sinh viên.

## Phương pháp và giới hạn

Đây là mẫu có chủ đích theo độ liên quan và khả năng kiểm chứng; không lấy mẫu ngẫu nhiên. Điều kiện đưa vào: (1) ứng dụng đặt món/nhà hàng/căng-tin; (2) có mã nguồn client và server hoặc luồng HTTP hoàn chỉnh; (3) tác giả tự xác nhận là course, university, assignment hoặc final project; (4) đọc được luồng đặt món thực tế. Dự án chỉ có SRS, console không có mạng, ảnh chụp hoặc lời giới thiệu không có code bị loại.

Truy vấn khám phá đã thực hiện bằng web search:

- `site:github.com restaurant "socket" "course" Java ordering`
- `site:github.com cafe "socket" "project" ordering student`
- `site:github.com "restaurant ordering" "course project"`
- `site:github.com "restaurant" "client server" "university"`
- `site:github.com "restaurant ordering" "final project"`
- `site:github.com "food ordering" "course project"`
- `site:github.com "cafe" "network programming"`
- `site:github.com "restaurant" "client-server" "assignment"`
- `site:github.com "restaurant" "socket programming"`
- `site:github.com "food ordering" "TCP"`

NatasaTM được tìm thêm từ [trang portfolio của chính tác giả](https://natasatm.netlify.app/projects/restaurant-management). `jedrzej-p/self-order` được tìm từ topic self-ordering và kiểm chứng tiếp ở mô tả repository. Các truy vấn khác không cho ứng viên đủ điều kiện vẫn được thực hiện; danh sách này ghi truy vấn góp phần vào mẫu.

Đợt tìm phản ví dụ chủ động sử dụng thêm `site:github.com restaurant "offline" "final project"`, `site:github.com cafe ordering "idempotency" "course"`, `site:github.com restaurant "reconnect" "academic"`, `site:github.com restaurant "session" "idempotent" "student"`. Kết quả trả cả ứng dụng recipe/cache và ERP SQLite tại một máy; không đưa vào corpus client/server đặt món. Các truy vấn này chưa tìm được phản ví dụ phù hợp trong kết quả được đọc, nhưng không chứng minh phản ví dụ không tồn tại.

Sau khám phá, clone mã nguồn bằng `git clone --depth 1 --filter=blob:none`, lấy `git rev-parse HEAD`, đọc README và các file client, handler, schema, service/repository liên quan. Tìm toàn bộ code ứng dụng theo các từ `idempot|request_?id|requestId|outbox|offline|reconnect|retry|revision|epoch|fencing|expiresAt|expire_at`, rồi đọc luồng xử lý để tránh suy ra sự vắng mặt chỉ từ README. Không chạy ứng dụng, không kiểm toán toàn bộ triển khai hay hạ tầng ngoài repository; vì vậy mọi N chỉ áp dụng cho luồng và snapshot đã nêu.

Các repository tham khảo được giữ dưới `report/research-cache/student-a/`. Không sử dụng credentials hoặc vận hành dịch vụ bên ngoài của các tác giả. File nguồn có cấu hình mẫu hoặc literal dịch vụ không được trích lại vào báo cáo này.

## Mẫu và snapshot

| ID | Repository | Căn cứ học tập của tác giả | Commit đã đọc |
|---|---|---|---|
| A1 | [NatasaTM/RestaurantManagingJavaApp](https://github.com/NatasaTM/RestaurantManagingJavaApp) | [README, dòng 2](https://github.com/NatasaTM/RestaurantManagingJavaApp/blob/31a687837a454699a2a32c2b11619e03d3688fe6/README.md#L2): bài cuối khóa đào tạo lại Java developer; không mặc nhiên coi là môn lập trình mạng đại học | `31a687837a454699a2a32c2b11619e03d3688fe6` |
| A2 | [pha123661/Online-Food-Ordering-System](https://github.com/pha123661/Online-Food-Ordering-System) | [README dòng 7](https://github.com/pha123661/Online-Food-Ordering-System/blob/403d094c60e409cc6e87c2d9b2983e67d89328a4/README.md#L7): Introduction to Database, NYCU, Spring 2022 | `403d094c60e409cc6e87c2d9b2983e67d89328a4` |
| A3 | [ByteBiteDev/food-ordering-system](https://github.com/ByteBiteDev/food-ordering-system) | [README dòng 249](https://github.com/ByteBiteDev/food-ordering-system/blob/3955c21eb77f8c3608abfdef021d0150cf70daad/README.md#L249): course project PHP/MySQL; không công bố tên trường/môn cụ thể | `3955c21eb77f8c3608abfdef021d0150cf70daad` |
| A4 | [aannirajpatel/samosabucket](https://github.com/aannirajpatel/samosabucket) | [README dòng 59](https://github.com/aannirajpatel/samosabucket/blob/db4a5d0900896cdcf1fa1a0137ce6a0175be2fe2/README.md#L59): video là phần submission của course project | `db4a5d0900896cdcf1fa1a0137ce6a0175be2fe2` |
| A5 | [jedrzej-p/self-order](https://github.com/jedrzej-p/self-order) | Mô tả repository của tác giả ghi “Small uni project”; metadata này được kiểm chứng qua GitHub API ngày khảo sát, không gắn bất biến vào commit | `4d59799a1d7c03a95689a857533ef68f0a28b9f6` |
| A6 | [christian-tapales/Canteen-Express](https://github.com/christian-tapales/Canteen-Express) | [README dòng 11–14](https://github.com/christian-tapales/Canteen-Express/blob/fc84343263c02dee60f79b4700fb29354a4a02da/README.md#L11): final project App Development và Industry Elective | `fc84343263c02dee60f79b4700fb29354a4a02da` |

Mẫu gồm một ứng dụng TCP trực tiếp và năm ứng dụng web. Hai dự án có mô hình bàn ăn (A1, A5); bốn dự án còn lại là đặt món giao hàng/căng-tin. Không dùng mẫu này để kết luận mức phổ biến của epoch bàn trong những hệ thống không có phiên bàn.

## Tiêu chí và ma trận

- **S:** socket trực tiếp hoặc có mã gửi thông báo server chủ động. HTTP request/response thường không được đánh Y cho tiêu chí này.
- **I:** retry command với cùng ID do client giữ và có chống thực thi lặp ở server. CSRF, khóa giỏ hàng, ID đơn do server sinh và khóa payment provider không đủ.
- **F:** mã thế hệ/lượt khách sử dụng bàn, được server kiểm tra để chặn yêu cầu đến muộn từ khách trước.
- **A:** protocol phân biệt rõ nhận message, commit tác dụng nghiệp vụ và nhân viên bắt đầu phục vụ. Response sau lưu hoặc trường order status một mình không đủ.
- **E:** chính sách replay phân biệt ORDER lâu dài với CALL_SERVICE/CHECKOUT có hạn dùng, đối chiếu hiệu lực khi reconnect.
- **Q:** truy vấn kết quả bằng ID command trước khi replay để giải quyết trường hợp server đã commit nhưng client mất ACK.
- **R:** revision/tombstone/barrier xử lý create–sửa–hủy đến muộn hoặc trái thứ tự sau reconnect.
- **Y:** có bằng chứng triển khai; **N:** không có cơ chế trong luồng đã đọc; **U:** thiếu bằng chứng để kết luận; **—:** chức năng nghiệp vụ tương ứng không áp dụng/không có trong mẫu. Không biến — thành N trong mẫu số riêng của tiêu chí.

| ID | S | I | F | A | E | Q | R |
|---|---|---|---|---|---|---|---|
| A1 | Y: Java TCP | N | N | N | — | N | N |
| A2 | N | N | — | N | — | N | N |
| A3 | N | N | — | N | — | N | N |
| A4 | N | N* | — | N | — | N | N |
| A5 | Y: Web Push | N | N | N | — | N | N |
| A6 | N | N | — | N | — | N | N |

`N*`: A4 có idempotency key cho Stripe. Đây là bằng chứng tiền lệ quan trọng, nhưng mã sinh UUID mới mỗi lần nhận POST nên không đáp ứng I của khảo sát. E được để — vì các mẫu này không có tập CALL_SERVICE/CHECKOUT tương tự CafeLink; không được báo “6/6 không có expiry service request” như một tỷ lệ có ý nghĩa.

**Những kết luận N trên chỉ mô tả mã nguồn đã đọc.** Hạ tầng ngoài repository hoặc phiên bản không công khai có thể khác. Các nguồn có kiến trúc khác nhau, mục tiêu môn học khác nhau; không đánh giá chất lượng tác giả theo việc họ không triển khai feature ngoài scope.

## Bằng chứng theo dự án

### A1: RestaurantManagingJavaApp

[Communication.java](https://github.com/NatasaTM/RestaurantManagingJavaApp/blob/31a687837a454699a2a32c2b11619e03d3688fe6/RestaurantClient/src/restaurant/client/communication/Communication.java#L18) tạo singleton TCP socket và object streams. [Request.java](https://github.com/NatasaTM/RestaurantManagingJavaApp/blob/31a687837a454699a2a32c2b11619e03d3688fe6/RestaurantCommon/src/restaurant/common/transfer/Request.java#L14) mang operation và argument, không có client command ID/epoch. [Luồng client tạo đơn](https://github.com/NatasaTM/RestaurantManagingJavaApp/blob/31a687837a454699a2a32c2b11619e03d3688fe6/RestaurantClient/src/restaurant/client/ui/form/order/controller/OrderCreateFormController.java#L247) ghi request rồi đọc response, không có outbox hoặc query outcome.

[ORDER_ADD ở handler](https://github.com/NatasaTM/RestaurantManagingJavaApp/blob/31a687837a454699a2a32c2b11619e03d3688fe6/RestaurantServer/src/restaurant/server/thread/ProcessClientRequests.java#L285) gọi lưu rồi đặt result; [cuối handler](https://github.com/NatasaTM/RestaurantManagingJavaApp/blob/31a687837a454699a2a32c2b11619e03d3688fe6/RestaurantServer/src/restaurant/server/thread/ProcessClientRequests.java#L432) gửi response và đóng client khi SocketException. [Repository](https://github.com/NatasaTM/RestaurantManagingJavaApp/blob/31a687837a454699a2a32c2b11619e03d3688fe6/RestaurantServer/src/restaurant/server/repository/impl/OrderRepositoryImpl.java#L99) INSERT và dùng generated keys; [Table.java](https://github.com/NatasaTM/RestaurantManagingJavaApp/blob/31a687837a454699a2a32c2b11619e03d3688fe6/RestaurantCommon/src/restaurant/common/domain/Table.java#L12) chỉ có số bàn, số ghế và availability.

Response là ACK ứng dụng cơ bản. Tính bền vững/nguyên tử toàn đơn chưa được kiểm chứng runtime; không coi A là Y chỉ vì có save.

### A2: Online-Food-Ordering-System, NYCU

[app.py, order_made](https://github.com/pha123661/Online-Food-Ordering-System/blob/403d094c60e409cc6e87c2d9b2983e67d89328a4/app.py#L119) nhận PIDs, Quantities, S_owner, Type; [INSERT và commit](https://github.com/pha123661/Online-Food-Ordering-System/blob/403d094c60e409cc6e87c2d9b2983e67d89328a4/app.py#L229) tạo OID mới rồi commit trước trả thành công. [schema.sql](https://github.com/pha123661/Online-Food-Ordering-System/blob/403d094c60e409cc6e87c2d9b2983e67d89328a4/schema.sql#L31) dùng OID tự tăng; không có command ledger.

[Hủy đơn](https://github.com/pha123661/Online-Food-Ordering-System/blob/403d094c60e409cc6e87c2d9b2983e67d89328a4/app.py#L701) kiểm tra đơn chưa kết thúc rồi cập nhật trạng thái. Đây là business state guard, không phải barrier cho create/cancel trái thứ tự. Các luồng đọc đơn biết OID chưa giải quyết được ACK bị mất lúc tạo OID mới. Mô hình take-out/delivery không có bàn nên F, E không áp dụng.

### A3: PHP/MySQL Food Ordering System

[checkout.php](https://github.com/ByteBiteDev/food-ordering-system/blob/3955c21eb77f8c3608abfdef021d0150cf70daad/frontend/pages/checkout.php#L54) xác thực CSRF, tạo đơn và items trong transaction, commit rồi chuyển sang thanh toán. [schema](https://github.com/ByteBiteDev/food-ordering-system/blob/3955c21eb77f8c3608abfdef021d0150cf70daad/backend/database/schema.sql#L44) không có command ID unique cho đặt đơn. [JS submit](https://github.com/ByteBiteDev/food-ordering-system/blob/3955c21eb77f8c3608abfdef021d0150cf70daad/frontend/pages/checkout.php#L508) disable nút là bảo vệ giao diện, không chứng minh idempotency mạng.

[ajax_payment.php](https://github.com/ByteBiteDev/food-ordering-system/blob/3955c21eb77f8c3608abfdef021d0150cf70daad/backend/endpoints/ajax_payment.php#L27) kiểm tra order đã tồn tại và Pending Payment; [admin update](https://github.com/ByteBiteDev/food-ordering-system/blob/3955c21eb77f8c3608abfdef021d0150cf70daad/backend/admin/order_edit.php#L29) cập nhật status. Có transaction và trạng thái nghiệp vụ, chưa có replay qua disconnect.

### A4: Samosabucket — tiền lệ gần với idempotency

[routes/order.js](https://github.com/aannirajpatel/samosabucket/blob/db4a5d0900896cdcf1fa1a0137ce6a0175be2fe2/routes/order.js#L89) nhận POST, sinh UUID làm idempotency key cho Stripe, rồi save Order và trả response. Key sinh bên trong handler nên POST gửi lại sinh key mới; [Cart.js](https://github.com/aannirajpatel/samosabucket/blob/db4a5d0900896cdcf1fa1a0137ce6a0175be2fe2/frontend/src/Cart.js#L78) không giữ key cho retry. Không được phát biểu rằng dự án “không biết idempotency”.

[Order schema](https://github.com/aannirajpatel/samosabucket/blob/db4a5d0900896cdcf1fa1a0137ce6a0175be2fe2/models/Order.js#L3) chứa trạng thái, cart, địa chỉ và payment data. [Hủy đơn](https://github.com/aannirajpatel/samosabucket/blob/db4a5d0900896cdcf1fa1a0137ce6a0175be2fe2/routes/order.js#L211) có điều kiện PAID/PREPARING; chưa có revision/barrier. [Orders.js](https://github.com/aannirajpatel/samosabucket/blob/db4a5d0900896cdcf1fa1a0137ce6a0175be2fe2/frontend/src/Orders.js#L14) lấy danh sách theo HTTP, không theo dõi kết quả bằng request ID.

### A5: Self-order — phiên HTTP, transaction và Web Push đã có

[OrderController](https://github.com/jedrzej-p/self-order/blob/4d59799a1d7c03a95689a857533ef68f0a28b9f6/app/Http/Controllers/Api/OrderController.php#L19) dùng session order_id cho giỏ; storeCart chuyển trạng thái và quên order_id. [Summary.vue](https://github.com/jedrzej-p/self-order/blob/4d59799a1d7c03a95689a857533ef68f0a28b9f6/resources/js/components/cart/Summary.vue#L29) POST và ghi lỗi khi thất bại; không có command outbox.

[Migration orders](https://github.com/jedrzej-p/self-order/blob/4d59799a1d7c03a95689a857533ef68f0a28b9f6/database/migrations/2021_10_28_220900_create_orders_table.php#L16) có table_id nhưng [tables](https://github.com/jedrzej-p/self-order/blob/4d59799a1d7c03a95689a857533ef68f0a28b9f6/database/migrations/2021_10_28_220820_create_tables_table.php#L16) chỉ id và table_nr, chưa có epoch lượt khách. [service worker](https://github.com/jedrzej-p/self-order/blob/4d59799a1d7c03a95689a857533ef68f0a28b9f6/public/sw.js#L1) triển khai Web Push; asset offline.html tồn tại nhưng không là bằng chứng có replay lệnh ngoại tuyến. Phiên HTTP/PWA không tương đương phiên chiếm bàn và outbox.

### A6: Canteen Express — response sau transaction và xác nhận vendor đã có

[CartPage.jsx](https://github.com/christian-tapales/Canteen-Express/blob/fc84343263c02dee60f79b4700fb29354a4a02da/frontend/src/pages/CartPage.jsx#L77) gửi orderPayload qua Axios, xử lý success/error, không có key bền vững. [Controller](https://github.com/christian-tapales/Canteen-Express/blob/fc84343263c02dee60f79b4700fb29354a4a02da/backend/src/main/java/com/appdevg5/canteencoders/controller/OrderController.java#L43) gọi service rồi trả created order.

[OrderService](https://github.com/christian-tapales/Canteen-Express/blob/fc84343263c02dee60f79b4700fb29354a4a02da/backend/src/main/java/com/appdevg5/canteencoders/service/OrderService.java#L155) dùng @Transactional và save cả order/items/payment. [Entity](https://github.com/christian-tapales/Canteen-Express/blob/fc84343263c02dee60f79b4700fb29354a4a02da/backend/src/main/java/com/appdevg5/canteencoders/entity/OrderEntity.java#L17) có status và confirmedAt; [VendorOrders](https://github.com/christian-tapales/Canteen-Express/blob/fc84343263c02dee60f79b4700fb29354a4a02da/frontend/src/pages/VendorOrders.jsx#L52) có accept/reject. Các cơ chế lưu trước response và phân biệt trạng thái tiếp nhận/phục vụ đã có tiền lệ; không đề xuất chúng đơn lẻ là ít phổ biến.

## Kết luận dùng được và không dùng được

Có thể viết:

> Trong sáu repository học tập công khai được chọn có chủ đích, khảo sát mã nguồn luồng đặt món và kết nối chưa ghi nhận cơ chế kết hợp: đối chiếu kết quả command sau mất ACK, kiểm tra phiên sử dụng bàn hiện hành và quyết định gửi lại theo loại/hạn hiệu lực yêu cầu. Hai mẫu có bàn chỉ dùng table ID, chưa thấy mã thế hệ lượt khách. Kết quả chỉ áp dụng cho corpus và commit đã nêu.

Không thể viết:

- “0/6 nên 100% bài tập lớn không có”.
- “Contribution độc nhất/chưa ai làm”.
- “Các hệ thống nhà hàng không có offline mode”.
- “Receipt và ACK sau commit ít phổ biến”: nhiều mẫu đã lưu trước response.
- “Expiry của CALL_SERVICE ít phổ biến 0/6”: các mẫu không có command đó nên mẫu số này không hợp lệ.

**Hướng contribution CafeLink có căn cứ nhất để tiếp tục thiết kế:** phục hồi command theo ngữ nghĩa trong phiên bàn. Cụ thể, ORDER chưa rõ kết quả được đối chiếu bằng command ID; CALL_SERVICE hết hiệu lực không tự tạo ticket cũ; mọi tác dụng mới phải kiểm tra phiên lượt khách vẫn hiện hành. Idempotency/outbox/snapshot là thành phần nền, contribution là chính sách phối hợp và đánh giá bằng fault injection.

**Mức chứng cứ về độ ít phổ biến:** bằng chứng định tính có corpus và mã nguồn truy nguyên được; chưa phải kết luận thống kê. Survey A không đủ để so trực tiếp với SeatLink trên cùng quần thể. Muốn mạnh hơn nên bổ sung dự án socket/network-course và table-ordering khác, chủ động tìm bằng các từ offline/reconnect/idempotent/session để tìm cả phản ví dụ, rồi báo đầy đủ Y/N/U. Tránh chỉ tìm dự án CRUD dễ vắng feature.

