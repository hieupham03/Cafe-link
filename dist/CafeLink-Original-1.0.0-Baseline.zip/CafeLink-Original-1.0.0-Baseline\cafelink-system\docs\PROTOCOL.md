# CafeLink TCP protocol v1 — mở rộng phục hồi tuần 2

Cập nhật 20/10/2026. Giữ framing/version=1; client/server hiện tại cần cùng phiên bản ứng dụng để dùng recovery. Không hứa tương thích ngược chức năng phục hồi với client tuần 1.

## Framing

`[4-byte signed big-endian positive length][UTF-8 JSON bytes]`. Length là số byte, tối đa 262144. Một read() có thể chỉ nhận một phần message; codec đọc đủ header/body. EOF trước byte đầu là disconnect; EOF giữa frame là lỗi. Không sử dụng ObjectInputStream/Java native serialization.

```json
{"version":1,"kind":"REQUEST","requestId":"UUID","action":"PLACE_ORDER","ok":true,"data":{"visitId":"server-issued","items":[{"menuId":2,"quantity":2}],"note":"ít đá"}}
```

Response giữ requestId/action, có `ok`, `data`; khi lỗi có `errorCode` và `message`. Event có kind EVENT, action STATE_UPDATED, data Snapshot, không cần requestId. Client có một reader; request callers đợi future theo ID, không đọc stream cạnh tranh với event listener.

## Commands

| Action | Payload | Quyền / kết quả |
|---|---|---|
| LOGIN | username/password | Identity role/table do server trả; chỉ một lần login/connection |
| GET_OUTCOME | commandId | Tra receipt trong principal của credential hiện tại; found/action/fingerprint/result |
| DISCARD_COMMAND | commandId, action, payload gốc | GUEST; giữ outcome đã nhận hoặc ghi dấu bỏ nếu chưa nhận |
| START_NEW_VISIT | {} | GUEST; lượt credential cũ phải đã đóng; trả Identity/credential mới |
| PING | {} | Đã login; heartbeat response |
| GET_STATE | {} | Snapshot lọc theo Identity |
| OPEN_TABLE | tableId integer | ADMIN; cấp visitId UUID mới |
| PLACE_ORDER | visitId, items(menuId,quantity), note tùy chọn | GUEST; xác minh bàn/phiên; giá tra DB; trả orderId,totalVnd |
| SET_ORDER_STATUS | orderId integer,status | ADMIN; chỉ next state |
| CALL_SERVICE | visitId,note | GUEST; tạo ticket OPEN |
| REQUEST_BILL | visitId,note | GUEST; cần có đơn; tạo ticket OPEN |
| HANDLE_TICKET | ticketId integer,reply | ADMIN; OPEN → HANDLED |
| GET_BILL | visitId | ADMIN hoặc đúng GUEST; tổng từ order_items |
| PAY_AND_CLOSE | visitId | ADMIN; tất cả SERVED/ticket handled; lưu payment/đóng phiên |
| CLOSE_EMPTY_TABLE | visitId | ADMIN; không đơn, không ticket OPEN; không payment |

Mỗi món chỉ một dòng, quantity 1–20, tối đa 20 dòng/đơn; note/reply tối đa 500 ký tự. Số phải nguyên, không tự làm tròn input phân số. Trường giá client không quyết định giá thanh toán.

## State và lỗi

Order: SUBMITTED → PREPARING → READY → SERVED. Ticket: OPEN → HANDLED. Table: AVAILABLE/OCCUPIED suy từ active visit. Online count đếm socket guest; không dùng disconnect để kết thúc visit. Payment CASH_SIMULATED giữ một hàng/visit và transaction cùng đóng visit.

Error codes: AUTH_FAILED, UNAUTHENTICATED, ALREADY_AUTHENTICATED, FORBIDDEN, INVALID_INPUT, NOT_FOUND, UNKNOWN_ACTION, INVALID_STATE, SESSION_CLOSED, TABLE_ALREADY_OPEN, TICKET_ALREADY_OPEN, DATABASE_ERROR. Business error trả response và giữ connection. Frame sai/timeout/network failure kết thúc connection đó.

Client request timeout 5s, connect 3s, heartbeat mỗi 5s; server idle read timeout 60s, client read timeout 20s. Sau timeout mutation, kết quả có thể đã commit. GUI giữ command trong outbox và yêu cầu đăng nhập lại để tra GET_OUTCOME. Không tự gửi một mutation mới chỉ vì timeout.

Snapshot revision trong DB tăng sau mutation thành công; lỗi không tăng. Client bỏ snapshot revision nhỏ hơn đã biết. Online count là trạng thái hiện diện tạm thời và không nằm trong business revision. Responses được xếp queue trước khi publish mutation snapshot; các peer chỉ nhận dữ liệu đúng quyền.

## Boundary bảo đảm

Transaction/khóa CafeService tuần tự hóa ghi dữ liệu và kiểm tra visit. TCP chưa TLS; dùng LAN demo. Không claim exactly-once delivery.

## Receipt và chính sách phục hồi

Đối với mutation, requestId đồng thời là command ID bền vững (1–80 ký tự). Client lưu ID và payload trước gửi; retry dùng lại đúng ID/action/payload. Principal ADMIN là tài khoản; principal GUEST gồm tài khoản và hash credential. SHA-256 fingerprint gồm action và JSON canonical sắp xếp object key, array giữ thứ tự. Số khác biểu diễn JSON có thể có fingerprint khác; retry phải giữ payload bất biến.

Receipt và mutation/revision commit cùng transaction. Replay cùng fingerprint trả outcome cũ, không tăng revision; đổi nội dung trả COMMAND_CONFLICT. Outcome thành công được lưu; lỗi xác định không tạo success receipt. GET_OUTCOME `{found:false}` không bảo đảm handler cũ sẽ không commit sau đó: unique key/khóa/transaction vẫn là nơi bảo vệ replay.

LOGIN nhận thêm credential tùy chọn. Nếu rỗng, server cấp quyền terminal mới; nếu có thì kiểm tra cùng tài khoản, không tự fallback. Identity gồm username/role/tableId/credential. Server chỉ lưu hash credential. Credential chưa bind được gắn khi mở lượt đầu, đã bind không đổi sang lượt sau. Guest cũ thấy SESSION_ENDED và không thấy dữ liệu lượt mới. Credential cũ vẫn tra outcome của chính nó sau khi lượt đóng. Không log LOGIN payload/credential.

REVIEW (GUI mặc định) lookup trước: đã nhận thì lấy outcome; chưa nhận và sai lượt thì STALE; chưa nhận đúng lượt thì CONFIRM_REQUIRED. Cả đơn và lời gọi chưa nhận đều cần xác nhận rõ, với lời giải thích theo loại. Không có TTL, không xóa ticket đã nhận. REPLAY_ALL chỉ là chế độ đối chứng được gọi từ runner local; gửi lại mọi command unresolved, vẫn có receipt/guard lượt.

DISCARD_COMMAND nguyên tử với receipt/mutation: đã nhận trả kết quả cũ; chưa nhận lưu result `{cancelledBeforeAcceptance:true}` cùng fingerprint. Lệnh gốc đến muộn bị COMMAND_DISCARDED. Đây là bỏ trước tiếp nhận, không hủy order đã lưu. Không tăng business revision khi chỉ ghi dấu bỏ. GET_OUTCOME vẫn tìm thấy dấu này.

Mã lỗi bổ sung: COMMAND_CONFLICT, COMMAND_DISCARDED, INVALID_CREDENTIAL, STALE_SESSION. START_NEW_VISIT với lượt cũ chưa đóng trả INVALID_STATE. Snapshot/request luôn dùng quyền của connection do server cấp; role/tableId client tự gửi không cấp quyền.

## Fault injection local

Mặc định `--fault=none`. `drop-order-ack` ngắt một lần sau commit PLACE_ORDER trước enqueue response; `drop-service-before` ngắt một lần trước handler CALL_SERVICE. Hook được cấu hình tại tiến trình server/constructor, không có RPC để client bật. Race test dùng barrier ngoài khóa service; không mô tả sai rằng TCP đảo thứ tự byte trong một kết nối.
