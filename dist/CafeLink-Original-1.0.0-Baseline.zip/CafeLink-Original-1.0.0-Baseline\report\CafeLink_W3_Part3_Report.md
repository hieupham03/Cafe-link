# W3.3 — Campaign phục hồi bản gốc

**Kết quả chương trình: PASS 180/180 ca, 0 ca lỗi.** Bắt đầu 16:19:46 UTC và kết thúc 16:30:33 UTC ngày 20/10/2026. Analyzer đã kiểm đủ matrix và SQLite read-only cho 180 ca; dữ liệu đọc độc lập và oracle đã lưu vào `evidence/cafelink-original/` cùng báo cáo tổng.

## Cấu hình và tái lập

```powershell
cd cafelink-system
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/recovery-experiment.ps1 -Repetitions 5 -OfflineSeconds '2,10,60' -Parallelism 6
```

Hai policy × sáu kịch bản × ba khoảng offline × năm lần lặp. Seed shuffle 20261020. Mỗi ca có server/DB/journal riêng; sáu fixture chạy song song trong cùng JVM, giao tiếp qua TCP loopback. Không dùng campaign này làm latency benchmark so sánh policy. Raw folder: `cafelink-system/target/recovery-experiment-7df3aa31-0638-444d-a0c3-1355f4c7770f/`.

Offline là cố ý không có guest kết nối trong khoảng 2/10/60 giây, server vẫn hoạt động. Không tạo packet loss hoặc độ trễ đường truyền vật lý. NORMAL không chờ offline; ba nhãn delay trong NORMAL chỉ giúp giữ số đối chứng tương ứng, không có ba mức lỗi thực tế.

## Kết quả từng kịch bản

Mỗi ô là tổng của 15 ca/policy.

| Kịch bản | REPLAY_ALL | REVIEW |
|---|---|---|
| NORMAL | 15 đơn, không ticket | 15 đơn, không ticket |
| LOST_ORDER_ACK | 15 đơn, không đơn thứ hai | 15 đơn, không đơn thứ hai |
| UNACCEPTED_ORDER | 15 đơn tự gửi lại | 0 đơn, 15 ý định chờ xác nhận |
| UNACCEPTED_SERVICE | 15 ticket tự gửi lại | 0 ticket, 15 ý định chờ xác nhận |
| LOST_SERVICE_ACK | 15 ticket, lấy lại outcome | 15 ticket, lấy lại outcome |
| VISIT_CHANGED | Không tác dụng ở lượt mới | Không tác dụng ở lượt mới |

CSV ghi nhận 0 duplicateOrders và 0 wrongVisitEffects. Cả hai policy dùng cùng receipt/idempotency và guard lượt. Vì vậy, chống đơn trùng/sai lượt là hiệu quả của cơ chế chung; không gán riêng lợi ích này cho REVIEW. Khác biệt đo được là ý định chưa nhận có được tự gửi lại hay cần khách xác nhận.

## Ý nghĩa và giới hạn

REVIEW tránh tự tạo 15 lời gọi chưa được xác nhận lại, đồng thời buộc khách xác nhận cả 15 đơn chưa nhận. Điều này đánh đổi sự chủ động lấy thao tác bổ sung của khách. Không có dữ liệu để khẳng định 15 nhu cầu thực sự hết hiệu lực, cải thiện sự hài lòng hoặc giảm chi phí vận hành tại quán.

REVIEW bản gốc chưa có TTL, chưa tự bỏ lời gọi theo thời gian, chưa khác nhau thật sự giữa hai loại ý định chưa nhận. Các khoảng offline kiểm tra trạng thái qua thời gian chờ, không chứng minh expiry. U2 trong Upgrade Plan là công việc sau baseline, chưa được đưa vào kết quả.

`recoveryMs` gồm reconnect/login PBKDF2/journal/refresh/reconcile và loại offline; không gồm thời gian chờ con người. Chạy song song tạo tranh chấp CPU nên chỉ báo số mô tả, không so sánh nhanh/chậm bằng các con số này. `sentBytes/receivedBytes` gồm hai kết nối guest và login; không so trực tiếp với traffic sau warmup của benchmark.

File private-outbox chứa credential chỉ giữ cục bộ tại target. Evidence công khai gồm CSV, metadata, bảng oracle và hash, không chứa journal hoặc DB xác thực.
