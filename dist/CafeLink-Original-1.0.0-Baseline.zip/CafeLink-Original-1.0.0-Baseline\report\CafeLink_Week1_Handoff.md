# CafeLink — Bàn giao tuần 1

Ngày: **14/10/2026**. Trạng thái: **toàn bộ baseline tuần 1 đã triển khai, kiểm thử và đóng gói**. Mã nguồn: `../cafelink-system`. Đây là code mới, không dùng code khảo sát làm code nộp.

Báo cáo dự án theo cấu trúc technical paper đã được tổng hợp tại [CafeLink_Project_Report.md](CafeLink_Project_Report.md), kèm [bản Word](CafeLink_Project_Report_Draft.docx). Các phần tuần 1 đã được điền từ code và artifact hiện có; contribution và thực nghiệm đối chứng được đánh dấu chờ hoàn thành.

## Đã chạy được

- Server TCP/SQLite và console vận hành; app khách và màn hình chủ quán Swing.
- Xác thực chủ quán/6 tài khoản bàn, quyền và phạm vi dữ liệu do server quyết định.
- Mở bàn, menu 8 đồ uống, chọn số lượng/ghi chú, đặt món với giá tính tại server.
- Chủ quán chuyển SUBMITTED → PREPARING → READY → SERVED; nhiều bàn gửi đồng thời.
- Gọi phục vụ, yêu cầu hóa đơn, chống ticket OPEN cùng loại, phản hồi tới guest.
- Hóa đơn tổng VND nguyên, thanh toán mô phỏng và đóng phiên nguyên tử; đóng bàn trống riêng.
- Server push, presence, heartbeat, lỗi request/frame, giới hạn connections/queues, manual reconnect.
- Persistence qua restart; sau đổi lượt, nháp guest được xóa và mutation mang visit cũ bị chặn.

## Báo cáo theo từng phần

| Phần | Kết quả tại mốc | Báo cáo |
|---|---|---|
| W1.1 Protocol/build | 6 tests pass | [Part 1](CafeLink_W1_Part1_Report.md) |
| W1.2 Database/service | 12 cumulative tests pass | [Part 2](CafeLink_W1_Part2_Report.md) |
| W1.3 TCP/concurrency | 20 cumulative tests pass | [Part 3](CafeLink_W1_Part3_Report.md) |
| W1.4 Swing workflows | 23 cumulative tests pass | [Part 4](CafeLink_W1_Part4_Report.md) |
| W1.5 Integration/package | **27 cumulative tests pass** + process restart smoke | [Part 5](CafeLink_W1_Part5_Report.md) |

Mỗi mốc đã test và viết report trước khi chuyển phần tiếp theo. Số ở mốc cũ là lịch sử, không cộng các cumulative counts thành tổng khác.

## Kết quả cuối cùng

27 JUnit tests: **6 codec + 7 service + 10 network + 4 UI**, 0 lỗi/thất bại/skipped. UI suite bấm nút/form thật, dùng TCP và SQLite thật; modal được trả lời tự động bằng test Dialogs. Có 12 client đặt đồng thời; có race payment/order và lỗi ghi DB giữa chừng. GUI login, reset nháp, disabled actions khi disconnect đã kiểm chứng.

Smoke packaged jar: server và scenario client ở hai JVM, 3 guest connections; trước/sau restart đều **3 đơn, 190.000 VND, 1 ticket HANDLED**. Thời gian chạy test không dùng làm latency/throughput benchmark. Chưa có thử nghiệm LAN nhiều máy hoặc baseline/proposed contribution.

## Chạy ngay

Trong terminal tại `D:\BTL-LTM\cafelink-system`:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/demo.ps1
```

Demo mở server và 3 cửa sổ khách. Trong Server console bấm mở quản trị; login `admin / CafeLink@123`. Khách `ban1 / Ban1@123`, `ban2 / Ban2@123`, `ban3 / Ban3@123`. Chủ quán mở bàn trước khi khách đặt. Dùng cổng khác bằng `-Port 5051` nếu cần. Tài khoản là dữ liệu demo; không nhập mật khẩu thật vào TCP chưa TLS.

Chạy riêng/LAN/configuration: [README](../cafelink-system/README.md). Chi tiết [Protocol](../cafelink-system/docs/PROTOCOL.md), [Kiến trúc](../cafelink-system/docs/ARCHITECTURE.md), [Demo](../cafelink-system/docs/DEMO.md).

## Ảnh giao diện đã kiểm tra

Ảnh render từ JFrame trong UI test, không dùng mockup. Thời điểm chụp đơn đã phục vụ và ticket đã phản hồi trước thanh toán.

![Quầy chủ quán](statics/cafelink-week1/admin-serving.png)

![Màn hình khách và phản hồi](statics/cafelink-week1/guest-feedback.png)

![Màn hình guest mất kết nối](statics/cafelink-week1/guest-disconnected.png)

## Tuần 2 tiếp tục từ đâu

1. CafeService/Database: bổ sung receipt key (principal, session, request ID), payload fingerprint và outcome cùng transaction nghiệp vụ.
2. Protocol: query receipt/outcome, auth ràng buộc phiên và response recovery contract.
3. NetworkClient: outbox bền vững, kết nối lại/đối chiếu trước replay; lời gọi phục vụ chưa nhận phải xác nhận lại.
4. CafeServer: fault injection sau commit/trước ACK; baseline/proposed có cấu hình riêng và cùng workload.
5. GUI: trình bày trạng thái chưa rõ kết quả, phục hồi được xác nhận và đề nghị gửi mới; không tự bind lệnh cũ vào phiên mới.

Code hiện đã có role, visit, transaction và request correlation; đó là nền, **không được nói durable recovery contribution đã xong**. Chưa có sửa/hủy món, inventory hoặc payment gateway. Kế hoạch chi tiết: [CafeLink_Implementation_Plan.md](CafeLink_Implementation_Plan.md).
