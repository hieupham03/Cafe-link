"""Export the CafeLink Markdown draft to Word, preserving tables and images."""

from pathlib import Path
import re
import xml.etree.ElementTree as ET

import markdown
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt
from docx.opc.constants import RELATIONSHIP_TYPE as RT


REPORT_DIR = Path(__file__).resolve().parents[1]
SOURCE = REPORT_DIR / "CafeLink_Project_Report.md"
OUTPUT = REPORT_DIR / "CafeLink_Project_Report_Draft.docx"


def inline(paragraph, element, bold=False, italic=False, code=False):
    """Preserve Markdown inline formatting and clickable source references."""
    def add(value):
        if value:
            run = paragraph.add_run(value)
            run.bold, run.italic = bold, italic
            if code:
                run.font.name = "Consolas"
                run.font.size = Pt(10)

    add(element.text)
    for child in element:
        if child.tag == "br":
            paragraph.add_run().add_break()
        elif child.tag == "a":
            href = child.attrib.get("href", "")
            label = "".join(child.itertext())
            if re.match(r"https?://", href):
                link = OxmlElement("w:hyperlink")
                relation = paragraph.part.relate_to(href, RT.HYPERLINK, is_external=True)
                link.set(qn("r:id"), relation)
                run = OxmlElement("w:r")
                properties = OxmlElement("w:rPr")
                style = OxmlElement("w:rStyle")
                style.set(qn("w:val"), "Hyperlink")
                properties.append(style)
                run.append(properties)
                text = OxmlElement("w:t")
                text.text = label
                run.append(text)
                link.append(run)
                paragraph._p.append(link)
                # Keep the source URL visible in printed reports too.
                paragraph.add_run(f" ({href})")
            else:
                add(f"{label} ({href})" if label != href else label)
        elif child.tag == "img":
            image_path = (REPORT_DIR / child.attrib["src"]).resolve()
            if not image_path.is_file():
                raise FileNotFoundError(image_path)
            paragraph.add_run().add_picture(str(image_path), width=Cm(16))
        else:
            inline(paragraph, child, bold or child.tag == "strong",
                   italic or child.tag == "em", code or child.tag == "code")
        add(child.tail)


def render(document, element):
    tag = element.tag
    if re.fullmatch(r"h[1-6]", tag):
        level = int(tag[1])
        paragraph = document.add_heading(level=0 if level == 1 else level - 1)
        inline(paragraph, element)
    elif tag == "p":
        paragraph = document.add_paragraph()
        inline(paragraph, element)
        if element.find("img") is not None:
            paragraph.alignment = 1
            image = element.find("img")
            document.add_paragraph(image.attrib.get("alt", ""), style="Caption")
    elif tag == "pre":
        paragraph = document.add_paragraph(style="Code Block")
        paragraph.add_run("".join(element.itertext()))
    elif tag == "table":
        rows = element.findall(".//tr")
        columns = max(len(list(row)) for row in rows)
        table = document.add_table(rows=0, cols=columns)
        table.style = "Table Grid"
        for index, row in enumerate(rows):
            cells = table.add_row().cells
            for cell, content in zip(cells, row):
                paragraph = cell.paragraphs[0]
                inline(paragraph, content, bold=index == 0)
                for run in paragraph.runs:
                    run.font.size = Pt(10)
                paragraph.paragraph_format.space_after = Pt(3)
            if index == 0:
                repeated = OxmlElement("w:tblHeader")
                table.rows[0]._tr.get_or_add_trPr().append(repeated)
        document.add_paragraph()
    elif tag in {"ol", "ul"}:
        for item in element.findall("li"):
            paragraph = document.add_paragraph(style="List Number" if tag == "ol" else "List Bullet")
            inline(paragraph, item)
    else:
        for child in element:
            render(document, child)


def export():
    html = markdown.markdown(SOURCE.read_text(encoding="utf-8"),
                             extensions=["tables", "fenced_code"], output_format="xhtml")
    root = ET.fromstring(f"<root>{html}</root>")
    document = Document()
    section = document.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin = section.bottom_margin = Cm(2)
    section.left_margin = section.right_margin = Cm(2.5)
    normal = document.styles["Normal"]
    normal.font.name, normal.font.size = "Times New Roman", Pt(12)
    normal.paragraph_format.line_spacing = 1.15
    normal.paragraph_format.space_after = Pt(6)
    for name in ["Title", "Heading 1", "Heading 2", "Heading 3"]:
        document.styles[name].font.name = "Times New Roman"
    code = document.styles.add_style("Code Block", 1)
    code.font.name, code.font.size = "Consolas", Pt(8)
    code.paragraph_format.line_spacing = 1
    # Avoid splitting short protocol/architecture blocks across pages.
    code.paragraph_format.keep_together = True
    footer = section.footer.paragraphs[0]
    footer.alignment = 1
    footer.add_run("CafeLink – Bản thảo | Trang ")
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)
    document.core_properties.title = "CafeLink – Báo cáo bài tập lớn Lập trình mạng"
    document.core_properties.subject = "CafeLink: triển khai và thực nghiệm Client/Server TCP"
    for element in root:
        render(document, element)
    document.save(OUTPUT)
    # Reopen to catch an invalid package before claiming successful export.
    reopened = Document(OUTPUT)
    print(f"Created {OUTPUT.name}: {len(reopened.paragraphs)} paragraphs, "
          f"{len(reopened.tables)} tables, {len(reopened.inline_shapes)} images")


if __name__ == "__main__":
    export()
