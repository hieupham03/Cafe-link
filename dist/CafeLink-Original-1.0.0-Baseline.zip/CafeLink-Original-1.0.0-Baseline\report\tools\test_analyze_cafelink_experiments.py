import unittest
from analyze_cafelink_experiments import audit_samples, percentile


class EvidenceAnalysisTest(unittest.TestCase):
    def test_nearest_rank_small_and_unsorted_samples(self):
        self.assertEqual(percentile([100, 1, 3, 2], .5), 2)
        self.assertEqual(percentile(list(range(1, 21)), .95), 19)
        with self.assertRaises(ValueError):
            percentile([], .95)

    def test_failure_is_retained_and_must_match_summary(self):
        rows = [dict(sampleId="one", outcome="IOException", startedMs="0", endedMs="100", latencyMs="100")]
        self.assertEqual(audit_samples(rows, dict(requests=1, successes=0, errors=1)), 0)
        with self.assertRaises(ValueError):
            audit_samples(rows, dict(requests=1, successes=1, errors=0))

    def test_duplicate_ids_and_impossible_timing_fail(self):
        row = dict(sampleId="one", outcome="OK", startedMs="10", endedMs="20", latencyMs="10")
        with self.assertRaises(ValueError):
            audit_samples([row, row], dict(requests=2, successes=2, errors=0))
        row["latencyMs"] = "-1"
        with self.assertRaises(ValueError):
            audit_samples([row], dict(requests=1, successes=1, errors=0))


if __name__ == "__main__":
    unittest.main()
