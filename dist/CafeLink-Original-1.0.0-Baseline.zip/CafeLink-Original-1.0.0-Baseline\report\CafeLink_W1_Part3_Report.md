# W1.3 — TCP Server, Client và server push

Trạng thái: hoàn thành, 14/10/2026.

CafeServer phục vụ tối đa 32 reader connections, mỗi peer có outbound queue giới hạn 64 message và writer riêng. Connection được xác thực trên server; guest chỉ có quyền bàn tài khoản được gán. NetworkClient có một reader phân tuyến response theo ID và STATE_UPDATED events, heartbeat 5 giây, request timeout 5 giây và timeout socket. Timeout/ngắt kết nối không tự retry mutation, tránh tuyên bố kết quả chưa biết là đã thất bại.

Không ghi mật khẩu/payload login vào log. Client malformed/slow bị ngắt riêng, không dừng server. Snapshot business revision giúp UI không áp dụng bản cũ hơn. Trạng thái online là hiện diện connection, không phải lượt sử dụng bàn.

`scripts/maven.ps1 -B test`: **20 tests pass, 0 failures/errors/skipped**. NetworkIntegrationTest có 8 tests qua localhost TCP thật: chưa auth/login sai; action sai; isolation giữa bàn; payload sai; server push không guest polling; workflow phục vụ/hóa đơn/thanh toán; frame length ác ý chỉ ngắt peer; manual reconnect giữ đơn; 12 khách đồng thời tạo 12 đơn riêng/tổng bill đúng; shutdown làm connection lỗi hợp lý (một số case nằm cùng test).

Thời gian suite network được Surefire ghi 5.533 s; đây là thời gian chạy tests, không phải benchmark response time. Không suy ra throughput LAN hoặc hiệu năng nhiều máy từ test trên một host.

Giới hạn: contribution receipt bền vững/outbox/phục hồi có phân loại chưa có. RPC ID hiện chỉ tương quan phản hồi. TCP chưa mã hóa. Phần tiếp theo là GUI và script chạy nhiều tiến trình.
