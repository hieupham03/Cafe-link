# W3.5 — Evidence, báo cáo và truy vết trước nâng cấp

## Nội dung hoàn thiện

Báo cáo technical paper giữ đủ phần yêu cầu của học phần: vấn đề, nền tảng/khảo sát, yêu cầu, phương pháp, kiến trúc, giao thức, triển khai, thiết lập đo, kết quả, thảo luận, contribution, hạn chế, hướng phát triển, kết luận, nguồn và phụ lục.

Analyzer chỉ điền số liệu khi campaign PASS, đủ matrix và SQLite oracle khớp. Bảng/biểu đồ latency/throughput/traffic/storage giữ dữ liệu từng lần; kết quả phục hồi tách đúng tác dụng chung của idempotency/guard với quyết định REVIEW. Không gán hiệu quả chống trùng riêng cho policy REVIEW; không claim TTL/SEMANTIC hoặc mạng LAN vật lý.

`CafeLink_Requirements_Traceability.md` nối F01–F13 và các yêu cầu mạng/lỗi/đồng thời tới lớp và suite/campaign. Các điều kiện bên ngoài có trạng thái riêng: LAN hai máy NOT RUN, bìa/thành viên hoãn theo người dùng, Compilatio/nộp/duyệt Word trực quan chưa thực hiện.

## Quy trình kiểm tra tài liệu

```powershell
python report/tools/export_cafelink_report.py
python report/tools/validate_cafelink_report.py --output report/evidence/cafelink-original/report-validation.json
```

Validator kiểm link/image nội bộ, file ảnh, số liệu đo xuất hiện trong Markdown và DOCX, ZIP DOCX hợp lệ, số bảng/ảnh tương ứng và số tham khảo được định nghĩa. Nó không duyệt ngắt trang hoặc độ đẹp bố cục Word; cần người mở Word xem trước khi nộp.

## Trạng thái kiểm tra cuối

**PASS.** Word đã xuất lại theo số đo cuối: 243 paragraphs, 22 bảng, 5 hình; 43 link/image nội bộ tồn tại và 14 mục tham khảo được định nghĩa. DOCX ZIP hợp lệ, số liệu chính khớp Markdown, PNG đã kiểm file và biểu đồ đã xem trực tiếp. [Kết quả máy đọc được](evidence/cafelink-original/report-validation.json).

Giữ 9 placeholder metadata theo yêu cầu người dùng; không coi đó là lỗi đã tự điền. Chưa duyệt trực quan phân trang Word hoặc chạy Compilatio. Mỗi yêu cầu kỹ thuật có bằng chứng trong ma trận truy vết; LAN hai máy NOT RUN. Candidate source build đạt 59/59 test không skip, cả hai smoke chứng minh listener cũ đã đóng; ZIP cuối kiểm lại runtime và source hash giống candidate.
