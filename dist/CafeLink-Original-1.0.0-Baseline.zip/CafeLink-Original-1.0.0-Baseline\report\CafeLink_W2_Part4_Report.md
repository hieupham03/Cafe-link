# W2.4 – Tích hợp, fault demo và đối chứng chức năng

Hoàn thành 20/10/2026. Build package bằng `scripts/build.ps1`: **49 tests, 0 failures/errors/skipped**. Có thêm UI test tab Phục hồi: journal có ý định chưa gửi, chưa tạo ticket, nút đặt mới bị khóa, bấm xác nhận qua UI tạo đúng một ticket và cập nhật RESOLVED. Ảnh JFrame thật lưu tại `report/statics/cafelink-week2/guest-recovery.png`.

Server CLI có `--fault=none|drop-order-ack|drop-service-before`, script run-server có `-Fault`; mặc định none. Hook local trước tiếp nhận/sau commit, không có RPC để khách bật. REPLAY_ALL chỉ là baseline explicit của runner; GUI mặc định REVIEW.

`scripts/smoke.ps1`: packaged server/client ở hai JVM, trước/sau restart đều 3 đơn, 190.000 VND, 1 ticket HANDLED, PASS. Artifact: `target/smoke-7e2c070498f6421fa617708eb3b57056`.

`scripts/recovery-experiment.ps1 -Repetitions 3`: **24 ca PASS** (2 chính sách × 4 kịch bản × 3 lần). Mỗi ca có DB/snapshot/log; CSV/metadata được chép vào report/evidence/cafelink-week2, không chép journal có credential.

| Quan sát, ba lần lặp/chính sách | REPLAY_ALL | REVIEW |
|---|---:|---:|
| Bình thường đúng một đơn | 3/3 | 3/3 |
| Mất ACK đơn, lấy đúng kết quả/không trùng | 3/3 | 3/3 |
| Ticket tự tạo khi lời gọi chưa nhận, chưa xác nhận lại nhu cầu | 3 | 0 |
| Ca lời gọi cần xác nhận lại | 0 | 3 |
| Tác dụng sai lượt trong ca đổi khách | 0 | 0 |

Hai bản có cùng idempotency và guard lượt; khác chính sách phục hồi. Không dùng kết quả này để nói REVIEW cải thiện chống lặp/guard so với REPLAY_ALL. Chưa đo nhu cầu thực tế hoặc TTL. Runner dùng localhost/socket riêng nhưng server/client cùng JVM; thời gian recoveryMs có cả PBKDF2/journal I/O, ba mẫu không đủ benchmark. Tuần 3 tiếp tục tải/LAN, số mẫu đủ, delay có kiểm soát, byte/storage và chi phí xác nhận lại.

Kiểm tra đóng gói bổ sung: `scripts/smoke.ps1 -Recovery` PASS. JVM khách kết thúc khi đang PENDING, server dừng/restart, JVM khách mới resume credential từ file: vẫn đúng một đơn 30.000 VND và journal RESOLVED. Artifact `target/smoke-475ac344968247089689a65c415b73b5/`. Build cuối sau bổ sung fixture vẫn 49 test đạt.
