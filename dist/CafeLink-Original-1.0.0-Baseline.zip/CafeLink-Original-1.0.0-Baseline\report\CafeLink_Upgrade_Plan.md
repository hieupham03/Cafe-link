# Kế hoạch nâng cấp CafeLink trước hạn nộp 31/10/2026

Ngày lập: **20/10/2026**. Mốc xuất phát: **CafeLink tuần 2**, 49 kiểm thử đạt, smoke khởi động lại và 24 ca đối chứng chức năng. Thời gian còn lại theo kế hoạch: **21–31/10/2026**, hạn nộp 23:59 ngày 31/10 theo [Submission.md](../final-project/Submission.md).

**Đây là kế hoạch, chưa phải các tính năng đã triển khai hoặc kết quả đã đo.** Giữ evidence tuần 2 làm lịch sử; mốc E0 chính dùng bản gốc tuần 3 đã nghiệm thu và đóng gói. Những thay đổi dưới đây không được tự ghi thành DONE trong báo cáo chính.

**Mốc chuẩn bị sau kế hoạch:** đã hoàn tất bản gốc tuần 3 trên một máy: 59/59 test Java (0 failures/errors/skipped), 3 test bộ phân tích Python, 180/180 ca phục hồi, 20/20 lần đo tải với 10,800 request và 0 lỗi; [bàn giao/ZIP E0](CafeLink_Original_Handoff.md). Công cụ đo và baseline E0 của U0 đã có; chưa triển khai JOIN/resume/SEMANTIC/dashboard/menu/CI/app-image. Không chạy lại toàn bộ chuẩn bị E0 nếu source/JAR không thay đổi. LAN hai máy vẫn NOT RUN.

## 1. Đích nâng cấp

Đưa CafeLink gần mức hoàn thiện kỹ thuật của repo TOEIC ở các tiêu chí có thể kiểm chứng: vòng đời kết nối/xác thực, xử lý lỗi, giao diện vận hành, thực nghiệm tái lập, đóng gói và bảo vệ. Không đặt đích bằng số tính năng hoặc số test của họ. Không thể bảo đảm điểm số; nhóm cần sản phẩm chạy đúng, số liệu thật và hiểu được mã đã nộp.

Giữ bài toán một quán, sáu bàn, hai vai trò, khách dùng client desktop tại bàn. Giữ Java/Swing, TCP Socket, SQLite, receipt/outbox hiện tại. Không chuyển framework hoặc database trong đợt này. Đối chiếu TOEIC theo commit cố định `d2c8f01`, không nhận xét lại một HEAD chưa đọc. Xem [bản so sánh](CafeLink_vs_Toeic_Monitoring.md).

Theo [rubric đề xuất](../final-project/Instruction.md), network implementation 25%, contribution 15%, experiment 15%, demo/bảo vệ 15%: bốn phần này cộng 70%. Nâng cấp phải có luồng demo và bằng chứng gắn với các phần đó; giao diện đẹp hoặc nhiều CRUD không tự tạo contribution.

## 2. Phạm vi được chọn và thứ tự ưu tiên

**P0:** cần hoàn thành để đạt mục tiêu đợt nâng cấp. **P1:** làm sau P0 hoặc khi phép đo chỉ ra cần thiết; cắt P1 nếu chậm. Ước lượng là ngày công tập trung có AI hỗ trợ, không phải cam kết thời lượng hay giả định AI thay được kiểm thử máy thật.

| Gói | Mức | Nâng cấp | Giá trị thực tế | Ước lượng |
|---|---|---|---|---|
| U0 | P0 | Chốt contract, bổ sung bộ ghi phép đo và chạy mốc hiện tại | Biết đang yếu ở đâu; đo được trước/sau | 0,5 ngày |
| U1 | P0 | Mã vào bàn theo lượt, resume credential, thu hồi/hết hạn, reconnect có giới hạn | Khách không nhập lại mật khẩu khi Wi-Fi chập chờn; mật khẩu bàn cũ không cấp quyền khách mới | 1,5–2 ngày |
| U2 | P0 | Phân biệt ý định đặt món và lời gọi phục vụ thật sự trong recovery | Giữ ý định đặt món; chặn lời gọi chưa nhận đến muộn mà không cần TTL | 1 ngày |
| U3 | P0 | Dashboard vận hành, hàng đợi pha chế, trạng thái mạng và phục hồi dễ hiểu | Chủ quán xử lý việc cần làm; khách biết quán đã nhận hay chưa | 1 ngày |
| U4 | P0 | Tạm hết món và kiểm tra phiên bản giá khi xác nhận đơn | Không bán món hết hoặc âm thầm tính giá mới cho ý định cũ | 0,5–1 ngày |
| U4b | P1 | Lịch sử hóa đơn đã đóng, phân trang | Tra cứu giao dịch thật sự đã lưu | 0,5 ngày |
| U5 | P1 có điều kiện | Push đúng phạm vi; gộp snapshot chờ của client chậm | Giảm gửi trạng thái thừa và backlog nếu phép đo cho thấy vấn đề | 0,5–1 ngày |
| U6 | P0 | Thực nghiệm tải/lỗi, CI, app-image, LAN và báo cáo/bảo vệ | Sản phẩm tái lập được và có bằng chứng định lượng | 2–3 ngày, có thời gian máy chạy |

U6 không đợi đến khi code xong: script đo/CI hình thành sớm, mỗi gói đều kiểm thử và cập nhật bằng chứng. Không có mục tiêu “phải đạt 500/1.000 test”; dùng độ phủ tình huống và chất lượng oracle.

## 3. U0 – Chốt contract và thiết lập phép đo

### Công việc

- Lưu version/source identifier hoặc manifest SHA-256 của mã, cấu hình, artifact và trạng thái dataset trước nâng cấp. Không đưa credential/journal riêng vào evidence công khai.
- Bổ sung recorder ghi request ID, action, trạng thái kết quả, thời điểm đơn điệu trong cùng tiến trình, byte frame ứng dụng gửi/nhận, số reconnect và số lần xác nhận lại. Không ghi password/token/nội dung riêng tư của ghi chú.
- Tách thời gian connect, xác thực, request nghiệp vụ và phục hồi. Không gộp PBKDF2/login vào latency đặt món mà không nói rõ.
- Chạy workload nhỏ trước khi sửa transport; giữ CSV gốc và lỗi/timeout. Nếu chưa có bộ đo ổn định, hoàn thiện recorder trước, không suy số baseline từ thời gian chạy JUnit.

### Hoàn thành khi

Một script tạo manifest/config/raw CSV/summary riêng mỗi lần chạy, không ghi đè lần trước; có thể truy từ một dòng metric đến log cùng ID. Có phép đo mốc tuần 2 cho các workload mà bản tuần 2 hỗ trợ. Điều kiện P1/U5 được quyết định từ mốc này hoặc profile lặp lại sau U1–U4.

## 4. U1 – Vào bàn và kết nối lại thuận tiện, quyền theo đúng lượt

### Luồng sản phẩm đích

1. Chủ quán đăng nhập, mở bàn. Server cấp mã vào bàn ngẫu nhiên tám ký tự, chỉ có hiệu lực cho lượt đó; chủ quán đưa mã cho khách trên terminal demo.
2. Khách chọn bàn, nhập mã để JOIN_TABLE. Không yêu cầu khách dùng một mật khẩu bàn cố định có quyền xin credential mới vô hạn.
3. Server trả credential resume; client giữ trong journal. Reconnect sử dụng credential, không lưu/gửi lại mật khẩu người dùng ngầm.
4. Sau mất mạng ngắn, client tự kết nối lại, resume, lấy trạng thái và đối chiếu lệnh. Khách không phải đóng/mở cửa sổ.
5. Bàn kết thúc lượt: quyền đặt/gọi hết hiệu lực. Credential còn hợp lệ có thể tra receipt của chính lượt cũ; không được đọc hoặc thay đổi lượt mới. Khách mới cần mã mới.

Không thêm web/QR vào bản nộp này. JOIN bằng mã trong Swing giải quyết cấp quyền theo lượt mà không cần thêm HTTP server hoặc giao diện thứ hai. Mã được lưu hash; chỉ hiển thị lúc cấp, chủ quán có thể cấp lại mã nếu cần. Đổi mã vào bàn không tự hủy các credential khách đã được cấp hợp lệ.

### Thiết kế kỹ thuật

- Thêm JOIN_TABLE và RESUME; giữ login mật khẩu cho ADMIN. Luồng guest dùng mật khẩu bàn hiện tại không tiếp tục là đường cấp quyền production song song, nếu không lỗ hổng cũ vẫn còn. Fixture/test phát triển phải được phân biệt rõ.
- Session có `expires_at`, `revoked_at`, quyền và visit. Thu hồi kiểm ở request lẫn trước push. Đóng lượt và thu hồi session là hai thao tác khác nhau: đóng lượt không làm mất khả năng đối chiếu receipt cũ ngay lập tức.
- Thời hạn session là cấu hình server, mặc định đề xuất tám giờ để đủ một ca demo; đây là auth expiry, không phải TTL của yêu cầu phục vụ. Credential hết hạn/thu hồi dừng tự reconnect và yêu cầu người dùng xác thực/cấp quyền lại đúng luồng.
- Giới hạn thử mã sai theo kết nối/tài khoản bàn, có cooldown và bộ nhớ giới hạn; không ghi mã vào log hoặc dòng lệnh. Chỉ guest scope đúng bàn/lượt được cấp từ server, không tin role/table do client tự khai.
- ConnectionManager sở hữu vòng đời transport: sáu lần thử reconnect, backoff 1/2/4/8/8/8 giây, connect timeout tối đa ba giây, tổng ngân sách outage tối đa 60 giây. Mỗi lần chờ/handshake bị chặn bởi ngân sách còn lại; không nhân worker qua mỗi lần mất mạng. Hết ngân sách có nút Thử kết nối lại.
- Tách socket của một lần kết nối khỏi journal/session sống lâu hơn. Callback có generation; reader/heartbeat của socket cũ không được làm hỏng kết nối mới.
- Không tự gửi mutation chỉ vì transport đã nối lại. Recovery U2 quyết định từng ý định.
- ADMIN có thể ngắt/thu hồi phiên guest. Ngắt socket không kết thúc lượt và không hủy đơn. ADMIN hết session cần login lại; không bắt buộc lưu token ADMIN xuống đĩa để tự đăng nhập.

### Kiểm thử bắt buộc

Mã sai/hết lượt, mã của bàn khác, mật khẩu guest cũ không bypass JOIN, resume sau server restart, token bị thu hồi/hết hạn, close/mở bàn, receipt cũ còn truy đúng quyền, callback socket cũ, reconnect hết ngân sách, stop/logout trong backoff và không nhân reader/heartbeat. Dùng clock có thể điều khiển cho expiry; không chờ tám giờ trong test.

### Giá trị so với mốc hiện tại

Thu hẹp khoảng cách với vòng đời auth/reconnect của TOEIC và giải quyết một bất tiện nhìn thấy được: nhập lại mật khẩu sau mỗi lần đứt mạng. Đồng thời sửa giới hạn shared table password đã ghi trong báo cáo, không chỉ thêm một lớp token có tên khác.

## 5. U2 – Contribution có khác biệt policy thật, tận dụng code đang có

### Chính sách đích

| Loại ý định | Đã commit nhưng client mất phản hồi | Chưa ghi nhận, lượt còn hiệu lực | Lượt đã đóng |
|---|---|---|---|
| PLACE_ORDER | Tra receipt, hiển thị đúng đơn; không tạo lại | Giữ ID/payload trong outbox, cho khách xác nhận hoặc bỏ; kiểm lại giá/món trước khi nhận | Không tạo đơn mới; receipt cũ nếu có vẫn được đối chiếu |
| CALL_SERVICE / REQUEST_BILL | Tra ticket đã nhận và trạng thái hiện tại; không âm thầm xóa | Tự kết thúc ý định của lần kết nối trước bằng DISCARD_COMMAND; nếu vẫn cần, khách bấm gọi mới với ID mới | Không chuyển lời gọi sang lượt mới |

**Không dùng TTL.** Ranh giới là lời gọi phục vụ chưa được quán nhận khi client đối chiếu lại sau mất kết nối. Phần mềm không đoán rằng mọi khách đã hết nhu cầu: giao diện nói rõ lời gọi chưa nhận đã dừng, khách có thể gọi mới.

### Vì sao đáng làm

Mốc tuần 2 đặt cả hai loại ở CONFIRM_REQUIRED. Lookup có thể chưa thấy receipt trong khi handler cũ còn đang chờ. U2 dùng dấu bỏ bền vững đã có để tạo ranh giới nguyên tử: nếu handler đã commit trước thì trả ticket có thật; nếu DISCARD thắng thì handler đến muộn bị chặn. Khách không bị một lời gọi cũ bất ngờ xuất hiện sau khi đã kết nối lại và tiếp tục sử dụng.

Đơn hàng là ý định cần giữ để kiểm tra/xác nhận, không bị tự hủy khi mất mạng. Lời gọi chưa nhận được kết thúc; nút gọi mới tạo ý định mới. Như vậy “theo loại” có khác biệt trạng thái và tác dụng server, không chỉ khác câu thông báo. Chi phí là thêm một request bỏ và có thể cần khách bấm gọi lại; phải đo chi phí này.

### Công việc

- Thêm policy SEMANTIC; giữ REPLAY_ALL và REVIEW hiện có trong runner để làm đối chứng, không đổi ý nghĩa tên baseline sau khi đã đo.
- RecoveryCoordinator lookup trước; nếu lời gọi chưa nhận thì DISCARD_COMMAND cùng ID/action/payload. Lấy kết quả chính thức của thao tác đó để phân biệt đã nhận với đã bỏ.
- Nếu kết nối mất trong lúc discard, giữ trạng thái chưa rõ của thao tác bỏ, tra receipt khi reconnect; không đánh dấu đã bỏ chỉ vì đã gửi bytes.
- Giữ invariant receipt + mutation transaction, fingerprint, credential và visit. Cùng ID khác payload vẫn bị chặn; không remap outbox sang lượt mới.
- UI hiển thị nhu cầu theo từ ngữ nghiệp vụ; ID/log kỹ thuật nằm trong màn chẩn đoán hoặc artifact.

### Kiểm thử/so sánh bắt buộc

Giữ handler cũ trước bước nhận, cho lookup trả chưa thấy rồi reconnect/discard và thả handler; thử cả thứ tự commit thắng và discard thắng. Thêm mất phản hồi discard, server restart giữa các bước, ticket đã được xử lý lúc khách offline và đơn hàng vẫn cần xác nhận. Kiểm tra client không coi lời gọi đã nhận là đã hủy. Đối chứng REVIEW đặc biệt hữu ích để xem dấu bỏ tự động giải quyết tình huống handler cũ mà chỉ chờ người dùng chưa giải quyết.

### Phát biểu contribution dự kiến

> CafeLink thiết kế và đánh giá cơ chế phục hồi ý định sau mất kết nối: giữ ý định đặt món để đối chiếu/xác nhận, kết thúc nguyên tử lời gọi phục vụ chưa được tiếp nhận, và ràng buộc mọi thay đổi với lượt sử dụng bàn. Cơ chế dùng receipt/outbox bền vững, kiểm tra nội dung và thực nghiệm đối chứng để đánh giá tính đúng cùng chi phí phục hồi.

Đây là mục tiêu của nâng cấp, chỉ đưa vào phần kết quả sau khi implementation/test chứng minh. Không tuyên bố idempotency, fencing hay dấu bỏ là phát minh mới.

## 6. U3/U4 – Chất lượng sử dụng và demo

### U3: Chủ quán nhìn thấy việc cần làm

- Dashboard có số bàn đang phục vụ, đơn chờ pha, đơn sẵn sàng và yêu cầu phục vụ chưa xử lý; tất cả lấy từ server, không gắn số giả.
- Chế độ “Quầy pha chế” nhóm đơn theo trạng thái, hiển thị bàn, món, ghi chú và thời gian chờ. Một thao tác chuyển sang bước kế tiếp; không thêm quy trình bếp/phân ca.
- Chế độ quầy là một view thuộc quyền ADMIN hiện có, không giả là vai trò BARISTA đã được phân quyền riêng. Hai cửa sổ ADMIN có thể cùng quan sát/xử lý; server kiểm chuyển trạng thái nguyên tử.
- Client khách có giỏ hàng/tổng dự kiến rõ, trạng thái đã nhận/chưa rõ/chưa nhận; trong reconnect hiển thị dữ liệu cũ có nhãn và khóa mutation phù hợp. Không hiện UUID dài trong luồng thường.
- Bố cục dùng được ở 1366×768 và 1600×900, phím/nút không bị che; không chuyển Swing sang JavaFX để làm giao diện đẹp hơn.
- Ticket phản hồi qua server push; không thêm chat tự do vì tăng nghiệp vụ mà không giải quyết khoảng trống chính.

### U4: Món tạm hết và giá được kiểm tra đúng

- ADMIN sửa giá và bật/tắt “còn phục vụ” cho tám món hiện có. Không thêm quản lý kho nguyên liệu hay xóa món có lịch sử.
- Mỗi món có version. Đơn mang expectedVersion của các món; server kiểm version, tình trạng phục vụ và tự tính giá. Giá client gửi không quyết định giá thanh toán.
- Nếu đơn chưa được nhận mà menu đã thay đổi, trả MENU_CHANGED/ITEM_UNAVAILABLE và cho khách xem lại. Không âm thầm nhận đơn với giá mới.
- Nếu đơn đã commit trước thay đổi menu, tra receipt trả đúng outcome và giá đã lưu. Vì vậy kiểm receipt phải đúng thứ tự trước kiểm điều kiện nhận mới; không làm retry của đơn đã nhận bị lỗi do giá mới.
- Khi khách chấp nhận nội dung/giá mới, tạo ý định mới với ID mới; không sửa payload của ID cũ. Đối chiếu/bỏ ý định cũ trước để tránh hai ý định cùng có tác dụng chưa rõ.
- P1: lịch sử hóa đơn đã đóng cho ADMIN, phân trang theo ID, tổng tiền/giá thời điểm đặt giữ nguyên. Không đưa toàn bộ lịch sử vào snapshot realtime.

### Kiểm thử bắt buộc

Hai ADMIN chuyển cùng đơn, cập nhật menu cạnh tranh đặt món, đổi giá trong lúc mất ACK, receipt đã có trước khi món bị tắt, payload cũ chưa nhận, guest sửa giá/trạng thái bị từ chối, hóa đơn cũ không đổi. UI test dùng TCP/SQLite thật; screenshot MOCK chỉ dùng khi ghi nhãn rõ.

## 7. U5 – Tối ưu realtime vừa đủ, không sao chép FULL/DELTA

Chưa làm nếu U0 không quan sát được backlog/byte thừa hoặc P0 bị chậm. Với quy mô một quán, FULL/DELTA + base/epoch/resync tạo thêm nhiều trạng thái mà chưa chắc đem lại lợi ích tương xứng. Ưu tiên phương án đơn giản hơn:

- Mutation một bàn chỉ push đến ADMIN và guest liên quan; thay menu mới broadcast toàn quán. Phạm vi thay đổi do service xác định sau xử lý, không tin tableId do client tự khai.
- Mỗi peer tối đa một snapshot đang chờ; trạng thái mới có thể thay snapshot chưa gửi. Không bỏ RESPONSE, receipt outcome hoặc thông báo auth. Trạng thái cuối đầy đủ là dữ liệu có thể gộp; kết quả từng lệnh là dữ liệu phải giữ.
- Không cố thu hồi byte đã ghi vào TCP. Coalescing chỉ áp dụng phần còn trong bộ nhớ ứng dụng; peer quá chậm vẫn có giới hạn và bị ngắt riêng.
- Namespace theo lần chạy server và số thứ tự view/push giúp client loại callback/trạng thái cũ, kể cả presence thay đổi mà business revision không tăng. GET_STATE phải dùng cùng quy tắc phiên bản, không đè push mới bằng response cũ.
- Lịch sử phân trang riêng; full snapshot vẫn có giới hạn byte và phạm vi dữ liệu công bố rõ. Thử frame lớn và client đọc chậm trước khi nói hệ thống chịu tải.

Đối chứng U5 dùng cùng auth/recovery/dataset; thay duy nhất broadcast/coalescing. Đo byte frame, queue depth, disconnect chậm và độ trễ hội tụ trạng thái. Không quy giảm byte nhờ phạm vi nhỏ hơn thành phát minh thuật toán delta.

## 8. U6 – Thực nghiệm có thể dùng để bảo vệ

### 8.1. Ma trận đối chứng

| Mã | Nội dung | Câu hỏi |
|---|---|---|
| R0 – REPLAY_ALL | Receipt + guard + outbox, phát lại mọi ý định chưa rõ | Retry chung giải quyết và bỏ sót điều gì? |
| R1 – REVIEW | Receipt + guard + outbox, ý định chưa nhận chờ xác nhận như tuần 2 | Chỉ lookup/xác nhận khác gì với kết thúc nguyên tử lời gọi? |
| R2 – SEMANTIC | R1 + policy U2 | Tránh lời gọi đến muộn được đến đâu, chi phí gì? |
| J0/J1 | Journal RAM so với journal đĩa trong fixture riêng, còn lại giống nhau | Ý định còn hay mất khi JVM khách khởi động lại? |
| G0/G1 | Fixture có/không guard lượt, không đưa mode yếu vào server demo | Tác dụng riêng của ràng buộc lượt là gì? |
| P0/P1, nếu U5 làm | Broadcast hiện tại so với scoped/coalesced push | Có giảm byte/backlog mà vẫn hội tụ đúng không? |

Không chạy tích Descartes mọi mode. R0–R2 là nhóm chính; J/G là các ca cơ chế ngắn; P chỉ chạy nếu thực sự có U5. Không đổi UI/DB workload giữa các baseline hoặc dùng auth yếu để làm bản đề xuất trông nhanh hơn.

### 8.2. Kịch bản chính

- Workload bình thường: 1/5/10/20 guest trên sáu bàn và một ADMIN, request rate được cấu hình rõ, seed/dataset cố định. Trần 32 connection hiện tại không phải kết quả tải đã đạt.
- Mất kết nối trước tiếp nhận, sau commit/trước ACK, sau lookup chưa thấy receipt và handler cũ còn chờ.
- Mất mạng 2/10/60 giây; nếu vượt ngân sách reconnect thì phải ghi nhận chuyển sang retry chủ động, không coi là auto phục hồi thành công.
- Đóng/mở bàn khi client offline; token sai/bị thu hồi; đổi giá/tạm hết món khi còn ý định chờ.
- Kill JVM khách do fixture tạo, restart server cùng DB; client đọc chậm/frame sai/đạt giới hạn queue.

Dùng script tạo lỗi ở tầng ứng dụng và ghi nhãn SIMULATED; không gọi đó là đo packet loss vật lý. LAN thật chạy riêng trên ít nhất hai máy Windows nếu nhóm có thiết bị. Việc triển khai tự động vẫn có thể tiếp tục trước khi nhóm bố trí máy; mục LAN giữ NOT RUN đến khi chạy thật.

### 8.3. Chỉ số

| Chỉ số | Cách dùng |
|---|---|
| Đơn trùng, tác dụng sai lượt, lời gọi bị tạo sau khi đã bỏ thành công | Đối chiếu DB/log độc lập UI; mục tiêu không có vi phạm trong workload đã công bố |
| Yêu cầu phục hồi đúng, còn chưa rõ, bị từ chối hoặc cần khách thao tác | Báo tất cả trạng thái; không giấu lỗi/timeout khỏi mẫu |
| Latency request median/p95; throughput; error/timeout rate | Đo riêng từng action, tải, lần chạy; không dùng thời gian suite |
| Recovery time | Báo cả từ bắt đầu outage và từ server sẵn sàng trở lại; chỉ có thời điểm chắc chắn trong fixture thì mới dùng |
| Byte frame và queue depth | Byte ứng dụng khác byte Ethernet; ghi rõ vị trí đo |
| Xác nhận lại/gọi lại, request phụ, receipt/journal storage | Thể hiện chi phí và trade-off, không chỉ số lỗi được tránh |
| Cleanup và tài nguyên | Reader/heartbeat/worker sau stop, reconnect nhiều lần; RSS/CPU nếu lấy được đáng tin cậy |

Kế hoạch khởi điểm: workload đo 60 giây sau warm-up 10 giây, năm lần lặp mỗi cấu hình quan trọng; tốc độ mutation và dataset có giới hạn để không vô tình biến một lượt bàn thành kho lịch sử vô hạn. Công bố request count thực tế; tăng thời lượng khi mẫu p95 quá ít. Fault/race chính tối thiểu 20 lần lặp với lịch có seed; test correctness hai thứ tự thắng phải có trước campaign. Ngưỡng latency/load cuối chốt sau U0 theo máy thật, không sửa ngưỡng hoặc loại ca thất bại để tạo PASS đẹp.

Chạy R0–R2 cùng lịch lỗi, xen kẽ thứ tự để giảm ảnh hưởng warm-up. Báo theo từng run, median/p95 và độ phân tán; không gộp latency lỗi thành latency thành công. Không đưa CI runner và máy LAN vào cùng bảng như cùng môi trường. Đo trên máy thật không nhất thiết có cải thiện; kết quả không cải thiện cũng phải phân tích.

### 8.4. Artifact mỗi lần chạy

`manifest.json`, `environment.json`, `config.json`, raw CSV/JSONL, summary, log server/client đã lọc bí mật và biểu đồ. Mỗi biểu đồ truy được về raw data và công thức. Bản báo cáo phân biệt kiểm thử chức năng, fault mô phỏng, benchmark và nghiệm thu LAN. Source ID/hash gắn với package, không lấy artifact tuần 2 làm bằng chứng tính năng mới.

## 9. CI, đóng gói và dữ liệu demo

- CI Maven chạy trên Windows, có job Java 17 và JDK bản đóng gói được pin rõ; nếu không đủ chi phí thì Java 17 bắt buộc, môi trường đóng gói xác minh local riêng. Core/network test là gate, GUI test chạy ở môi trường có desktop và báo số skip thật. Có artifact report; không chỉ một badge xanh.
- Giữ script build/smoke hiện tại; thêm recovery regression U1/U2, kiểm migration schema cũ. CI local chưa publish chỉ được gọi workflow đã chuẩn bị, không ghi CI online PASS.
- Dùng `jpackage --type app-image` trên Windows để đóng runtime cùng client/server launcher, phát hành ZIP mở chạy được. JDK hiện có `jpackage`. Không yêu cầu phải làm MSI, ký số hoặc auto-update để giống peer; app-image đã giải quyết cài Java trên máy demo [1].
- Config host/port hiển thị dễ sửa. DB và journal nằm trong thư mục người dùng có quyền ghi, không phụ thuộc thư mục cài đặt; đường dẫn Unicode được kiểm tra.
- Không đóng gói mật khẩu thật hoặc journal của phiên cá nhân. Tạo dataset demo độc lập, không reset DB người dùng để làm demo.
- Kiểm launch máy thứ hai không có Java trong PATH; nếu chưa có máy thì ghi chưa kiểm. Chuẩn bị hướng dẫn firewall để nhóm thao tác; không tự đổi firewall toàn máy.
- Hướng CI dựa vào workflow Maven chính thức và upload artifact [2]; không biến số test của peer thành yêu cầu phải đạt.

## 10. Lịch 21–31/10 và điểm cắt phạm vi

| Ngày | Công việc chính | Điều kiện rời mốc |
|---|---|---|
| 21/10 | U0, chốt wire/schema/auth contract; bắt đầu U1 | Mốc đo hiện tại được lưu; có test tình huống U1 và migration |
| 22/10 | Hoàn thành JOIN/RESUME/revoke/reconnect U1 | Không bypass bằng mật khẩu guest cũ; resume/closed visit/worker cleanup đạt |
| 23/10 | U2 và đối chứng R0/R1/R2 | Hai thứ tự commit/discard đều đúng; mất ACK discard không bị coi đã bỏ |
| 24/10 | U3 dashboard/pha chế/phục hồi | GUI qua TCP thật; thao tác quán/khách rõ; không số MOCK trong demo |
| 25/10 | U4 menu/version; U4b nếu còn thời gian | Race giá/món hết/replay receipt đúng; dữ liệu giá cũ giữ nguyên |
| 26/10 | Tích hợp, CI, chạy đo thử; U5 nếu đủ điều kiện | P0 regression đạt; chỉ làm U5 khi có số đo và thời gian dự phòng |
| 27/10 | Đóng tính năng, kiểm migration/restart/giới hạn tài nguyên | Artifact code được đóng mốc; không thêm nhóm nghiệp vụ mới |
| 28/10 | Campaign U6 và app-image | Raw data đầy đủ, lỗi được giữ, package có manifest |
| 29/10 | LAN hai máy, demo đóng gói, sửa lỗi tái lập | Bảng LAN có bước/kết quả/ảnh/log; không tự nâng NOT RUN |
| 30/10 | Báo cáo, biểu đồ, diễn tập giải thích/sửa mã | Nội dung khớp source/package, mỗi thành viên hiểu luồng trọng yếu |
| 31/10 | Dự phòng, kiểm cuối, Compilatio và nộp trước 23:59 | Không phát triển tính năng mới, nộp đúng tên/file/source chạy được |

Thứ tự phụ thuộc: U0 → U1 → U2; U3/U4 dùng contract đã ổn định; U5 sau đo; U6 xuyên suốt và chốt cuối. Nếu nhiều thành viên, có thể tách recorder/UI/CI sau khi thống nhất contract, nhưng không giả định nhân sự chưa được nhóm phân công.

**Điểm cắt:** chậm một ngày thì bỏ U4b/U5 trước; chậm hai ngày thì dashboard chỉ giữ view vận hành chính và menu tạm hết/giá, không thêm lịch sử. Không cắt correctness receipt/guard, kiểm thử migration, bằng chứng thực nghiệm hoặc thời gian làm báo cáo để giữ một tính năng P1. Nếu U1 hoặc U2 có lỗi nghiêm trọng ở mốc 27/10, cô lập thay đổi chưa ổn định và giữ bản chạy được đã kiểm chứng; cập nhật claim theo bản thực nộp, không che lỗi để đạt lịch.

## 11. Checklist nghiệm thu đợt nâng cấp

- [ ] Guest không xin quyền lượt mới chỉ bằng mật khẩu bàn cũ.
- [ ] Reconnect/resume không lưu password, có giới hạn và dừng khi quyền bị thu hồi.
- [ ] Không nhân worker/reader qua reconnect; callback cũ không ghi đè view mới.
- [ ] Đơn đã nhận lấy lại outcome; đơn chưa nhận còn nguyên ý định để khách quyết định.
- [ ] Lời gọi chưa nhận được kết thúc nguyên tử khi phục hồi; đã nhận thì giữ đúng ticket.
- [ ] Đổi bàn/lượt không chuyển outbox cũ; receipt cũ được đọc đúng quyền còn hiệu lực.
- [ ] Thay đổi giá/món hết không làm retry đơn đã commit bị sai hoặc đổi hóa đơn cũ.
- [ ] Dashboard/pha chế/guest được kiểm qua network/database thật.
- [ ] R0–R2 có raw data và so sánh lợi ích/chi phí, không chỉ số test.
- [ ] Package khởi động lại và resume từ journal đúng; có kết quả LAN thật hoặc nhãn NOT RUN rõ ràng.
- [ ] Báo cáo/Word/README/protocol và artifact cùng phiên bản; thành viên giải thích được code.

Đạt các mục này giúp CafeLink có chiều sâu tương đương ở các năng lực cốt lõi của môn học, dù ít nghiệp vụ hơn TOEIC. Đây là tiêu chí kỹ thuật nội bộ của kế hoạch, không phải dự đoán điểm hay thay quyết định của giảng viên.

## 12. Những phần không đưa vào phạm vi bản nộp

Không microservices/Kafka/Redis, không đổi sang Spring/PostgreSQL/JavaFX, không FULL/DELTA/resync chỉ để có tên giống peer, không thanh toán thật, kho nguyên liệu, voucher, ML, nhiều chi nhánh hoặc chat tự do. Không viết hủy/sửa món đã vào pha chế: đó là quy trình mới có nhiều cạnh tranh trạng thái.

Web/QR có ích khi chuyển sản phẩm sang điện thoại nhưng làm phát sinh giao diện/transport thứ hai; để sau bản nộp. TLS là nâng cấp phù hợp nếu triển khai mạng không tin cậy, nhưng không dùng một chứng chỉ demo để claim an toàn production; trong lịch này vẫn công khai phạm vi LAN có kiểm soát. Chỉ thêm các phần ngoài kế hoạch khi nhóm đã hoàn tất gate P0 và còn thời gian kiểm chứng riêng.

## 13. Tài liệu và nguồn

- [Yêu cầu học phần](../final-project/Instruction.md), [hạn và cách nộp](../final-project/Submission.md).
- [Bàn giao CafeLink tuần 2](CafeLink_Week2_Handoff.md), [so sánh peer](CafeLink_vs_Toeic_Monitoring.md), [kiểm tra evidence peer](CafeLink_Toeic_Evidence_Review.md).
- [ADR-003: phương án nâng cấp đề xuất](../cafelink-system/docs/architecture/ADR-003-upgrade-scope.md). ADR-002 tiếp tục mô tả implementation hiện tại cho đến khi nâng cấp được thực hiện.
- [1] Oracle Java 24, [Packaging Overview](https://docs.oracle.com/en/java/javase/24/jpackage/packaging-overview.html): app-image và bundled runtime; đóng gói trên nền tảng đích. Đối chiếu ngày 20/10/2026.
- [2] GitHub Docs, [Building and testing Java with Maven](https://docs.github.com/en/actions/tutorials/build-and-test-code/java-with-maven): workflow Maven và artifact. Đối chiếu ngày 20/10/2026.
