"""Update delivery status after campaign audit and extracted-source validation."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "report"
EVIDENCE = REPORT / "evidence/cafelink-original"


def main():
    data = json.loads((EVIDENCE / "summary.json").read_text(encoding="utf-8"))
    validation = json.loads((EVIDENCE / "package-validation.json").read_text(encoding="utf-8"))
    if data["status"] != "PASS" or validation["status"] != "PASS" or validation["rebuiltSourceTests"] != data["tests"]:
        raise ValueError("Campaign audit and identical passing extracted-source tests required")
    count = data["tests"]["tests"]
    stats = f"{count}/{count} test Java (0 failures/errors/skipped), 3 test bộ phân tích Python, {data['recoveryCases']}/{data['recoveryCases']} ca phục hồi, {data['benchmarkCases']}/{data['benchmarkCases']} lần đo tải với {data['requests']:,} request và {data['errors']} lỗi"
    table = ["| Guest | Tổng request | Lỗi | Request/s TB | p50 (ms) | p95 (ms) | Nhận TB (MiB) |", "|---|---:|---:|---:|---:|---:|---:|"]
    for row in data["load"]:
        table.append(f"| {row['clients']} | {row['requests']} | {row['errors']} | {row['meanCompletedRps']:.2f} | {row['p50_ms']:.2f} | {row['p95_ms']:.2f} | {row['meanReceivedKiB']/1024:.2f} |")
    table_text = "\n".join(table)
    handoff = f"""# Bàn giao CafeLink bản gốc trước nâng cấp

**Đã hoàn tất các phần kỹ thuật có thể kiểm chứng trên một máy của bản gốc tuần 1–3.** Kết quả: {stats}. Source giải nén được build/test lại; smoke từ JAR giữ đúng dữ liệu qua restart và khôi phục mất ACK. Chưa triển khai U1–U5.

## Tài liệu và bản chạy

- [Báo cáo dự án](CafeLink_Project_Report.md), [Word tương ứng](CafeLink_Project_Report_Draft.docx).
- ZIP baseline: `dist/CafeLink-Original-1.0.0-Baseline.zip`, gồm source/test/docs, JAR + dependency, báo cáo/evidence, BASELINE.json và SHA256-MANIFEST.csv. Khi đọc từ bản giải nén, thư mục chứa START-HERE.md chính là nội dung ZIP này. Cần JDK, không cần build chỉ để chạy.
- [Tổng hợp evidence](evidence/cafelink-original/summary.json), [raw và chỉ số](evidence/cafelink-original/RESULTS.md), [truy vết yêu cầu](CafeLink_Requirements_Traceability.md).
- [Kiểm chạy bản giải nén và build source](evidence/cafelink-original/package-validation.json). Hash ZIP cuối và lần kiểm runtime của ZIP cuối lưu ngoài archive tại `report/evidence/cafelink-original-release/` để tránh hash tự tham chiếu.

## Kết quả đo thực tế

{table_text}

Mỗi mức tải năm lần, 10 giây warmup + 60 giây đo, một request/giây/guest; 20% đặt món và 80% GET_STATE. Server/client ở hai JVM riêng trên loopback. p50/p95 nearest-rank gộp mẫu; từng lần giữ riêng trong [benchmark-runs.csv](evidence/cafelink-original/benchmark-runs.csv). Không xem request/s lịch cố định là công suất tối đa. Traffic là byte ứng dụng guest, gồm frame/event/heartbeat, không gồm admin/TCP/IP.

Gói chạy có vá đọc đồng thời hai pipe trong bước dò JDK trước khởi động; JAR, JVM thực thi và đường xử lý request đã đo giữ nguyên. [Hồ sơ startup patch](evidence/cafelink-original/launcher-startup-patch.json) giữ mã/hash khi đo và diff tới launcher đóng gói. Không đo startup latency; khởi chạy gói sau vá được smoke/build riêng.

180 ca phục hồi gồm hai policy × sáu kịch bản × khoảng offline 2/10/60 giây × năm lần. REVIEW giữ 15 đơn chưa nhận và 15 lời gọi chưa nhận chờ khách xác nhận; REPLAY_ALL tự gửi lại. Riêng lời gọi chưa nhận, REVIEW tạo 0 ticket trước xác nhận mới, REPLAY_ALL tạo 15. Cả hai dùng receipt/idempotency/guard lượt, không ghi nhận đơn trùng hoặc tác dụng sai lượt trong các ca. Không quy toàn bộ hiệu quả chống trùng cho REVIEW; chưa chứng minh nhu cầu thực sự đã hết hoặc policy mới nhanh hơn.

## Các bước đã kiểm thử và báo cáo

| Mốc | Kết quả | Báo cáo |
|---|---|---|
| W3.1 | 59 test Java, thêm ca tài nguyên/ACK/lock/byte | [Part 1](CafeLink_W3_Part1_Report.md) |
| W3.2 | 20 lần đo tải; CSV request, latency/traffic/storage, oracle DB | [Part 2](CafeLink_W3_Part2_Report.md) |
| W3.3 | 180 ca fault/offline, seed và ma trận đối chứng đầy đủ | [Part 3](CafeLink_W3_Part3_Report.md) |
| W3.4 | Manifest, tamper rejection, probe, smoke và build source ở đường dẫn mới ASCII có khoảng trắng | [Part 4](CafeLink_W3_Part4_Report.md) |
| W3.5 | Báo cáo/Word, biểu đồ, local references và truy vết | [Part 5](CafeLink_W3_Part5_Report.md) |

## Chạy bản đóng gói

Giải nén ZIP, vào `cafelink-system`:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/verify-package.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/demo.ps1
```

Admin/CafeLink@123; ban1/Ban1@123, ban2/Ban2@123, ban3/Ban3@123. Chủ quán mở bàn trước khi khách đặt. TCP demo chưa mã hóa; không dùng mật khẩu thật. [README](../cafelink-system/README.md) có build/run riêng, IP/cổng và schema. Không chia sẻ journal sinh ra tại data/client-state vì chứa credential.

Tái chạy phép đo từ source:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/recovery-experiment.ps1 -Repetitions 5 -OfflineSeconds '2,10,60' -Parallelism 6
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/benchmark.ps1 -ClientCounts '1,5,10,20' -Repetitions 5 -DurationSeconds 60 -WarmupSeconds 10
```

Chạy nối tiếp, không rebuild trong campaign. Analyzer cần Python + matplotlib; chạy `--help` để truyền thư mục benchmark/recovery/Surefire/output mới. ZIP giữ baseline có hash để so nâng cấp; các lần chạy mới tạo thư mục mới.

## Phần còn cần điều kiện bên ngoài

- **LAN vật lý hai máy NOT RUN:** hiện chỉ có một máy, đã có [runbook và checklist](../cafelink-system/docs/LAN_ACCEPTANCE.md). Probe localhost không thay LAN.
- **Bìa/thành viên/phân công:** hoãn theo yêu cầu người dùng, không tự bịa dữ liệu. Chưa đổi tên báo cáo theo số nhóm thật.
- **Compilatio/nộp chính thức và xem bố cục Word:** chưa có bằng chứng; cần hoàn tất trước nộp. Word hiện đã kiểm cấu trúc/nội dung/link/ảnh, chưa coi đó là duyệt bố cục trực quan.

Không diễn giải bộ test thành 100% độ phủ dòng mã hoặc không còn mọi lỗi. Chưa chạy runtime JDK17 riêng (đã dùng JDK24.0.2), chưa thử mất điện, Wi-Fi thực, soak dài hạn hoặc khảo sát người dùng quán.

Launcher cần thư mục ASCII, cho phép khoảng trắng. Probe thư mục tiếng Việt **không đạt** trên JDK24/Windows Cp1252, đã giữ log và ghi điều kiện cài đặt trong README; chưa sửa hỗ trợ tên thư mục có dấu. Nội dung message vẫn UTF-8.

## Bắt đầu nâng cấp từ baseline này

[Upgrade Plan](CafeLink_Upgrade_Plan.md) giữ nguyên các gói. Dùng JAR/hash/dataset hiện tại làm E0, không làm lại công cụ đo từ đầu. Ưu tiên U1 quyền vào bàn/resume và U2 phân biệt phục hồi thật sự theo loại; U3/U4 tăng giá trị vận hành. Dữ liệu byte của baseline giúp quyết định U5 giảm snapshot thừa. U6 vẫn còn CI/app-image và nghiệm thu LAN của bản nâng cấp; không coi các bước đó đã xong từ kết quả bản gốc.
"""
    (REPORT / "CafeLink_Original_Handoff.md").write_text(handoff, encoding="utf-8")
    main_report = REPORT / "CafeLink_Project_Report.md"
    report_text = main_report.read_text(encoding="utf-8")
    report_text = report_text.replace("### 9.3. Đối chứng chức năng tuần 2", f"Kiểm chạy bản đóng gói gốc mới ở đường dẫn sạch ASCII có khoảng trắng xác nhận lại cả hai smoke trên JAR đã đo tải, phát hiện file bị sửa và build source giải nén đạt {count} test không skip. [Biên bản máy đọc được](evidence/cafelink-original/package-validation.json). Đây là thư mục sạch trên cùng OS/JDK, không phải máy Windows mới; build dùng dependency cache hiện có.\n\n### 9.3. Đối chứng chức năng tuần 2", 1)
    report_text = report_text.replace("## 8. Thiết lập kiểm thử và thực nghiệm", "Bản gốc có JAR/dependency/source/test và báo cáo trong ZIP baseline; `scripts/package-original.ps1` đối chiếu JAR hash với campaign, `verify-package.ps1` kiểm manifest trước sử dụng. Kiểm chạy source và runtime từ đường dẫn mới ASCII có khoảng trắng được ghi tại mục 9.2.\n\n## 8. Thiết lập kiểm thử và thực nghiệm", 1)
    main_report.write_text(report_text, encoding="utf-8")
    completion = REPORT / "CafeLink_Original_Completion.md"
    text = completion.read_text(encoding="utf-8")
    text = text.replace("Đang chạy 20 lần đo, 60 giây/lần sau 10 giây warmup", "Đạt 20/20 lần đo; raw data, biểu đồ và oracle đã lưu")
    text = text.replace("Đạt 180/180 ca; chờ oracle tổng hợp cuối", "Đạt 180/180 ca; oracle SQLite độc lập đạt")
    text = text.replace("| W3.4 | Đóng gói bản gốc, manifest, kiểm chạy từ thư mục sạch, bộ LAN | Chưa chạy |", "| W3.4 | Đóng gói bản gốc, manifest, kiểm chạy từ thư mục sạch, bộ LAN | Đạt trên một máy; LAN hai máy NOT RUN |")
    text = text.replace("| W3.5 | Raw data, biểu đồ, báo cáo/Word, ma trận truy vết và bàn giao | Đang làm |", "| W3.5 | Raw data, biểu đồ, báo cáo/Word, ma trận truy vết và bàn giao | Hoàn tất nội dung kỹ thuật; bìa/nộp/duyệt Word trực quan còn bên ngoài |")
    completion.write_text(text + f"\n- Nghiệm thu bản gốc: {stats}. Xem [bàn giao cuối](CafeLink_Original_Handoff.md), evidence và giới hạn cụ thể.\n", encoding="utf-8")
    part2 = REPORT / "CafeLink_W3_Part2_Report.md"
    text = part2.read_text(encoding="utf-8")
    text = text.replace("**Campaign đang chạy**; kết quả cuối chỉ lấy khi `campaign-summary.json` là PASS và analyzer độc lập đối chiếu đủ case.", f"**PASS 20/20 lần; {data['requests']:,} request, {data['errors']} lỗi.** Analyzer đối chiếu đủ matrix/raw/SQLite và tổng tiền từng lần.")
    part2.write_text(text + "\n## Kết quả sau đối chiếu\n\n" + table_text + "\n\n[Raw data và biểu đồ](evidence/cafelink-original/RESULTS.md), [oracle SQLite](evidence/cafelink-original/database-oracle.csv). Bảng không phải công suất tối đa hoặc đo LAN.\n", encoding="utf-8")
    part3 = REPORT / "CafeLink_W3_Part3_Report.md"
    text = part3.read_text(encoding="utf-8").replace("Dữ liệu đọc độc lập và oracle SQLite sẽ được lưu vào", "Analyzer đã kiểm đủ matrix và SQLite read-only cho 180 ca; dữ liệu đọc độc lập và oracle đã lưu vào")
    part3.write_text(text, encoding="utf-8")
    part4 = REPORT / "CafeLink_W3_Part4_Report.md"
    text = part4.read_text(encoding="utf-8").split("## Kết quả kiểm chạy")[0]
    text += f"""## Kết quả kiểm chạy

**PASS.** Giải nén ở đường dẫn ASCII có khoảng trắng, manifest đúng, README sửa bị từ chối rồi khôi phục đúng; probe cổng mở PASS và cổng đóng bị từ chối như mong đợi. Smoke thường giữ ba đơn/190.000 VND/một ticket HANDLED qua restart; recovery smoke giữ một đơn/30.000 VND, journal PENDING→RESOLVED qua JVM mới.

Build source trong thư mục giải nén đạt **{count} tests, 0 failures/errors/skipped**. Dùng cùng Windows/JDK24 và cache dependency trên máy, không claim môi trường OS sạch hoặc build offline. [Kết quả máy đọc được](evidence/cafelink-original/package-validation.json); log sạch của source build và smoke lưu kèm evidence.

ZIP cuối cùng có cùng JAR/source nhưng báo cáo được cập nhật sau kiểm chứng candidate. ZIP cuối được kiểm lại manifest/probe/smoke; release record ngoài archive ở `evidence/cafelink-original-release/` ghi hash chính ZIP cuối và kết quả thực tế. Không ghi hash ZIP vào chính file bên trong ZIP.
"""
    part4.write_text(text, encoding="utf-8")
    correction = REPORT / "CafeLink_Launcher_Correction.md"
    text = correction.read_text(encoding="utf-8").replace("Đang chạy lại đủ 20 lần", "Đã chạy lại và nghiệm thu đủ 20 lần")
    text += "\nKết quả cuối có 20/20 listenerClosed=True, đủ 10.800 request và oracle SQLite đạt; xem `evidence/cafelink-original/` và bàn giao bản gốc.\n"
    correction.write_text(text, encoding="utf-8")
    readme = ROOT / "cafelink-system/README.md"
    text = readme.read_text(encoding="utf-8")
    lines = text.splitlines()
    lines[2] = f"Cập nhật bản gốc: **{count} test Java đạt, 180 ca phục hồi đạt và 20 lần đo tải đạt ({data['requests']:,} request, {data['errors']} lỗi)**. Có raw data, biểu đồ, oracle SQLite và bản đóng gói kiểm chạy từ đường dẫn sạch. Xem [bàn giao](../report/CafeLink_Original_Handoff.md), [số liệu](../report/evidence/cafelink-original/RESULTS.md). LAN vật lý hai máy chưa chạy vì chỉ có một máy. U1–U5 vẫn là kế hoạch."
    readme.write_text("\n".join(lines) + "\n", encoding="utf-8")
    plan = REPORT / "CafeLink_Implementation_Plan.md"
    text = plan.read_text(encoding="utf-8")
    begin, end = text.index("**Cập nhật"), text.index("**Kế hoạch nâng cấp")
    text = text[:begin] + f"**Cập nhật bản gốc:** W1/W2 hoàn thành; W3 đã đo và kiểm chạy trên một máy: {stats}. Xem [bản gốc](CafeLink_Original_Handoff.md), [truy vết](CafeLink_Requirements_Traceability.md). LAN hai máy NOT RUN, metadata nhóm hoãn theo người dùng; thủ tục nộp chưa thực hiện.\n\n" + text[end:]
    text = text.replace("chưa thay đổi trạng thái hoàn thành của mã tuần 2", "chưa triển khai tính năng U1–U5; dùng baseline gốc đã đóng gói làm E0")
    plan.write_text(text, encoding="utf-8")
    upgrade = REPORT / "CafeLink_Upgrade_Plan.md"
    text = upgrade.read_text(encoding="utf-8")
    text = text.replace("Giữ nguyên evidence tuần 2 làm mốc so sánh.", "Giữ evidence tuần 2 làm lịch sử; mốc E0 chính dùng bản gốc tuần 3 đã nghiệm thu và đóng gói.")
    marker = "## 1. Đích nâng cấp"
    note = f"**Mốc chuẩn bị sau kế hoạch:** đã hoàn tất bản gốc tuần 3 trên một máy: {stats}; [bàn giao/ZIP E0](CafeLink_Original_Handoff.md). Công cụ đo và baseline E0 của U0 đã có; chưa triển khai JOIN/resume/SEMANTIC/dashboard/menu/CI/app-image. Không chạy lại toàn bộ chuẩn bị E0 nếu source/JAR không thay đổi. LAN hai máy vẫn NOT RUN.\n\n"
    text = text.replace(marker, note + marker, 1)
    upgrade.write_text(text, encoding="utf-8")
    print("Handoff and stage reports updated from passing evidence and package validation.")


if __name__ == "__main__":
    main()
