# Công cụ báo cáo và kiểm chứng CafeLink

Ứng dụng CafeLink không cần Python để chạy. Các công cụ dưới đây dùng cho báo cáo/evidence, đã chạy với Python 3.13 trên Windows; dependency pin trong `requirements.txt` là phiên bản thực tế đã dùng.

Từ thư mục workspace/package root:

```powershell
python -m pip install -r report/tools/requirements.txt
python -m unittest discover -s report/tools -p test_analyze_cafelink_experiments.py -v
```

- `analyze_cafelink_experiments.py --help`: truyền thư mục benchmark/recovery/Surefire và output mới. Kiểm matrix/raw CSV/listener đã đóng, mở SQLite read-only đối chiếu dữ liệu, xuất CSV/JSON/PNG/SVG và hash. Không copy DB/outbox chứa credential vào evidence công khai. Chỉ phân tích sau khi campaign xong; không chạy đồng thời benchmark.
- `export_cafelink_report.py`: xuất Markdown thành DOCX, giữ bảng/ảnh và URL.
- `validate_cafelink_report.py --output <file.json>`: kiểm link/ảnh/nội dung đo/cấu trúc Word và tham khảo. Không thay người xem ngắt trang trong Word.
- `validate_cafelink_package.py --archive <zip> --output <thư-mục-mới>`: giải nén vào path ASCII có khoảng trắng, kiểm manifest/tamper/probe/smoke với listener đóng, rồi build source và chạy đầy đủ Java tests. Cần môi trường desktop để UI không skip. Không phải build trên OS sạch; bootstrap Maven có thể dùng Internet và cache dependency người dùng.
- `finalize_cafelink_original_report.py`, `finalize_cafelink_handoff.py`: các bước hoàn thiện tài liệu mốc bản gốc, chỉ dùng với cấu hình 1/5/10/20 guest, 5 lần × 60 giây, warmup 10 giây và 180 ca recovery 2/10/60 giây. Chúng cập nhật báo cáo theo evidence đã kiểm chứng; không dùng để ghi đè mốc gốc bằng số liệu bản nâng cấp.

`--skip-source-build` của package validator chỉ dùng để kiểm ZIP cuối khi có `--source-build-evidence` của candidate đã build đạt; validator bắt buộc source/test/scripts và JAR giống candidate. Gói ZIP cuối có record SHA-256 bên ngoài archive để tránh tự tham chiếu.

Giữ baseline/evidence gốc trước nâng cấp. Dữ liệu `cafelink-original-superseded` chỉ lưu lịch sử điều tra launcher, không dùng làm E0. [Đính chính](../CafeLink_Launcher_Correction.md) giải thích phạm vi dữ liệu được chấp nhận.
