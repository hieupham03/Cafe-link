# Kiến trúc CafeLink

Cập nhật tuần 2: [ADR-002 – Phục hồi và quyền theo lượt](architecture/ADR-002-recovery.md). Schema 3 có command_receipts/guest_credentials, client có Outbox. Các quyết định tuần 1 dưới đây là nền tảng; auth và retry đã được mở rộng như ADR-002 và PROTOCOL.

## Thành phần

`common`: DTO, Json, Message, FrameCodec, CLI Arguments. `server`: CafeServer quản lý sockets/connection identity; CafeService sở hữu business state và transaction; Database sở hữu SQLite connection/schema. `client`: NetworkClient quản lý RPC futures/server events; `client.ui` chịu trách nhiệm thao tác người dùng và render.

Database không được truy cập trực tiếp từ GUI hoặc client. Người dùng chủ quán cũng gửi lệnh qua TCP, nên workflow demo thật sự kiểm chứng giao tiếp mạng. Server console chỉ vận hành listener, ghi log và mở login quản trị.

## Quyết định kiến trúc

| Quyết định | Lý do | Đánh đổi |
|---|---|---|
| Java 17+, Swing | Sẵn JDK, GUI desktop dễ chạy nhiều cửa sổ, tập trung socket | Chưa web/mobile; kiểm tra desktop/DPI cần riêng |
| Maven project, 3 nhóm package | Build đơn giản trong 3 tuần; entrypoint client/server riêng | Chưa tách deployment thành nhiều module |
| TCP + length-prefix JSON | Nhìn được format/protocol; xử lý partial reads rõ; không native deserialization | Phải tự quản lý framing/RPC/events/timeouts; TCP chưa TLS |
| SQLite + lock CafeService | Dữ liệu nhỏ; transaction và persistence chạy không cần DB service | Ghi nghiệp vụ tuần tự; không tuyên bố scale nhiều quán |
| Bounded readers, per-peer writer queue | Hạn chế tài nguyên; client chậm không giữ lock DB khi ghi socket | Mỗi peer có hai thread; snapshot gửi full state có overhead |
| Giá nguyên VND, lưu giá ở order_items | Tổng chính xác, giữ giá lúc đặt, bỏ client price | Phạm vi chưa hỗ trợ nhiều tiền tệ/thuế/khuyến mãi |
| Auth connection + credential theo lượt | Vai trò/bàn do server quyết định, quyền resume không đổi lượt | Shared table password vẫn là mô hình terminal demo |
| Receipt + outbox, không tự retry trong GUI | Timeout không chứng minh server chưa commit | Người dùng đăng nhập lại, lookup và xác nhận ý định chưa nhận |

## Đồng thời và transaction

Các public operation CafeService synchronized trên một SQLite connection. Việc kiểm tra role, active visit, trạng thái đơn, insert/update và revision nằm trong cùng transaction. OPEN_TABLE được unique partial index bảo vệ một active visit/bàn. PAY_AND_CLOSE ghi payment unique visit và đóng phiên cùng transaction; chỉ khi mọi đơn SERVED và không ticket OPEN.

Snapshot đọc dưới cùng lock và không đưa connection/socket vào model. Sau service operation kết thúc, network enqueue response rồi publish state. Socket writer không có quyền truy cập DB. Queue full kết thúc peer chậm; invalid frame chỉ kết thúc peer đó.

Client có một reader, request threads đợi future theo request ID. Listener UI chỉ enqueue công việc vào Swing EDT; không block reader bằng I/O hoặc popup. GUI network actions chạy SwingWorker, giữ state trên EDT. Snapshot revision cũ hơn không được áp dụng; online presence không là business state.

## Giới hạn có chủ đích

Snapshot đầy đủ có giới hạn frame 256 KiB; một phiên quán nhỏ là mục tiêu. Số order/ticket trong phiên chưa có phân trang, receipt chưa GC. Có ledger/outbox, chưa partial event replay. Thread cap không thay thế kiểm thử workload LAN thực tế. Ngắt server có thể làm outcome chưa rõ; client chỉ xác nhận sau response hoặc tra receipt. Journal atomic replace không phải bằng chứng chống mọi sự cố mất điện; secret credential chưa mã hóa at rest.

## Công cụ kiểm chứng bản gốc

`BenchmarkClientMain` chỉ là workload client, không là lớp server thay thế. Launcher `benchmark.ps1` chạy ServerMain và workload ở hai JVM riêng, mỗi lần DB mới; đo 1/5/10/20 guest với lịch cố định. `NetworkClient.Traffic` đếm byte ứng dụng qua stream, gồm header frame; không thay packet capture TCP/IP.

`RecoveryExperimentMain` dựng fixture server/client socket thật cho từng ca, chèn lỗi trước handler hoặc sau commit, đóng guest và chờ offline rồi khôi phục từ journal. Các fixture độc lập có thể chạy song song để kiểm tính đúng; timing của chúng không phải benchmark latency giữa policy.

Analyzer Python ngoài ứng dụng đọc CSV và SQLite read-only để đối chiếu integrity, foreign key, số đơn/ticket/receipt và tổng tiền. File journal chứa credential không được copy vào evidence công khai. Công cụ đo, source/test, JAR và dependency được đóng gói với manifest SHA-256 để giữ baseline so sánh nâng cấp. Xem [LAN acceptance](LAN_ACCEPTANCE.md) cho phần cần máy thứ hai.
