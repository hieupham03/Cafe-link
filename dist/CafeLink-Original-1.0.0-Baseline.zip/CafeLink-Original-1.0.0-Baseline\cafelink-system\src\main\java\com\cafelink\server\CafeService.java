package com.cafelink.server;

import com.cafelink.common.Models.*;
import com.cafelink.common.Json;
import com.cafelink.common.Commands;
import com.google.gson.*;
import java.nio.file.Path;
import java.sql.SQLException;
import java.time.Instant;
import java.util.*;

/** Database and business state are serialized here; socket I/O never holds this lock. */
public final class CafeService implements AutoCloseable {
    private final Database db;
    public CafeService(Path path) throws Exception { db = new Database(path); }
    public synchronized Identity authenticate(String username, String password) throws SQLException {
        return authenticate(username, password, "");
    }
    public synchronized Identity authenticate(String username, String password, String credential) throws SQLException {
        if (username == null || password == null || username.length() > 60 || password.length() > 128)
            throw problem("AUTH_FAILED", "Sai tài khoản hoặc mật khẩu.");
        record Account(String hash, Identity identity) { }
        List<Account> found = db.query("SELECT * FROM accounts WHERE username=?", r -> new Account(r.getString("password_hash"),
                new Identity(username, r.getString("role"), r.getObject("table_id") == null ? null : r.getInt("table_id"), null)), username);
        if (found.isEmpty() || !PasswordHash.verify(password, found.get(0).hash())) throw problem("AUTH_FAILED", "Sai tài khoản hoặc mật khẩu.");
        Identity account = found.get(0).identity();
        if (admin(account)) return account;
        String token = credential;
        if (token == null || token.isEmpty()) {
            token = UUID.randomUUID().toString() + UUID.randomUUID();
            List<String> visits = db.query("SELECT id FROM visits WHERE table_id=? AND active=1", r -> r.getString(1), account.tableId());
            db.update("INSERT INTO guest_credentials VALUES(?,?,?,?)", Commands.digest(token), username, visits.isEmpty() ? null : visits.get(0), Instant.now().toString());
        } else if (token.length() > 160 || db.query("SELECT token_hash FROM guest_credentials WHERE token_hash=? AND username=?", r -> r.getString(1), Commands.digest(token), username).isEmpty()) {
            throw problem("INVALID_CREDENTIAL", "Không thể phục hồi quyền của lượt khách. Không tự chuyển sang lượt mới.");
        }
        return new Identity(username, account.role(), account.tableId(), token);
    }
    public synchronized Snapshot snapshot(Identity who, Map<Integer, Integer> online) throws SQLException {
        if (who == null) throw problem("UNAUTHENTICATED", "Vui lòng đăng nhập.");
        String allowed = admin(who) ? null : guestVisit(who);
        List<MenuItem> menu = db.query("SELECT * FROM menu ORDER BY id", r -> new MenuItem(r.getInt("id"), r.getString("name"), r.getLong("price_vnd"), r.getString("category")));
        String filter = admin(who) ? "" : " WHERE t.id=?";
        Object[] tableArgs = admin(who) ? new Object[0] : new Object[]{allowed, who.tableId()};
        List<TableView> tables = db.query("SELECT t.id,t.name,v.id visit_id FROM cafe_tables t LEFT JOIN visits v ON v.table_id=t.id AND v.active=1" + (admin(who) ? "" : " AND v.id=?") + filter + " ORDER BY t.id",
                r -> new TableView(r.getInt("id"), r.getString("name"), r.getString("visit_id"), r.getString("visit_id") == null ? (allowed == null ? "AVAILABLE" : "SESSION_ENDED") : "OCCUPIED", online.getOrDefault(r.getInt("id"), 0)), tableArgs);
        String scope = admin(who) ? "v.active=1" : "v.active=1 AND v.table_id=? AND v.id=?";
        Object[] args = admin(who) ? new Object[0] : new Object[]{who.tableId(), allowed};
        List<OrderView> orders = loadOrders(" WHERE " + scope, args);
        List<Ticket> tickets = db.query("SELECT k.*,v.table_id FROM tickets k JOIN visits v ON v.id=k.visit_id WHERE " + scope + " ORDER BY k.id DESC",
                r -> new Ticket(r.getLong("id"), r.getInt("table_id"), r.getString("visit_id"), r.getString("type"), r.getString("status"), r.getString("note"), r.getString("reply"), r.getString("created_at")), args);
        long revision = db.query("SELECT value FROM metadata WHERE name='revision'", r -> r.getLong(1)).get(0);
        return new Snapshot(revision, menu, tables, orders, tickets);
    }
    public synchronized JsonObject execute(Identity who, String action, JsonObject input) throws SQLException {
        return execute(who, UUID.randomUUID().toString(), action, input);
    }
    public synchronized JsonObject outcome(Identity who, String commandId) throws SQLException {
        if (who == null) throw problem("UNAUTHENTICATED", "Vui lòng đăng nhập.");
        validateCommandId(commandId);
        List<JsonObject> found = db.query("SELECT action,fingerprint,result_json FROM command_receipts WHERE principal=? AND command_id=?", r -> {
            JsonObject result = new JsonObject(); result.addProperty("found", true); result.addProperty("commandId", commandId);
            result.addProperty("action", r.getString("action")); result.addProperty("fingerprint", r.getString("fingerprint")); result.add("result", JsonParser.parseString(r.getString("result_json"))); return result;
        }, principal(who), commandId);
        if (!found.isEmpty()) return found.get(0);
        JsonObject result = new JsonObject(); result.addProperty("found", false); result.addProperty("commandId", commandId); return result;
    }
    private static void validateCommandId(String id) {
        if (id == null || id.isBlank() || id.length() > 80) throw problem("INVALID_INPUT", "Mã yêu cầu không hợp lệ.");
    }
    public synchronized Identity startNewVisit(Identity who) throws SQLException {
        requireGuest(who); String previous = guestVisit(who);
        if (previous == null || !db.query("SELECT id FROM visits WHERE id=? AND active=1", r -> r.getString(1), previous).isEmpty()) throw problem("INVALID_STATE", "Chỉ bắt đầu khách mới sau khi lượt trước đã kết thúc.");
        String token = UUID.randomUUID().toString() + UUID.randomUUID();
        List<String> visits = db.query("SELECT id FROM visits WHERE table_id=? AND active=1", r -> r.getString(1), who.tableId());
        db.update("INSERT INTO guest_credentials VALUES(?,?,?,?)", Commands.digest(token), who.username(), visits.isEmpty() ? null : visits.get(0), Instant.now().toString());
        return new Identity(who.username(), who.role(), who.tableId(), token);
    }
    public synchronized JsonObject discard(Identity who, String commandId, String action, JsonObject input) throws SQLException {
        requireGuest(who); validateCommandId(commandId);
        if (!Commands.guestMutation(action)) throw problem("INVALID_INPUT", "Chỉ bỏ yêu cầu của khách chưa được tiếp nhận.");
        return db.transaction(() -> {
            String owner = principal(who), fingerprint = Commands.fingerprint(action, input);
            JsonObject known = outcome(who, commandId);
            if (known.get("found").getAsBoolean()) {
                String saved = db.query("SELECT fingerprint FROM command_receipts WHERE principal=? AND command_id=?", r -> r.getString(1), owner, commandId).get(0);
                if (!saved.equals(fingerprint)) throw problem("COMMAND_CONFLICT", "Mã yêu cầu đã dùng cho nội dung khác.");
                return known;
            }
            JsonObject result = new JsonObject(); result.addProperty("cancelledBeforeAcceptance", true);
            db.update("INSERT INTO command_receipts VALUES(?,?,?,?,?,?)", owner, commandId, action, fingerprint, Json.GSON.toJson(result), Instant.now().toString());
            return outcome(who, commandId);
        });
    }
    public synchronized JsonObject execute(Identity who, String commandId, String action, JsonObject input) throws SQLException {
        if (who == null) throw problem("UNAUTHENTICATED", "Vui lòng đăng nhập.");
        validateCommandId(commandId);
        return db.transaction(() -> {
            String fingerprint = Commands.fingerprint(action, input);
            if (Commands.mutation(action)) {
                List<JsonObject> existing = db.query("SELECT fingerprint,result_json FROM command_receipts WHERE principal=? AND command_id=?", r -> {
                    if (!r.getString("fingerprint").equals(fingerprint)) throw problem("COMMAND_CONFLICT", "Mã yêu cầu đã dùng cho nội dung khác.");
                    return JsonParser.parseString(r.getString("result_json")).getAsJsonObject();
                }, principal(who), commandId);
                if (!existing.isEmpty()) {
                    if (existing.get(0).has("cancelledBeforeAcceptance")) throw problem("COMMAND_DISCARDED", "Yêu cầu chưa được nhận đã được bỏ; không tạo lại.");
                    return existing.get(0);
                }
            }
            JsonObject result = switch (action) {
                case "OPEN_TABLE" -> openTable(who, integer(input, "tableId"));
                case "PLACE_ORDER" -> placeOrder(who, input);
                case "SET_ORDER_STATUS" -> advanceOrder(who, integer(input, "orderId"), text(input, "status", 30, true));
                case "CALL_SERVICE", "REQUEST_BILL" -> createTicket(who, input, action);
                case "HANDLE_TICKET" -> handleTicket(who, integer(input, "ticketId"), text(input, "reply", 500, true));
                case "GET_BILL" -> Json.object(bill(who, text(input, "visitId", 80, true)));
                case "PAY_AND_CLOSE" -> pay(who, text(input, "visitId", 80, true));
                case "CLOSE_EMPTY_TABLE" -> closeEmpty(who, text(input, "visitId", 80, true));
                default -> throw problem("UNKNOWN_ACTION", "Thao tác không được hỗ trợ.");
            };
            if (!action.equals("GET_BILL")) db.update("UPDATE metadata SET value=value+1 WHERE name='revision'");
            if (Commands.mutation(action)) db.update("INSERT INTO command_receipts VALUES(?,?,?,?,?,?)", principal(who), commandId, action, fingerprint, Json.GSON.toJson(result), Instant.now().toString());
            return result;
        });
    }
    private JsonObject openTable(Identity who, int tableId) throws SQLException {
        requireAdmin(who);
        if (db.query("SELECT id FROM cafe_tables WHERE id=?", r -> r.getInt(1), tableId).isEmpty()) throw problem("NOT_FOUND", "Không có bàn này.");
        if (!db.query("SELECT id FROM visits WHERE table_id=? AND active=1", r -> r.getString(1), tableId).isEmpty()) throw problem("TABLE_ALREADY_OPEN", "Bàn đã có phiên đang hoạt động.");
        String visit = UUID.randomUUID().toString();
        db.update("INSERT INTO visits(id,table_id,active,opened_at) VALUES(?,?,1,?)", visit, tableId, Instant.now().toString());
        db.update("UPDATE guest_credentials SET visit_id=? WHERE visit_id IS NULL AND username IN(SELECT username FROM accounts WHERE table_id=?)", visit, tableId);
        return fields("visitId", visit);
    }
    private JsonObject placeOrder(Identity who, JsonObject input) throws SQLException {
        requireGuest(who); String visit = text(input, "visitId", 80, true); activeVisit(who, visit);
        JsonElement element = input.get("items");
        if (element == null || !element.isJsonArray() || element.getAsJsonArray().isEmpty() || element.getAsJsonArray().size() > 20)
            throw problem("INVALID_INPUT", "Chọn từ 1 đến 20 món.");
        List<OrderItem> items = new ArrayList<>(); Set<Integer> seen = new HashSet<>();
        for (JsonElement row : element.getAsJsonArray()) {
            if (!row.isJsonObject()) throw problem("INVALID_INPUT", "Danh sách món không hợp lệ.");
            int id = integer(row.getAsJsonObject(), "menuId"), quantity = integer(row.getAsJsonObject(), "quantity");
            if (quantity < 1 || quantity > 20 || !seen.add(id)) throw problem("INVALID_INPUT", "Số lượng phải từ 1–20 và mỗi món chỉ có một dòng.");
            List<MenuItem> found = db.query("SELECT * FROM menu WHERE id=?", r -> new MenuItem(id, r.getString("name"), r.getLong("price_vnd"), r.getString("category")), id);
            if (found.isEmpty()) throw problem("NOT_FOUND", "Món không tồn tại.");
            MenuItem item = found.get(0); items.add(new OrderItem(id, item.name(), quantity, item.priceVnd(), item.priceVnd() * quantity));
        }
        long id = db.insert("INSERT INTO orders(visit_id,status,note,created_at) VALUES(?,'SUBMITTED',?,?)", visit, text(input, "note", 500, false), Instant.now().toString());
        for (OrderItem item : items) db.update("INSERT INTO order_items VALUES(?,?,?,?,?)", id, item.menuId(), item.name(), item.quantity(), item.unitPriceVnd());
        JsonObject output = new JsonObject(); output.addProperty("orderId", id); output.addProperty("totalVnd", items.stream().mapToLong(OrderItem::subtotalVnd).sum()); return output;
    }
    private JsonObject advanceOrder(Identity who, int orderId, String status) throws SQLException {
        requireAdmin(who);
        List<OrderView> found = loadOrders(" WHERE o.id=?", orderId);
        if (found.isEmpty()) throw problem("NOT_FOUND", "Không có đơn này.");
        OrderView order = found.get(0); activeVisit(who, order.visitId());
        String next = switch (order.status()) { case "SUBMITTED" -> "PREPARING"; case "PREPARING" -> "READY"; case "READY" -> "SERVED"; default -> ""; };
        if (!next.equals(status)) throw problem("INVALID_STATE", "Chỉ được chuyển sang bước phục vụ kế tiếp.");
        db.update("UPDATE orders SET status=? WHERE id=?", status, orderId); return fields("status", status);
    }
    private JsonObject createTicket(Identity who, JsonObject input, String type) throws SQLException {
        requireGuest(who); String visit = text(input, "visitId", 80, true); activeVisit(who, visit);
        if (type.equals("REQUEST_BILL") && loadOrders(" WHERE o.visit_id=?", visit).isEmpty()) throw problem("INVALID_STATE", "Bàn chưa có đơn để tính tiền.");
        if (!db.query("SELECT id FROM tickets WHERE visit_id=? AND type=? AND status='OPEN'", r -> r.getLong(1), visit, type).isEmpty())
            throw problem("TICKET_ALREADY_OPEN", "Yêu cầu cùng loại đang chờ xử lý.");
        long id = db.insert("INSERT INTO tickets(visit_id,type,status,note,created_at) VALUES(?,?,'OPEN',?,?)", visit, type, text(input, "note", 500, false), Instant.now().toString());
        JsonObject output = new JsonObject(); output.addProperty("ticketId", id); return output;
    }
    private JsonObject handleTicket(Identity who, int id, String reply) throws SQLException {
        requireAdmin(who);
        List<String> visits = db.query("SELECT visit_id FROM tickets WHERE id=? AND status='OPEN'", r -> r.getString(1), id);
        if (visits.isEmpty()) throw problem("INVALID_STATE", "Yêu cầu không tồn tại hoặc đã được xử lý.");
        activeVisit(who, visits.get(0)); db.update("UPDATE tickets SET status='HANDLED',reply=? WHERE id=?", reply, id); return fields("reply", reply);
    }
    private Bill bill(Identity who, String visit) throws SQLException {
        int table = activeVisit(who, visit); List<OrderView> orders = loadOrders(" WHERE o.visit_id=?", visit);
        return new Bill(visit, table, orders.stream().mapToLong(OrderView::totalVnd).sum(), orders);
    }
    private JsonObject pay(Identity who, String visit) throws SQLException {
        requireAdmin(who); Bill bill = bill(who, visit);
        if (bill.orders().isEmpty() || bill.orders().stream().anyMatch(o -> !o.status().equals("SERVED"))) throw problem("INVALID_STATE", "Cần phục vụ xong tất cả đơn trước khi thanh toán.");
        if (!db.query("SELECT id FROM tickets WHERE visit_id=? AND status='OPEN'", r -> r.getLong(1), visit).isEmpty()) throw problem("INVALID_STATE", "Cần xử lý các yêu cầu còn đang mở.");
        long receipt = db.insert("INSERT INTO payments(visit_id,total_vnd,method,paid_at) VALUES(?,?,'CASH_SIMULATED',?)", visit, bill.totalVnd(), Instant.now().toString());
        db.update("UPDATE visits SET active=0,closed_at=? WHERE id=?", Instant.now().toString(), visit);
        JsonObject output = Json.object(bill); output.addProperty("receiptId", receipt); output.addProperty("paymentMethod", "CASH_SIMULATED"); return output;
    }
    private JsonObject closeEmpty(Identity who, String visit) throws SQLException {
        requireAdmin(who); activeVisit(who, visit);
        if (!loadOrders(" WHERE o.visit_id=?", visit).isEmpty() || !db.query("SELECT id FROM tickets WHERE visit_id=? AND status='OPEN'", r -> r.getLong(1), visit).isEmpty())
            throw problem("INVALID_STATE", "Chỉ đóng bàn trống và đã xử lý hết yêu cầu.");
        db.update("UPDATE visits SET active=0,closed_at=? WHERE id=?", Instant.now().toString(), visit);
        return fields("visitId", visit);
    }
    private int activeVisit(Identity who, String visit) throws SQLException {
        List<Integer> tables = db.query("SELECT table_id FROM visits WHERE id=? AND active=1", r -> r.getInt(1), visit);
        if (tables.isEmpty()) throw problem("SESSION_CLOSED", "Phiên bàn đã kết thúc hoặc không tồn tại.");
        if (!admin(who) && !Objects.equals(who.tableId(), tables.get(0))) throw problem("FORBIDDEN", "Bạn không có quyền trên bàn này.");
        if (!admin(who) && !Objects.equals(guestVisit(who), visit)) throw problem("STALE_SESSION", "Quyền của bạn không thuộc lượt khách này. Yêu cầu cũ không được chuyển lượt.");
        return tables.get(0);
    }
    private String principal(Identity who) throws SQLException {
        if (admin(who)) return who.username();
        guestVisit(who); // Also verify the credential when looking up a closed visit's receipt.
        return who.username() + ":" + Commands.digest(who.credential());
    }
    private String guestVisit(Identity who) throws SQLException {
        if (who.credential() == null) throw problem("INVALID_CREDENTIAL", "Thiếu quyền của lượt khách.");
        List<Optional<String>> found = db.query("SELECT visit_id FROM guest_credentials WHERE token_hash=? AND username=?", r -> Optional.ofNullable(r.getString(1)), Commands.digest(who.credential()), who.username());
        if (found.isEmpty()) throw problem("INVALID_CREDENTIAL", "Quyền của lượt khách không hợp lệ.");
        return found.get(0).orElse(null);
    }
    private List<OrderView> loadOrders(String where, Object... args) throws SQLException {
        record Header(long id, int table, String visit, String status, String note, String time) { }
        List<Header> headers = db.query("SELECT o.*,v.table_id FROM orders o JOIN visits v ON v.id=o.visit_id" + where + " ORDER BY o.id DESC",
                r -> new Header(r.getLong("id"), r.getInt("table_id"), r.getString("visit_id"), r.getString("status"), r.getString("note"), r.getString("created_at")), args);
        List<OrderView> orders = new ArrayList<>();
        for (Header h : headers) {
            List<OrderItem> items = db.query("SELECT * FROM order_items WHERE order_id=? ORDER BY menu_id", r -> new OrderItem(r.getInt("menu_id"), r.getString("name"), r.getInt("quantity"), r.getLong("unit_price_vnd"), r.getLong("unit_price_vnd") * r.getInt("quantity")), h.id());
            orders.add(new OrderView(h.id(), h.table(), h.visit(), h.status(), h.note(), items.stream().mapToLong(OrderItem::subtotalVnd).sum(), h.time(), List.copyOf(items)));
        }
        return List.copyOf(orders);
    }
    private static boolean admin(Identity who) { return who != null && "ADMIN".equals(who.role()); }
    private static void requireAdmin(Identity who) { if (!admin(who)) throw problem("FORBIDDEN", "Chỉ chủ quán được thực hiện thao tác này."); }
    private static void requireGuest(Identity who) { if (admin(who) || who.tableId() == null) throw problem("FORBIDDEN", "Thao tác dành cho khách tại bàn."); }
    public static String text(JsonObject data, String field, int max, boolean required) {
        JsonElement value = data.get(field);
        if (value == null || value.isJsonNull()) { if (!required) return ""; throw problem("INVALID_INPUT", "Thiếu trường " + field); }
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) throw problem("INVALID_INPUT", "Trường " + field + " phải là chuỗi.");
        String result = value.getAsString().trim();
        if (result.length() > max || (required && result.isEmpty())) throw problem("INVALID_INPUT", "Trường " + field + " không hợp lệ.");
        return result;
    }
    public static int integer(JsonObject data, String field) {
        try {
            JsonElement value = data.get(field);
            if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) throw new ArithmeticException();
            return value.getAsBigDecimal().intValueExact();
        } catch (RuntimeException e) { throw problem("INVALID_INPUT", "Trường " + field + " phải là số nguyên."); }
    }
    private static JsonObject fields(String name, String value) { JsonObject result = new JsonObject(); result.addProperty(name, value); return result; }
    private static BusinessException problem(String code, String detail) { return new BusinessException(code, detail); }
    @Override public synchronized void close() throws SQLException { db.close(); }
}
